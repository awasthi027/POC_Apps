module Fastlane
  module Actions
    class BuildCarthageAwopensslAction < Action
      def self.run(params)
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
        bump_type = Actions.lane_context[SharedValues::VERSION_DIGIT_TO_BUMP].to_s

        podspecLocation = Actions.sh("find " + workingDirectory + "/*.podspec").gsub("//","/").gsub("\n","") # replace '//' with '/' incase both working directory comes with trailing '/'
        currentPodspecVersion = other_action.version_get_podspec(path: podspecLocation)
        newVersion = other_action.version_bump_podspec(path: podspecLocation, bump_type: bump_type) # determine what the next version should be
        other_action.version_bump_podspec(path: podspecLocation, version_number: currentPodspecVersion) # reset podspec version to current version

        Actions.sh("agvtool new-marketing-version " + newVersion)

        prebuildAWOpenSSL(
          iosFrameworkOutputDirectory: workingDirectory + "/Release-Framework/AWCMWrapper.framework",
          iOSSymbolsOutputDirectroy: workingDirectory + "/Symbols/AWCMWrapper.framework-iOS.dSYM",
          macOSFrameworkOutputDirectory: workingDirectory + "/Release-Framework-OSX/AWCMWrapper.framework",
          macOSSymbolsOutputDirectroy: workingDirectory + "/Symbols/AWCMWrapper.framework-OSX.dSYM"
        )

        # Actions.sh("rm -rf Carthage/")
        # UI.header("Building Arxan AWOpenSSL Version..")
        #
        # ENV["ARXAN_PROTECTED_RELEASE"] = "1"
        # Actions.sh("(cd " + workingDirectory + "; pod install)")
        # prebuildArxanAWOpenSSL(
        #   iosFrameworkOutputDirectory: workingDirectory + "/Release-Framework-Arxan/AWCMWrapper.framework",
        #   iOSSymbolsOutputDirectroy: workingDirectory + "/Symbols-Arxan/AWCMWrapper.framework-iOS.dSYM"
        # )
      end

      def self.prebuildAWOpenSSL(params)
        iOSFrameworkOutputDirectory = params[:iosFrameworkOutputDirectory]
        iOSSymbolsOutputDirectroy = params[:iOSSymbolsOutputDirectroy]
        macOSFrameworkOutputDirectory = params[:macOSFrameworkOutputDirectory]
        macOSSymbolsOutputDirectroy = params[:macOSSymbolsOutputDirectroy]
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]

        Actions.sh("carthage build --no-skip-current")

        #delete old frameworks
        UI.message("Removing old AWCMWrapper frameworks and symbols...")
        Actions.sh("rm -rf " + iOSFrameworkOutputDirectory)
        Actions.sh("rm -rf " + iOSSymbolsOutputDirectroy)
        Actions.sh("rm -rf " + macOSFrameworkOutputDirectory)
        Actions.sh("rm -rf " + macOSSymbolsOutputDirectroy)

        # Move iOS Artifacts
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/iOS/AWCMWrapper.framework " + iOSFrameworkOutputDirectory)
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/iOS/AWCMWrapper.framework.dSYM " + iOSSymbolsOutputDirectroy)

        # Move macOS Artifacts
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/Mac/AWCMWrapper.framework " + macOSFrameworkOutputDirectory)
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/Mac/AWCMWrapper.framework.dSYM " + macOSSymbolsOutputDirectroy)

      end

      def self.prebuildArxanAWOpenSSL(params)
        iOSFrameworkOutputDirectory = params[:iosFrameworkOutputDirectory]
        iOSSymbolsOutputDirectroy = params[:iOSSymbolsOutputDirectroy]
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]

        Actions.sh("carthage build --no-skip-current --platform iOS")

        #delete old frameworks
        UI.message("Removing old AWCMWrapper frameworks and symbols...")
        Actions.sh("rm -rf " + iOSFrameworkOutputDirectory)
        Actions.sh("rm -rf " + iOSSymbolsOutputDirectroy)

        # Move iOS Artifacts
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/iOS/AWCMWrapper.framework " + iOSFrameworkOutputDirectory)
        Actions.sh("mv " + workingDirectory + "/Carthage/Build/iOS/AWCMWrapper.framework.dSYM " + iOSSymbolsOutputDirectroy)
      end
      # validate that the current project is a framework and fail with error message if it is not since
      # validate that this project is AWCMWrapper; otherwise return false
      def self.validateENVVariables
        if !Actions.lane_context[SharedValues::FRAMEWORK_PROJECT].to_s.downcase.strip == 'true'
          UI.user_error!("This action only supports framework projects. If this project is a framework please"+
          " add/update the FRAMEWORK_PROJECT variable in your .env file to be true.")
          return false
        end
        if !Actions.lane_context[SharedValues::WORKSPACE_NAME].to_s.include? "AWCMWrapper"
          UI.error("This action is only supported for the AWCMWrapper/AWOpenSSL repository. Do not try to use it for other repositories or projects.")
          return false
        end
        return true
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.details
        # Optional:
        # this is your chance to provide a more detailed description of this action
        "You can use this action to do cool things..."
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
