module Fastlane
  module Actions
    module SharedValues
      SITH_APP_FILENAME = :SITH_APP_FILENAME
    end

    class DeploySithSimulatorBuildsAction < Action
      def self.run(params)
        produceAppFile
      end

      def self.produceAppFile
        workspace = Actions.lane_context[SharedValues::WORKSPACE_NAME]
        scheme = Actions.lane_context[SharedValues::WORKSPACE_SCHEME]
        appname = Actions.lane_context[SharedValues::APP_DISPLAY_NAME]
        bin_name = Actions.lane_context[SharedValues::BINARY_NAME]
        derivedDataPath = Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY]
        artifactDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        simulator_name = Actions.lane_context[SharedValues::SIMULATOR_NAME]
        simulator_runtime = Actions.lane_context[SharedValues::SIMULATOR_RUNTIME].gsub("-",'.')
        sithAppName = bin_name
        if Actions.lane_context[SharedValues::USE_SCHEME_NAME].to_s.downcase.strip == 'true'
            UI.important('Using scheme name as app name')
            sithAppName = scheme
        end
        Actions.sh("xcodebuild -workspace " + workspace + " -scheme "+ scheme +
          " -configuration Debug -derivedDataPath "+ derivedDataPath +
          " -destination 'platform=iOS Simulator,name="+simulator_name+",OS="+simulator_runtime+"' clean build | xcpretty -c", log: true)
        Actions.sh("cp -a "+derivedDataPath+"/Build/Products/Debug-iphonesimulator/"+sithAppName+".app "+artifactDirectory+"/"+sithAppName+".app")
        Actions.sh("(cd "+artifactDirectory+"; zip -r "+sithAppName+".zip "+sithAppName+".app)")
        Actions.lane_context[SharedValues::SITH_APP_FILENAME] = sithAppName+".zip"

      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.details
        "SITH uses .app files to sideload the application onto simulators, so this
        action grabs the .app files found in the derived data path that was produced and
        then zips the .app files and uploads both .app files to artifactory for SITH to
        be able to download"
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :api_token,
                                       env_name: "FL_DEPLOY_SITH_SIMULATOR_BUILDS_APP_FILE_NAME", # The name of the environment variable
                                       description: ".app file na,e for DeploySithSimulatorBuildsAction")
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
