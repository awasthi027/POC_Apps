module Fastlane
  module Actions
    module SharedValues
      GENERATE_THIRD_PARTY_FRAMEWORKS_FOLDER_NAME = :GENERATE_THIRD_PARTY_FRAMEWORKS_FOLDER_NAME
    end

    class GenerateThirdPartyFrameworksAction < Action
      def self.run(params)
        generateFrameworks(xamarinCompatible: params[:xamarinCompatible])
        artifactsGenerated = 0
        Dir.glob('**/*.zip') { |file|
          renameFrameworkFiles(file: file, xamarinCompatible: params[:xamarinCompatible], shouldDoAppCheck: params[:shouldDoAppCheck])
          artifactsGenerated += 1
        }
        if artifactsGenerated == 0
          UI.user_error!('Zero artifacts were generated from this action')
        end
      end

      # generates the external versions of the SDK frameworks using the given version of xcode
      def self.generateFrameworks(params)
        developerDirectory=Actions.lane_context[SharedValues::DEVELOPER_DIR]
        UI.header("Generating Frameworks with xcode version: " + Actions.lane_context[SharedValues::XCODE_VERSION])
        errorMessage = "
        ------------------------------------------------------------------------------------
        ------------------------------------------------------------------------------------
                      ERROR: the framework generation script failed
        ------------------------------------------------------------------------------------
        ------------------------------------------------------------------------------------"
        Actions.sh("ls")
        if params[:xamarinCompatible].to_s.downcase.strip == 'true'
            Actions.sh("(export BAMBOO_DEVELOPER_DIR="+developerDirectory+";
                sh Scripts/Generate_Third_Party_Frameworks.sh allowDebug DisableBitcode) || echo '" + errorMessage + "'",log: true)
        else
            Actions.sh("(export BAMBOO_DEVELOPER_DIR="+developerDirectory+";
                sh Scripts/Generate_Third_Party_Frameworks.sh allowDebug CodeSign 'Apple Distribution: Wandering WiFi LLC') || echo '" + errorMessage + "'",log: true)
        end

        UI.header("Completed generating Frameworks with xcode version: " + Actions.lane_context[SharedValues::XCODE_VERSION])
      end

      # renames the framework zips outputted by the generation script to a user-friendly naming convention
      def self.renameFrameworkFiles(params)
        UI.important("Renaming Framework Files...")

        binaryName = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]
        file = params[:file]
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        UI.message("Zipfile found in the directory: " + file)
        filename = file.chomp('.zip')

        swiftVersionExtension = filename.partition('allowDebug').last
        newFolderName = "Frameworks-Xcode"

        if params[:xamarinCompatible].to_s.downcase.strip == 'true'
            newFolderName = newFolderName + "-XamarinCompatible"
        end

        UI.important("Unzipping file: " + file)
        Actions.sh("unzip " + file + " -d " + artifactsDirectory + " 2>&1 > /dev/null")
        Actions.sh("ls")
        Actions.sh("rm " + file + " 2>&1 > /dev/null",log: true)

        Actions.sh("mv " + artifactsDirectory + "/" + filename + " " + artifactsDirectory + "/" + newFolderName,log: true)

        UI.important("Zipping file: " + artifactsDirectory + "/" + newFolderName + " 2>&1 > /dev/null")

        if params[:shouldDoAppCheck].to_s.downcase.strip == 'true'
          Actions.sh("find " + artifactsDirectory + "/" + newFolderName + " -type d -name 'dSYMs' -prune -execdir rm -rf {} \\;")
          Actions.sh("find " + artifactsDirectory + "/" + newFolderName + " -type d -name '*dSYM' -prune -execdir rm -rf {} \\;")
          Actions.sh("find " + artifactsDirectory + "/" + newFolderName + " -type f -name Info.plist -prune -execdir sh -c 'count=$(plutil -convert json $1 -o - | grep -o DebugSymbolsPath | wc -l); for (( i=0; i<$count; i++ )); do plutil -remove AvailableLibraries.$i.DebugSymbolsPath $1; done' _ {} \\;")
          UI.important("Removing DSYM file from app check scan")
        end
        Actions.sh("(cd " + artifactsDirectory + "/" + newFolderName + "; zip -r " + binaryName + ".zip " + binaryName+") 2>&1 > /dev/null",log: false)
        Actions.sh("rm -rf " + artifactsDirectory + "/" + newFolderName + "/" + binaryName +" 2>&1 > /dev/null",log: true)
        Actions.lane_context[SharedValues::GENERATE_THIRD_PARTY_FRAMEWORKS_FOLDER_NAME] = newFolderName

        UI.important("Finished Renaming Framework Files.")
      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Generates the Third Party version of the SDK Framework"
      end

      def self.output
        [
          ['Frameworks.zip', 'The third party frameworks in a zip file located in the airwatchsdk/artifacts/ directory'],
          ['Frameworks', 'The third party frameworks in a folder located in the airwatchsdk/artifacts/ directory']
        ]
      end

      def self.available_options
        [
         FastlaneCore::ConfigItem.new(key: :xamarinCompatible,
                                        env_name: "FL_XAMARIN_COMPATIBLE",
                                        description: "xamarinCompatible",
                                        optional: true,
                                        is_string: false,
                                        default_value: false), # the default value if the user didn't provide one
         FastlaneCore::ConfigItem.new(key: :shouldDoAppCheck,
                                          env_name: "",
                                          description: "doAppCheck",
                                          optional: true,
                                          is_string: false,
                                          default_value: false) # the default value if the user didn't provide one
      ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
