module Fastlane
  module Actions

    class ThirdPartyCompilationTestAction < Action
      def self.run(params)
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        moveSampleAppToArtifactsFolder
        replaceFrameworkFilesInSampleApp

        #compile project
        UI.important('Attemping to compile project...')
        other_action.scan(
          project: artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication.xcodeproj",
          scheme: "SDKExampleApplication",
          clean: true,
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack: true #slack notifications are sent at end of fastlane execution
        )
      end

      # copies the SDKExampleApplication form the SampleApps directory inside the
      # AirWatchSDK repo into the artifacts folder where it can then be used for compilation
      # testing and for packaging into a dmg if the package_dmg action is later run
      def self.moveSampleAppToArtifactsFolder
        UI.important('moving sample application to artifacts folder...')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        Actions.sh("cp -a SampleApps/SDKExampleApplication " + artifactsDirectory + "/SDKExampleApplication", log:true)
        Actions.sh("(cd "+artifactsDirectory+"; ls)")
        UI.success("Finished moving sample application to the artifacts folder.")
      end

      # Deletes the old AirWatchSDK frameworks out of the SDKExampleApplication and
      # replaces them with the framework files found in the artifacts directory
      # Precondition - the SampleApp must have been moved to the artifacts directory
      def self.replaceFrameworkFilesInSampleApp
        UI.important('Deleting old frameworks from sample app directory...')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        #delete old framework files from directory
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWSDK.framework || true",log:true)
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWCMWrapper.framework || true",log:true)
        UI.success("Finished deleting old frameworks with those from artifacts folder.")

        UI.important('Unziping new frameworks and placing them in sample app directory...')
        #copy new framework files into directory
        Actions.sh("unzip " + artifactsDirectory + "/Frameworks-*.zip -d " + artifactsDirectory + " 2>&1 > /dev/null")

        Actions.sh("(cd "+artifactsDirectory+"; ls)")
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/; ls)")

        Actions.sh("mkdir "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/Frameworks/ || echo \"Framework folder already exists. No need to create one.\"")
        Actions.sh("cp -a " + artifactsDirectory + "/Frameworks-*/AWSDK.framework " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWSDK.framework", log:true)
        Actions.sh("cp -a " + artifactsDirectory + "/Frameworks-*/AWCMWrapper.framework " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWCMWrapper.framework", log:true)

        Actions.sh("(cd "+artifactsDirectory+"; ls)")
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/Frameworks/; ls)")
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/; ls)")

        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/; ls)")
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/; ls)")
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/Frameworks/; ls)")
        UI.success("Finished replacing old frameworks with those from artifacts folder.")
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Copies SDKExampleApplication into artifacts directoy and compiles it"
      end

      def self.details
        "Precondition: there must be pre-compiled airwatchsdk framework files inside the shared artifacts directory"
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
