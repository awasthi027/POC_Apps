module Fastlane
  module Actions
    @@artifactDirectory
    @@appDisplayName
    @@baseID
    @@releaseID

    class UploadToAppcheckAction < Action
      def self.run(params)
        @@artifactDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        @@appDisplayName = Actions.lane_context[SharedValues::APP_DISPLAY_NAME].to_s
        @@releaseID = Actions.lane_context[SharedValues::RID].to_s
        @@baseID = Actions.lane_context[SharedValues::BID].to_s

        appName = params[:appDisplayName]
        token = Actions.lane_context[SharedValues::APPCHECK_TOKEN]
        group = 48 # for MAIN
        appName = "BID__#{@@baseID}__RID__#{@@releaseID}__#{@@appDisplayName}.zip"
        Actions.sh("git clone ssh://git@stash.air-watch.com:7999/apsec/appcheck-tool.git", log: false)
        UI.message("Posting to appcheck with: " + appName)
        # Call script to do upload
        Actions.sh("cd #{@@artifactDirectory}; mv Frameworks-Xcode/AWSDK.xcframework.zip #{appName}")
        Actions.sh("cd #{@@artifactDirectory}; sh ../appcheck-tool/bdba_upload.sh --group #{group} --token #{token} #{appName}", log: true, error_callback: true)
        end


      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Uploads artifact to AppCheck for security scans."
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :appDisplayName,
                                       env_name: "FL_UPLOAD_TO_APPCHECK_APP_DISPLAY_NAME",
                                       description: "appDisplayName",
                                       optional: false,
                                       is_string: true),
        ]
      end

      def self.is_supported?(platform)
          [:ios].include?(platform)
      end
    end
  end
end
