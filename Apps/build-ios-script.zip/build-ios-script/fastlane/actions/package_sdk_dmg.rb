module Fastlane
    module Actions
        module SharedValues
            PACKAGE_SDK_DMG_CUSTOM_VALUE = :PACKAGE_SDK_DMG_CUSTOM_VALUE
        end

        class PackageSdkDmgAction < Action
            @@awprivacyArtifactoryRepoURL = 'https://artifactory.air-watch.com/artifactory/api/storage/prod-apps-ios/ISDK/AWPrivacy/snapshots/master/latest/Framework'
            @@artifactoryUsername = 'deployer'
            @@artifactoryPassword = 'AP2N7ob4YK1FedaGuYrBJ3W8ftr'

            def self.run(params)
                # Core WS1 SDK
                prepareWorkspaceONESDKFilesForDMG

                # Privacy SDK
                preparePrivacySDKFilesForDMG

                moveDMGGeneratorResourcesToArtifactsFolder

                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                Actions.sh("(cd "+ artifactsDirectory+"; ls)")
                Actions.sh("(cd "+ artifactsDirectory+"; dmgbuild -s dmgFormatTemplateV2.py \"VMwareWorkspaceONESDK\" \"VMwareWorkspaceONESDK.dmg\")")
            end

            ##################################################
            # Prepare Workspace One SDK Files Helper Methods #
            ##################################################

            # Prepare Workspace One SDK Files
            def self.prepareWorkspaceONESDKFilesForDMG
                UI.important("Preparing the Workspace One SDK Files for DMG creation...")
                currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
                other_action.download_latest_ios_sdk_frameworks_from_artifactory(branchName:currentBranch.to_s)
                organizeWS1SDKFrameworkFilesIntoSingleFolder
                moveLicenseAndAcknowledgementsToArtifactsFolder
                UI.success("Finished preparing the Workspace One SDK Files for DMG creation.")
            end

            def self.organizeWS1SDKFrameworkFilesIntoSingleFolder
                UI.important('Organizing framework files into a single folder...')
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s

                Actions.sh(" mkdir -p " + artifactsDirectory + "/\"Workspace ONE SDK\"/")
                Actions.sh(" mkdir -p " + artifactsDirectory + "/\"Workspace ONE SDK\"/" + "/\"Frameworks-Xcode\"/")
                UI.message("seaching for file names matching with .zip extension...")

                zipfilesFound = 0
                Dir.glob("**/*.zip") { |file|
                    UI.message("Found file named = " + file)
                    if file.include? "xcframework"
                        Actions.sh("unzip " + file + " -d " + artifactsDirectory + "/\"Workspace ONE SDK\"/"+ "/\"Frameworks-Xcode\"/ 2>&1 > /dev/null", log:true)
                        Actions.sh("rm -f " + file + " 2>&1 > /dev/null", log:true)
                        if zipfilesFound == 0 # only copy first zip file artifacts to base artifacts folder so that it can be used in example app
                            Actions.sh("mkdir -p " + artifactsDirectory + "/\"Frameworks\"/")
                            Actions.sh("cp -a " + artifactsDirectory + "/\"Workspace ONE SDK\"/Frameworks-Xcode/* " + artifactsDirectory + "/Frameworks/", log:true)
                        end
                    else
                        UI.message("File named: " + file + " does not include Frameworks in name and will therefore be deleted.")
                        Actions.sh("rm -rf " + file)
                    end
                }
                Actions.sh("find " + artifactsDirectory + "/\"Workspace ONE SDK\" -type d -name 'dSYMs' -prune -execdir rm -rf {} \\;")
                Actions.sh("find " + artifactsDirectory + "/\"Workspace ONE SDK\" -type d -name '*dSYM' -prune -execdir rm -rf {} \\;")
                Actions.sh("find " + artifactsDirectory + "/\"Workspace ONE SDK\" -type f -name Info.plist -prune -execdir sh -c 'count=$(plutil -convert json $1 -o - | grep -o DebugSymbolsPath | wc -l); for (( i=0; i<$count; i++ )); do plutil -remove AvailableLibraries.$i.DebugSymbolsPath $1; done' _ {} \\;")
                UI.success("Framework files organized into single folder. Moved "+ zipfilesFound.to_s+ " zip files")
            end


            # Moves the license, the Acknowledgements, and the README files from the working directory
            # into the artifact directory so that they can be added to the DMG.
            def self.moveLicenseAndAcknowledgementsToArtifactsFolder
                UI.important('Moving license and Acknowledgements files to artifacts folder...')
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                Actions.sh("cp -a -v "+workingDirectory+"/\"WS1 SDK Agreement.pdf\" " + artifactsDirectory + "/\"Workspace ONE SDK\"/\"WS1 SDK Agreement.pdf\"") #LICENSE file
                Actions.sh("cp -a -v "+workingDirectory+"/Acknowledgements.txt " + artifactsDirectory + "/\"Workspace ONE SDK\"/Acknowledgements.txt") #Acknowledgements file
                Actions.sh("cp -a -v "+workingDirectory+"/fastlane/resources/WS1SDK-README.txt " + artifactsDirectory + "/\"Workspace ONE SDK\"/README.txt") #README file
                UI.success('Finshed moving license and Acknowledgements files to artifacts folder.')
            end


            ##############################################
            # Prepare Privacy SDK Files Helper Methods #
            ##############################################

            # Prepare Privacy SDK Files
            def self.preparePrivacySDKFilesForDMG
                downloadLatestPrivacySDKFromArtifactory
                organizePrivacySDKFrameworkFilesIntoSingleFolder
                movePrivacySDKLicenseAndReadmeFileToPrivacySDKFolder
            end

            def self.downloadLatestPrivacySDKFromArtifactory
                UI.important('Downloading Latest Privacy Frameworks from artifactory...')
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]

                uri = URI(@@awprivacyArtifactoryRepoURL)
                response = Net::HTTP.get(uri)
                jsonResult = JSON.parse(response)
                downloadURI = jsonResult['uri'].gsub('api/storage/','')
                #Make sure downloadURI does not have / at the end
                UI.message ("downloadURI  " + downloadURI)
                children = jsonResult['children']
                UI.message ("children = " + children.to_s)
                children.each do |child|
                  childUri = child['uri'].gsub('/','')
                  if !childUri.include? ".dmg"
                    downloadCommand = "curl -u " + @@artifactoryUsername+":"+@@artifactoryPassword+" "+downloadURI+"/"+childUri+" --output " +artifactsDirectory+"/"+childUri
                    Actions.sh(downloadCommand, log:true)
                  end
                end
                UI.success("Finished downloading latest AWPrivacy Frameworks from artifactory.")
            end

            def self.organizePrivacySDKFrameworkFilesIntoSingleFolder
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                Actions.sh(" mkdir -p " + artifactsDirectory + "/\"Privacy SDK\"/")
                Dir.glob("**/*.zip") { |file|
                    UI.message("Found zip file named = " + file)
                    if file.include? "AWPrivacy-Xcode"
                        Actions.sh("unzip " + file + " -d "+ artifactsDirectory + "/\"Privacy SDK\"/ 2>&1 > /dev/null", log:true)
                        Actions.sh("rm -f " + file + " 2>&1 > /dev/null", log:true)
                    elsif file.include? "AWPrivacyExampleApplication"
                        UI.message("Unziping Privacy SDK Sample application to the Privacy SDK folder...")
                        Actions.sh("unzip " + file + " -d "+ artifactsDirectory + "/\"Privacy SDK\"/ 2>&1 > /dev/null", log:true)
                        Actions.sh("rm -f " + file + " 2>&1 > /dev/null", log:true)
                    else
                        UI.message("File named: " + file + " does not include AWPrivacy or AWPrivacyExampleApplication in name and will therefore be deleted.")
                        Actions.sh("rm -rf " + file)
                    end
                }
                UI.success("Finished organizing PrivacySDK files into a single folder.")
            end

            def self.movePrivacySDKLicenseAndReadmeFileToPrivacySDKFolder
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                UI.important('Moving Privacy License and README files into Privacy SDK folder...')
                Actions.sh("cp -a -v "+workingDirectory+"/\"WS1 SDK Agreement.pdf\" " + artifactsDirectory + "/\"Privacy SDK\"/\"WS1 SDK Agreement.pdf\"") #LICENSE file
                Actions.sh("cp -a -v "+workingDirectory+"/fastlane/resources/PrivacySDK-README.rtf " + artifactsDirectory + "/\"Privacy SDK\"/README.rtf") #README file
                UI.success('Finished moving Privacy License and README files into Privacy SDK folder.')
            end

            ##############################################
            #             Misc Helper Methods            #
            ##############################################

            # Moves all of the required resources needed for the dmg cfeation into the
            # artifacts folder where the DMG generator will be expecting it to be.
            # The resourses include: formatTemplate.json, background.png, and dmgIcon.icns
            def self.moveDMGGeneratorResourcesToArtifactsFolder
                UI.important('Moving DMG Generator Resources To Artifacts Folder...')
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                Actions.sh("cp -a -v fastlane/resources/dmgFormatTemplateV2.py "+ artifactsDirectory+"/dmgFormatTemplateV2.py")
                Actions.sh("cp -a -v fastlane/resources/background.png "+ artifactsDirectory+"/background.png")
                Actions.sh("cp -a -v fastlane/resources/dmgIcon.icns "+ artifactsDirectory+"/dmgIcon.icns")
                UI.success('Finished Moving DMG Generator Resources To Artifacts Folder.')
            end

            #####################################################
            # @!group Documentation
            #####################################################

            def self.description
                "A short description with <= 80 characters of what this action does"
            end

            def self.is_supported?(platform)
                [:ios, :mac].include?(platform)
            end
        end
    end
end
