module Fastlane
  module Actions
    module SharedValues
      CREATE_FRAMEWORK_FILENAME = :CREATE_FRAMEWORK_FILENAME
      CREATE_FRAMEWORK_DSYM_FILENAME = :CREATE_FRAMEWORK_DSYM_FILENAME
      CREATE_FRAMEWORK_ARTIFACT_LOCATION= :CREATE_FRAMEWORK_ARTIFACT_LOCATION
    end

    class CreateFrameworkAction < Action
      def self.run(params)
        createFrameworkArtifactDirectory= Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY] + "/CreateFrameworkResult"
        Actions.lane_context[SharedValues::CREATE_FRAMEWORK_ARTIFACT_LOCATION] = createFrameworkArtifactDirectory

        #Build the fmwk
        generateFrameworks

        #Copy the generated lib/dSYM to the artifacts folder
        copyArtifacts

        #zip the fmwk and dSYMs so they can be uploaded to the artifactory as is.
        processDeliverables

      end

      # generates framwork
      def self.generateFrameworks
          developerDirectory=Actions.lane_context[SharedValues::DEVELOPER_DIR]
          UI.important("Generating Frameworks with xcode version: " + Actions.lane_context[SharedValues::XCODE_VERSION])
          schemeName = Actions.lane_context[SharedValues::WORKSPACE_SCHEME]
          projectName = Actions.lane_context[SharedValues::WORKING_DIRECTORY]+"/"+Actions.lane_context[SharedValues::WORKSPACE_NAME]

          carthageLogPath =  Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY] + "/carthage.log"
          resultPath = Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY]

          Actions.sh("carthage build --no-skip-current --configuration Release --log-path "+ carthageLogPath +" ; carthage archive "+ schemeName +" --output "+resultPath)
          UI.success("Completed generating Frameworks with xcode version: " + Actions.lane_context[SharedValues::XCODE_VERSION])
      end

      def self.clearArtifactsDir
        FileUtils.rm_rf(Dir[Actions.lane_context[Actions::SharedValues::CREATE_FRAMEWORK_ARTIFACT_LOCATION] + '/*'])
      end

      def self.copyArtifacts
          #clear artifcats dir
          clearArtifactsDir
          workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
          UI.important("Copying the artifacts to: " + Actions.lane_context[SharedValues::CREATE_FRAMEWORK_ARTIFACT_LOCATION])
          other_action.copy_artifacts(
            target_path:  Actions.lane_context[SharedValues::CREATE_FRAMEWORK_ARTIFACT_LOCATION],
            artifacts: [workingDirectory + "/"+ "**/*.framework",workingDirectory + "/"+ "**/*.dSYM"],
            keep_original: true
          )
      end

      def self.processDeliverables
        artifactDirectory = Actions.lane_context[SharedValues::CREATE_FRAMEWORK_ARTIFACT_LOCATION]
        UI.important("Begin Processing the deliverables ")
        binary_name = Actions.lane_context[SharedValues::BINARY_NAME]
        UI.message("Creating" +  binary_name + ".zip")

        frameworkName = binary_name.gsub(' ','-') #escape spaces
        frameworkDSYMName = (binary_name + "_dSYM ").gsub(' ','-') #escape spaces

        Actions.sh("cd " + artifactDirectory + " ; mkdir " + frameworkName + " ; cp -R *.framework ./" + frameworkName)
        Actions.sh("(cd " + artifactDirectory + " ; zip -r " + frameworkName+".zip " +frameworkName+") 2>&1 > /dev/null")

        UI.important("Creating Framework.dSYM.zip")

        Actions.sh("cd " + artifactDirectory + " ; mkdir "+frameworkDSYMName + " ; cp -R *.dSYM ./"+frameworkDSYMName)
        Actions.sh("cd " + artifactDirectory + " ; zip -r " + frameworkDSYMName +".zip "+ frameworkDSYMName+" 2>&1 > /dev/null")

        Actions.lane_context[SharedValues::CREATE_FRAMEWORK_FILENAME] = frameworkName+".zip"
        Actions.lane_context[SharedValues::CREATE_FRAMEWORK_DSYM_FILENAME] = frameworkDSYMName+".zip"
        UI.success("Finish Processing the deliverables ")

      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Generates framework with dsyms for the given xcode version. "
      end

      def self.output
        [
          ['Frameworks.zip', 'The third party frameworks in a zip file located in the <working_folder>/artifacts/ directory'],
          ['Frameworks_dSYM.zip', 'dsym files of frameworks in a zip file located in the <working_folder>/artifacts/ directory']
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end

    end
  end
end
