module Fastlane
  module Actions

    class LintLocalizationFilesAction < Action
      def self.run(params)
        filesLinted = 0
        derivedData = Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY].split('/').last
        Dir.glob("**/*.strings") {|file|
          unless file.include? derivedData # dont lint files in derived data directory because that will be duplications
            filesLinted += 1
            Actions.sh('plutil -lint ' + file.shellescape)
          end
        }
        UI.success("|Localization Linting Completed| " + filesLinted.to_s + " localization files were linted")
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Lints localization file to ensure syntax is correct"
      end

      def self.details
        "This action searches the known directory for any files ending in .strings
        extentsion and runs the 'plutil -lint' command on each file to ensure there
        are no syntax errors in the localization files.
        If there are no localization files found, this action prints '0 files linted' and
        completes successfully"
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
