module Fastlane
  module Actions
    module SharedValues
      ANALYZE_RESULTS = :ANALYZE_RESULTS
    end

    class AnalyzeAction < Action
      def self.run(params)
        pathToProjectFile = Actions.lane_context[SharedValues::WORKING_DIRECTORY]+"/"+Actions.lane_context[SharedValues::WORKSPACE_NAME]
        logPath = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s+"/analyze.log"
        if Actions.lane_context[SharedValues::WORKSPACE_NAME].include? ".xcodeproj"
          analyzeProjct(pathToProjectFile: pathToProjectFile, logPath: logPath)
        else
          analyzeWorkspace(pathToProjectFile: pathToProjectFile, logPath: logPath)
        end
        collectResultsFromLog(logPath: logPath)
      end

      def self.analyzeWorkspace(params)
        command = "xcodebuild clean analyze -workspace " + params[:pathToProjectFile].to_s + " -scheme " + Actions.lane_context[SharedValues::WORKSPACE_SCHEME].to_s + " | xcpretty | tee " + params[:logPath].to_s
        Actions.sh(command)
      end

      def self.analyzeProjct(params)
        command = "xcodebuild clean analyze -project " + params[:pathToProjectFile].to_s + " -scheme " + Actions.lane_context[SharedValues::WORKSPACE_SCHEME].to_s + " | xcpretty | tee " + params[:logPath].to_s
        Actions.sh(command)
      end

      # parse the log file and collect each of the warnings that were found
      # if those warnings should not be excluded add them to the list of found warnings
      # keeps a tally of both found warnings and excluded warnings. If the warningsFound > 0
      # the action will fail fastlane execution and notify_slack of the failure
      def self.collectResultsFromLog(params)
        logFile = params[:logPath].to_s
        UI.message("Logfile found for metrics reporting: " + logFile)
        failureMessage = ""
        warningsFound = 0
        excludedWarnings = 0
        File.readlines(logFile).each { |line|
          if (line.include? "⚠️")
            if !shouldWarningBeExcluded(warning: line)
              failureMessage = failureMessage + "\n" + line.strip
              warningsFound += 1
            else
              excludedWarnings += 1
            end
          end
        }
        resultMessage = "Static Analysis Found " + warningsFound.to_s + " warnings (" + excludedWarnings.to_s + " excluded)."
        Actions.lane_context[SharedValues::ANALYZE_RESULTS] = resultMessage
        UI.message("Result Metrics = " + resultMessage)
        if warningsFound > 0
          UI.user_error!("The following analysis warnings were found: " + failureMessage)
        end
      end

      # is this static analysis warning from a file that falls under a directory listed in the
      # sonar exclusion environment variable.
      # returns true if this warning contains a path that should be excluded; false otherwise
      def self.shouldWarningBeExcluded(params)
        warning = params[:warning].to_s
        exclusions = Action.lane_context[SharedValues::SONAR_EXCLUSIONS].to_s.split(",")
        exclusions.each { |exclusion|
          formattedExclusion = exclusion.gsub('*','')
          if warning.include? formattedExclusion
            return true
          end
        }
        return false
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "This action runs xcode's static analysis and reports the compilation warnings that it finds."
      end

      def self.details
        "This action runs xcode's static analysis and reports the compilation warnings that it finds."
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
