module Fastlane
  module Actions
    module SharedValues
      POD_LIB_LINT_CUSTOM_VALUE = :POD_LIB_LINT_CUSTOM_VALUE
    end

    class PodLibLintAction < Action
      def self.run(params)
          workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
          Actions.sh("find " + workingDirectory + "/*.podspec").gsub("//","/").split("\n").each do |location| # replace '//' with '/' incase both working directory comes with trailing '/'
              if doesPodspecHaveArtifactorySource(location)
                  UI.important("Attempting to lint a artifactory sourced podpsec...")
                  # generateFrameworks
                  # runPodLibLint(location)
              else
                  UI.important("Attempting to lint a git sourced podpsec...")
                  moduleName = getPodspeceName(location)
                  replaceAnyPODS_ROOTVariablesWithAbsolutePath(location, moduleName)
                  runPodLibLint(location)
              end
          end
      end

      def self.doesPodspecHaveArtifactorySource(location)
          UI.message("Determining if podspec has an artifactory source or not...")
          podspecLines = other_action.read_podspec(path: location).to_s.split(",")
          puts podspecLines
          podspecLines.each do |line|
              if line.include? "source"
                  UI.important("Source Line in podspec reads: " + line.to_s)
                  if line.include? "\"http\"=>\"https://artifactory.air-watch.com/artifactory/"
                      UI.important("Source is artifactory. Should not proceed with this action")
                      return true
                  else
                      UI.important("Source line found and is not artifactory.")
                  end
              end
          end
          UI.important("Source is not artifactory.")
          return false
      end

      def self.getPodspeceName(location)
          UI.message("Determining podspec's name...")
          podspecLines = other_action.read_podspec(path: location).to_s.split(",")
          puts podspecLines
          specName = ""
          podspecLines.each do |line|
              if line.include? "\"name\""
                  specName = line.split("=>").last.gsub("\"","").strip
                  UI.important("Found name to be: " + specName)
                  return specName
              end
          end
          UI.error("Failed to find podspec name. Will most likely fail when we try to replace any local path")
          return ""
      end

      def self.generateFrameworks
          workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
          Actions.sh("sh " + workingDirectory+"/GenerateFrameworks.sh")
          # unizp result packaging
          Actions.sh("unzip *.zip")
      end

      def self.replaceAnyPODS_ROOTVariablesWithAbsolutePath(location, moduleName)
        UI.message("Replacying any ${PODS_ROOT} variables with absolute values...")
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
        currentBranchName = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME].to_s

        newPodspecLines = ""
        valueToReplace = "${PODS_ROOT}/"+moduleName
        UI.message("valueToReplace: " + valueToReplace)
        File.readlines(location).each { |line|
          if line.include? "${PODS_ROOT}"
            UI.message("Found line with ${PODS_ROOT} in path: " + line)
            edittedLine = line.gsub(valueToReplace,workingDirectory)
            UI.important("Replacing line with: " + edittedLine)

            newPodspecLines = newPodspecLines + edittedLine
          else
            newPodspecLines = newPodspecLines + line
          end
        }

        UI.message("Newly Editted Podspec: \n\n" + newPodspecLines)
        File.open(location, "w") {|file| file.puts newPodspecLines }
        UI.success("Finished replacying any ${PODS_ROOT} variables with absolute values.")
      end

      def self.runPodLibLint(location)
        UI.message("Running Pod Lib Lint...")
        command = "pod lib lint "+ location +" --allow-warnings --verbose --fail-fast"
        if Actions.lane_context[SharedValues::SKIP_LINT_TESTS].to_s == "true"
            command = command + " --skip-tests"
        end
        UI.message("USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT value: " + Actions.lane_context[SharedValues::USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT].to_s)
        if Actions.lane_context[SharedValues::USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT].to_s == "true"
          command = command + " --use-libraries"
        end
        command = command + " --sources=git@github.com:euc-uem/ios-specs.git,git@github.com:euc-uem/euc-oss-specs.git,git@github.com:euc-uem/pivd-ios-specs.git"
        Actions.sh(command)
        UI.success("Finished Linting Podspec")
      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Runs pod lib lint on the podspec found in the directory"
      end

      def self.details
        "You can use this action lint your podspec to ensure that they are of valid format and
        to determine if they can be successfully pushed to the pod spec repo"
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
