module Fastlane
    module Actions
        module SharedValues
            PUBLISH_ARTIFACTORY_VENDORED_POD_CUSTOM_VALUE = :PUBLISH_ARTIFACTORY_VENDORED_POD_CUSTOM_VALUE
        end

        class PublishArtifactoryVendoredPodAction < Action
            @@artifactoryURL = 'https://artifactory.abc.com/artifactory/'
            @@artifactoryUsername = 'deployer'
            @@artifactoryPassword = 'AP2N7ob4YK1FedaGu'

            def self.run(params)
                if validateENVVariables == false
                    UI.message("ArtiFact: ENV variables did not validate for UpdatePodVersionAction to execute. Skipping this action.")
                    return
                end
                podspecLocation = findPodspecPath
                if podspecLocation.to_s.empty?
                    UI.message("ArtiFact: Skipping action as could not find a podspec with an artifactory source")
                    return
                end
                UI.message("ArtiFact: Calling to setup setGITSSHRemoteAndUserInfo")
                setGITSSHRemoteAndUserInfo
                #setGITRemoteAndUserInfo
                # (1) Get podspec Location, tagPrefix, Current Version
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                currentPodspecVersion = getPodspecVersionNumber(podspecLocation)
                expectedTag = ("build/" + currentPodspecVersion).strip

                # if the current commit has a tag matching the expectedTag then that means we should not attempt to push a new version
                # if the current commit does not have a tag mathcing the expectedTag that means we should update the build version and podspec version
                # and commit this to the repo.
                # Note: the next execution on CI will see that this new commit would have a tag matching a version number and see that it does not need to do anything
                newVersion = currentPodspecVersion
                if doesCurrentCommitHaveTagMatchingVersion(expectedTag)
                    UI.success("ArtiFact: No need to make any commits to update version or make a new tag as there is already one present on this commit.")
                    if doesAPodSpecVersionAlreadyExistInPodspecRepo(podspecLocation, newVersion)
                        UI.success("ArtiFact: No need to push a new podspec as a podspec for version (" + newVersion.to_s + ") already exists")
                        UI.success("ArtiFact: Finshed Execution with no action taken.")
                        return
                    end
                else
                    if doesAPodSpecVersionAlreadyExistInPodspecRepo(podspecLocation, newVersion)
                        newVersion = bumpCurrentVersion(podspecLocation)
                    end
                    ensurePlistVersionsAreSameAsNewPodspecVersion(newVersion)
                    commitNewVersionToRemote(newVersion: newVersion, additionalFilesToCommit: params[:additionalFilesToCommit])
                    tagNewCommitWithUpdatedTag(("build/" + newVersion).strip)
                end
                publishVendoredFrameworkToArtifactory(newVersion)
                pushNewPodspec(podspecLocation)
                sendSlack(podspecLocation: podspecLocation, newVersion: newVersion)
                UI.success("ArtiFact: Finshed updating pod version")
            end

            # get the currect version from the podspec and fail with a user friendly error message if the
            # podspec cannot be located
            def self.getPodspecVersionNumber(podspecLocation)
                currentPodspecVersion = other_action.version_get_podspec(path: podspecLocation)
                UI.important("ArtiFact: Current Podspec Version: " + currentPodspecVersion.to_s)
                return currentPodspecVersion
            end

            # Checks to see if the current commit already has a tag matching the version found in the podspec
            # if it does, the method returns true. It is assumed that this indicates a "re-run" and therefore
            # this action should exit with success otherwise the 2nd run of any commit would always cause a buildID
            # failure.
            def self.doesCurrentCommitHaveTagMatchingVersion(expectedTag)
                UI.message("ArtiFact: Looking for expectedTag: (" + expectedTag + ")...")
                gitTags = Actions.sh('git tag -l --points-at HEAD', log:false)
                UI.message("ArtiFact: Found the following tags on current commit: " + gitTags.to_s.strip)
                if gitTags.include? expectedTag
                    UI.success("ArtiFact: Commit already has a tag matching tag("+expectedTag.to_s+"). "+
                    "This execution is assumed to be a re-run...")
                    return true
                end
                UI.important("ArtiFact: Commit does not have a tag matching ("+expectedTag.to_s+")")
                return false
            end

            # Checks to see if a tag already exists with same version number found in the podspec on this commit
            # if the tag exists elsewhere on another commit this action should fail as that indicates that this
            # version number is not unique and the user needs to update the podspec and info.plist
            def self.doesTagExist(tagName)
                UI.message("ArtiFact: Checking remote for matching tag: (" + tagName.to_s + ")")
                result = Actions.sh("git ls-remote origin " + tagName.to_s)
                if result.to_s.empty?
                    UI.message("ArtiFact: Did not find tag matching version ("+tagName.to_s+"). Podspec version has been determined to be unique.")
                    return false
                end
                UI.message("ArtiFact: Found tag matching version ("+tagName.to_s+").")
                return true
            end

            # bumps the current pod spec minor version by 1 and then uses agvtool to set the verion in the info.plist to be the same
            def self.bumpCurrentVersion(podspecLocation)
                bump_type = Actions.lane_context[SharedValues::VERSION_DIGIT_TO_BUMP].to_s
                UI.important("ArtiFact: ENV file provided bump_type = " + bump_type)
                UI.important("ArtiFact: Bumping the current " + bump_type + " version number by 1")

                currentVersion = other_action.version_get_podspec(path: podspecLocation)
                newVersion = other_action.version_bump_podspec(path: podspecLocation, bump_type: bump_type)
                UI.important("ArtiFact: currentVersion: " + currentVersion.to_s + " || newVersion: " + newVersion.to_s)
                return newVersion
            end

            def self.ensurePlistVersionsAreSameAsNewPodspecVersion(newVersion)
                #update info.plists
                Actions.sh("agvtool new-marketing-version " + newVersion)
            end

            # !!!WARNING!!!! This method makes a git commit!! Be very careful calling this method!!
            def self.commitNewVersionToRemote(params)
                newVersion = params[:newVersion]
                additionalFilesToCommit = params[:additionalFilesToCommit]
                UI.message("ArtiFact: Additional Files to commit: " + additionalFilesToCommit.to_s)
                UI.important("ArtiFact: Committing new version to remote...")
                modifiedFilesToCommitCount = 0
                changedFiles = Actions.sh("git status").split("\n").each do |line|
                    if line.include? "modified:"
                        modifiedFileName = line.gsub("modified:","").strip
                        isModifieldFileWhiteListedForCommit = false
                        additionalFilesToCommit.each { |filename|
                            UI.message("Checking to see if filename: " + modifiedFileName.to_s + " matches a whitelisted file name: " + filename.to_s)
                            if modifiedFileName.include? filename
                                UI.message("Modified file ( " + modifiedFileName.to_s + ") matches whitelisted modifiedFileName (" + filename.to_s + "). Will be added to commit")
                                isModifieldFileWhiteListedForCommit = true
                            end
                        }
                        if (modifiedFileName.include? ".podspec") || (modifiedFileName.include? ".plist") || (isModifieldFileWhiteListedForCommit)
                            UI.important("Will commit modified file: " + modifiedFileName)
                            Actions.sh("git add " + modifiedFileName)
                            modifiedFilesToCommitCount += 1
                        else
                            UI.message("Ignoring modified file: " + modifiedFileName)
                        end
                    end
                end
                if modifiedFilesToCommitCount > 0
                    Actions.sh("git commit -m \"Publishing Pod Version: " + newVersion + "\"")
                    currentBranchName = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
                    Actions.sh("git push --set-upstream origin " + currentBranchName.to_s)
                    UI.success("ArtiFact: Successfully committed update.")
                    Actions.lane_context[SharedValues::CHANGES_COMMITTED_FOR_POD_VERSION_UPDATE] = true
                else
                    UI.message("ArtiFact: No modified files were found to commit.")
                end
            end

            def self.tagNewCommitWithUpdatedTag(newTag)
                UI.important("ArtiFact: Tagging this current commit with tag: (" + newTag.to_s + ").")
                Actions.sh("git tag " + newTag.to_s)
                Actions.sh("git push origin " + newTag.to_s)
                UI.success("ArtiFact: Successfully added new tag.")
            end

            def self.regenerateFrameworksWithNewVersionNumbersToUpload
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                Actions.sh("sh " + workingDirectory+"/GenerateFrameworks.sh")
            end

            def self.publishVendoredFrameworkToArtifactory(newVersion)
                regenerateFrameworksWithNewVersionNumbersToUpload
                artifactLocation = Actions.sh("find *-" + newVersion + ".zip").gsub("//","/").gsub("\n","")
                if artifactLocation.to_s.empty?
                    UI.user_error!("ArtiFact: Failed to find artifact to publish to artifactory")
                    return
                end
                UI.message("ArtiFact: Uploading Vendored Framework to artifactory named: " + artifactLocation + " ...")
                artifactoryRepoPath = Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH] + "/release/"+artifactLocation # Path to place the artifact including its filename
                uploadCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -T "+artifactLocation+" "+@@artifactoryURL+artifactoryRepoPath
                Actions.sh(uploadCommand)
                UI.success("ArtiFact: Successfully Uploaded release framework to artifactory.")
            end

            def self.doesAPodSpecVersionAlreadyExistInPodspecRepo(podspecLocation, desiredVersion)
                UI.message("ArtiFact: Checking to see if a pod spec version matching desired version (" +desiredVersion+ ") already exists in pod spec repo...")
                updateLocalAirwatchSpecRepos
                podspecName = podspecLocation.split("/").last.gsub(".podspec","")
                searchResults = getCurrentlyAvailablePodVersions(podspecName)
                UI.message("ArtiFact: Checking to see if version: (" + desiredVersion.to_s + ") exists already.")
                searchResults.each { |a|
                    if desiredVersion == a.to_s.strip
                        UI.important("ArtiFact: Found pre-existing pod spec version matching the desired version: ("+ desiredVersion.to_s + ")")
                        return true
                    end
                }
                UI.important("ArtiFact: Did not find pre-existing pod spec version matching the desired version: ("+ desiredVersion.to_s + ")")
                return false
            end

            def self.getCurrentlyAvailablePodVersions(podspecName)
                UI.message("ArtiFact: Searching for pod versions of pod named: " + podspecName)
                searchResults = Actions.sh("pod search " + podspecName + " --simple --no-pager").split("\n")
                availableVersions = []
                if searchResults.count > 0
                    searchResults.each do |result|
                        if result.include? "Versions:"
                            versionArr = result.gsub("- Versions:","").strip.split("[").first
                            availableVersions = versionArr.split(",")
                            UI.message("ArtiFact: Found the following availabe version of pod named: " + podspecName + "\n\t" + availableVersions.to_s)
                            return availableVersions
                        end
                    end
                end
                UI.important("ArtiFact: Failed to find any versions of this pod!")
                return availableVersions
            end

            # This method can be added on to support other spec repo's
            # DO NOT UPDATE THE MASTER POD REPO THAT COMES FROM GIT. THAT IS NOT NEEDED FOR THIS ACTION AND WILL TAKE A LONG TIME TO EXECUTE
            def self.updateLocalAirwatchSpecRepos
                UI.message("ArtiFact: Updating local copies of airwatch internal spec repos...")
                Actions.sh("pod repo update air-watch-specs --silent || true", log: false)
                Actions.sh("pod repo update air-watch-specs-1 --silent  || true",log: false)
                Actions.sh("pod repo update sdk-ext-specs --silent || true",log: false)
                Actions.sh("pod repo update air-watch-peoplesearchnetworkpodspec --silent || true",log: false)
                UI.success("Finished updating local copies of airwatch internal spec repos.")
            end

            def self.pushNewPodspec(podspecLocation)
                UI.message("ArtiFact: Pushing new podspec...")
                UI.message("ArtiFact: USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT value: " + Actions.lane_context[SharedValues::USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT].to_s)
                command = "pod repo push air-watch-specs " + podspecLocation + " --allow-warnings --verbose"
                if Actions.lane_context[SharedValues::USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT].to_s == "true"
                    command = command + " --use-libraries"
                end
                if Actions.lane_context[SharedValues::WORKSPACE_NAME].include? "AirWatchSDK"
                    command = command + " --skip-tests"
                end
                if Actions.lane_context[SharedValues::WORKSPACE_NAME].include? "XCUIHubApp"
                  command = command + " --skip-tests" + " --no-private"
                end
                Actions.sh(command)
                UI.success("ArtiFact: Finished Pushing new podspec")
            end

            def self.sendSlack(params)
                podspecLocation = params[:podspecLocation]
                newVersion = params[:newVersion]
                #exclude the unit testing metrics
                podspecName = podspecLocation.split("/").last.gsub(".podspec","")
                Actions.lane_context[SharedValues::TEST_METRICS] = ""
                Actions.lane_context[SharedValues::CODE_COVERAGE] = ""
                other_action.notify_slack(success:true, messageSubject:"Publishing " + podspecName + " version (" + newVersion.to_s + ")")
            end

            def self.setGITSSHRemoteAndUserInfo
                sshRepoURL = Actions.lane_context[SharedValues::SSH_REPO_URL]
                UI.important("ssh Repo URL: " + sshRepoURL)
                Actions.sh("git remote set-url origin " + sshRepoURL)
                Actions.sh("git config user.name \"SDK Pod Publisher\"")
               Actions.sh("git config user.email \"stash-iossdk-svc@abc.com\"")
            end

#            def self.setGITRemoteAndUserInfo
#                httpRepoURL = Actions.lane_context[SharedValues::HTTPS_REPO_URL]
#                Actions.sh("git remote set-url origin https://stash-iossdk-svc:DFgJJk0LjNds" + httpRepoURL)
#                Actions.sh("git config user.name \"SDK Pod Publisher\"")
#                Actions.sh("git config user.email \"stash-iossdk-svc@abc.com\"")
#            end

            def self.findPodspecPath
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                podspecsLocations = Actions.sh("find " + workingDirectory + "/*.podspec").gsub("//","/").split("\n").each do |location| # replace '//' with '/' incase both working directory comes with trailing '/'
                    UI.message("ArtiFact: Examining possible podspec location at: " + location.to_s)
                    if doesPodspecHaveArtifactorySource(location)
                        return location
                    end
                end
                UI.error("ArtiFact: Failed to find podspec with an artifactory source to update version and publish new version.")
                return nil
            end

            def self.doesPodspecHaveArtifactorySource(podspecLocation)
                UI.message("ArtiFact: Determining if podspec has an artifactory source or not...")
                podspecLines = other_action.read_podspec(path: podspecLocation).to_s.split(",")
                puts podspecLines
                podspecLines.each do |line|
                    if line.include? "source"
                        UI.important("ArtiFact: Source Line in podspec reads: " + line.to_s)
                        if line.include? "\"http\"=>\"https://artifactory.air-watch.com/artifactory/"
                            UI.important("Source is artifactory. Okay to proceed with this action")
                            return true
                        else
                            UI.important("ArtiFact: Source line found and is not artifactory. Should not proceed with this action")
                        end
                    end
                end
                UI.important("ArtiFact: Source is not artifactory. Should not proceed with this action")
                return false
            end
            # validate that the current project is a framework and fail with error message if it is not since
            # validate that the current branch is registered as the branch for podspec creation
            # validate that the SSH_REPO_URL has been provided and fails with error message if it has not been provided
            # apps cannot be cocoapods
            def self.validateENVVariables
                if !Actions.lane_context[SharedValues::FRAMEWORK_PROJECT].to_s.downcase.strip == 'true'
                    UI.user_error!("ArtiFact: This action only supports framework projects. If this project is a framework please add/update the FRAMEWORK_PROJECT variable in your .env file to be true.")
                    return false
                end
                if Actions.lane_context[SharedValues::SSH_REPO_URL].to_s.empty?
                    UI.error("ArtiFact: This action cannot successfully execute without the env variable: SSH_REPO_URL. Please provide this variable in your .env file.")
                    return false
                end
                return currentBranchIsRegisteredNewPodSpecVersionCreation
            end

            # To prevent new podspec version creations on every single feature branch, the current branch
            # must be registered in order for the new podspec version to be created.
            # This method checks the env value BRANCH_NAME_FOR_POD_CREATION and if current branch
            # is registered it returns true; false otherwise
            def self.currentBranchIsRegisteredNewPodSpecVersionCreation
                if Actions.lane_context[SharedValues::BRANCH_NAME_FOR_POD_CREATION].to_s.empty?
                    UI.important("ArtiFact: There are no registered branches for new pod version creation. Skipping this step...")
                    return false
                end
                branches = Actions.lane_context[SharedValues::BRANCH_NAME_FOR_POD_CREATION].split(",")
                currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
                UI.message("ArtiFact: Checking to see if currentBranch ("+currentBranch.to_s+") is registered for new pod version creation...")
                branches.each { |registeredBranch|
                    if registeredBranch.to_s == currentBranch
                        UI.important("Current branch ("+currentBranch.to_s+") is registered for new pod version creation. Matched registeredBranch: (" + registeredBranch.to_s + ")")
                        return true
                    end
                }
                UI.important("ArtiFact: Current branch ("+currentBranch.to_s+") is not registered for new pod version creation.\n\t"+
                "The currently registered branches include: \n\t\t" +branches.to_s)
                return false
            end
            #####################################################
            # @!group Documentation
            #####################################################

            def self.description
              "Prepares the updates for a new pod version by tagging or update version if not done"
            end

            def self.available_options
              [
                FastlaneCore::ConfigItem.new(key: :additionalFilesToCommit,
                                             env_name: "MODIFIED_FILES_TO_INCLUDE_IN_COMMIT",
                                             description: "Array of file names modified by other actions that should be included in commit",
                                             optional: true,
                                             default_value: [],
                                             is_string:false)
              ]
            end

            def self.is_supported?(platform)
              [:ios, :mac].include?(platform)
            end
          end
        end
      end
