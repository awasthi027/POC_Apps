module Fastlane
  module Actions
     @@artifactDirectory
    module SharedValues

      WORKPSPACE_ONE_SDK_SPM_CHECKSUM = :WORKPSPACE_ONE_SDK_SPM_CHECKSUM
      WORKPSPACE_ONE_SDK_RELEASE_ARTIFACTORY_URL = :WORKPSPACE_ONE_SDK_RELEASE_ARTIFACTORY_URL
    end

    class PublishXcframeworkToPublicArtifactoryAction < Action
      # Vars to hold artifactory details
      @@vmsassArtifactoryURL = 'https://abc.jfrog.io/artifactory/'

      def self.run(params)
        @@vmsassArtifactoryUsername = Actions.lane_context[SharedValues::ABCSAAS_ARTIFACT_REPO_USERNAME].to_s
        @@artifactDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s
        @@vmsassArtifactoryToken = Actions.lane_context[SharedValues::ABCESAAS_ARTIFACT_IOS_REPO_AUTH_TOKEN].to_s
        shouldParseFramework = params[:shouldParseFramework]
        artifactFolderPath = params[:artifactFolderPath]
        licenseFilePath = params[:licenseFilePath]
        otherArtifactsLocalPath = params[:otherArtifactsLocalPath]
        
        # check if branch is eligible to publish to public repo
        unless currentBranchIsRegisteredToPublishToPublicArtifactory
          UI.message("Skipping framework publish to public artifactory...")
          return
        end

        # Binary name
        binaryName = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]
        artifactName = binaryName+".zip"

        # download framework from internal artifactory
        currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        artifactoryRepoPath = Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH]
        other_action.download_latest_ios_sdk_frameworks_from_artifactory(branchName:currentBranch.to_s, artifactoryRepoPath:artifactoryRepoPath)

        if (shouldParseFramework.nil? || shouldParseFramework)
          UI.message("Parsing the downloaded XCFramework")
          prepareFrameworkToPublish
        else
          UI.message("Generating the checksum for un-parsed binary")
          computeCheckSum(artifact_path: @@artifactDirectory+"/"+artifactName)
        end

        # path to deploy xcframework in public repo
        #repo
        destination_repo_path = Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH_PRODUCTION]
        #path
        artifact_folder_path = artifactFolderPath.nil? ? "MAMSDK/Release/" : artifactFolderPath.to_s

        #release version
        target = Actions.lane_context[SharedValues::WORKSPACE_SCHEME]
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
        pathToXcodeProj = workingDirectory + '/' + target + '.xcodeproj'
        sdkVersion = other_action.get_version_number(xcodeproj: pathToXcodeProj, target: target)
        UI.message("Release version --> :"+ sdkVersion)

        #complete path https://vmwaresaas.jfrog.io/artifactory/Workspace-ONE-iOS-SDK/com/vmware/release/${sdkVersion}/${artifactName}
        artifactoryRepoPath = destination_repo_path+artifact_folder_path+sdkVersion+"/"+artifactName

        # local path to framework to upload
        localPathToArtifact = @@artifactDirectory+"/"+artifactName

        UI.important('uploading frawework ...')
        #delete if any fw already presented at given path
        deleteArtifact(destination_repo_path: artifactoryRepoPath)
        publishArtifactoryToPublic(pathToArtifact: localPathToArtifact, destination_repo_path: artifactoryRepoPath)
        Actions.lane_context[SharedValues::WORKPSPACE_ONE_SDK_RELEASE_ARTIFACTORY_URL] = @@vmsassArtifactoryURL + artifactoryRepoPath
        UI.success('Framework uploaded successfully ...')

        #License file
        licenseRepoPath = destination_repo_path + artifact_folder_path + sdkVersion+ '/' + 'License.txt'
        localLicensePath = (licenseFilePath.nil? || licenseFilePath.to_s.empty?) ? workingDirectory+'/fastlane/resources/WS1SDK-license.txt' : licenseFilePath
        UI.important('uploading license ...')
        deleteArtifact(destination_repo_path: licenseRepoPath)
        publishArtifactoryToPublic(pathToArtifact: localLicensePath, destination_repo_path: licenseRepoPath)
        UI.success('license uploaded successfully ...')

        # Upload other artifacts if available
        if (otherArtifactsLocalPath.nil? || otherArtifactsLocalPath.to_s.empty?) == false
          UI.important('Uploading other artifacts at local path ' + otherArtifactsLocalPath)
          
          otherArtifactsRepoPath = destination_repo_path + artifact_folder_path + sdkVersion+ '/' + File.basename(otherArtifactsLocalPath)
          deleteArtifact(destination_repo_path: otherArtifactsRepoPath)
          publishArtifactoryToPublic(pathToArtifact: otherArtifactsLocalPath, destination_repo_path: otherArtifactsRepoPath)

          UI.success('Uploaded other artifacts to ' + otherArtifactsRepoPath)
        end
      end

      # Checks current branch returns if branch prefix is release returns true else returns false
      def self.currentBranchIsRegisteredToPublishToPublicArtifactory
          currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
          UI.message("Checking to see if currentBranch ("+currentBranch.to_s+") is registered to publish framework to public artifact...")
          prefix = currentBranch.split('-').first
          if prefix.downcase == 'release'.downcase
              UI.important("Current branch ("+currentBranch.to_s+") is registered for framework publish")
            return true
          end
          UI.important("Current branch ("+currentBranch.to_s+") is not registered for framework publish")
          return false
      end

      def self.prepareFrameworkToPublish
        removeDsymsInsideFramework
        reSignAWSDKFramework
        zipAWSDKFramework
      end

      # removes dysms from downloaded framework
      def self.removeDsymsInsideFramework
        UI.important('Removing dYSMs files ...')
        UI.message("searching for file names matching with .zip extension...")
            
        zipfilesFound = 0
        Dir.glob("**/*.zip") { |file|
          UI.message("Found file named = " + file)
          if file.include? "xcframework"
            Actions.sh("unzip " + file + " -d " + @@artifactDirectory + " 2>&1 > /dev/null", log:true)
            Actions.sh("rm -f " + file + " 2>&1 > /dev/null", log:true)
          else
            UI.message("File named: " + file + " does not include Frameworks in name and will therefore be deleted.")
            Actions.sh("rm -rf " + file)
          end
        }

        Actions.sh("find " + @@artifactDirectory + " -type d -name 'dSYMs' -prune -execdir rm -rf {} \\;")
        Actions.sh("find " + @@artifactDirectory + " -type d -name '*dSYM' -prune -execdir rm -rf {} \\;")
        Actions.sh("find " + @@artifactDirectory + " -type f -name Info.plist -prune -execdir sh -c 'count=$(plutil -convert json $1 -o - | grep -o DebugSymbolsPath | wc -l); for (( i=0; i<$count; i++ )); do plutil -remove AvailableLibraries.$i.DebugSymbolsPath $1; done' _ {} \\;")
        UI.success("Removed dSYMs from framework..")
      end

      def self.reSignAWSDKFramework
        #Re-Sign only if _CodeSignature exists
        codeSigantureFolderName = '_CodeSignature'
        binaryName = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]
        codeSigantureFolderPath = @@artifactDirectory+"/"+binaryName+"/"+codeSigantureFolderName
        if Dir.exist?(codeSigantureFolderPath)
          UI.important('CodeSigning the framework ...')
          Actions.sh("find " + @@artifactDirectory + " -type d -name "+ codeSigantureFolderName +" -prune -execdir rm -rf {} \\;")
          Actions.sh("(cd " + @@artifactDirectory + "/" + "; codesign --timestamp -s 'Apple Distribution: Wandering WiFi LLC' " + binaryName +") 2>&1 > /dev/null", log: true)
          Actions.sh("(codesign --verify --verbose "+  @@artifactDirectory + "/" + binaryName + ")")
          UI.success("Completed CodeSigning framework..")
        else
          UI.important("Skipping codesign ....")
        end
      end

      # Zip the xcframework
      def self.zipAWSDKFramework
        UI.important('Zipping framework ...')
        binaryName = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]
        Actions.sh("(cd " + @@artifactDirectory + "/" + "; zip -r " + binaryName + ".zip " + binaryName+") 2>&1 > /dev/null", log: false)
        Actions.sh("rm -rf " + @@artifactDirectory + "/" + binaryName +" 2>&1 > /dev/null", log: true)
        computeCheckSum(artifact_path: @@artifactDirectory+"/"+binaryName+".zip")
        UI.success('Framework zipped.')
      end


      # deletes any artifacts found at the [destination_repo_path] on the artifactory server.
      # this is used to delete the contents of the latests folder before uploading a new artifact to it
      # so that the "created date" on the latests artifact will be reset every time a new artifact is uploaded
      # this will help avoid confusion when someone is downloading the artifact and sees and old "created date"
      def self.deleteArtifact(params)
        UI.important('Deleting framework from artifactory ...')
        deleteCommand = "curl -u "+@@vmsassArtifactoryUsername+":"+@@vmsassArtifactoryToken+" -X DELETE "+@@vmsassArtifactoryURL+params[:destination_repo_path]
        UI.message("deleteCommand = "+ deleteCommand)
        Actions.sh(deleteCommand, log:true)
        UI.success('Framework deleted.')
      end

      # uploads the zip framework to given repo path from local path
      def self.publishArtifactoryToPublic(params)
        UI.important('uploading artifact ...')
        uploadCommand = "curl -u "+@@vmsassArtifactoryUsername+":"+@@vmsassArtifactoryToken+" -T "+params[:pathToArtifact]+" "+@@vmsassArtifactoryURL+params[:destination_repo_path]
        UI.important("Upload command = " + uploadCommand)
        Actions.sh(uploadCommand, log:true)

        artifactURL = @@vmsassArtifactoryURL+params[:destination_repo_path]
        # remove downloaded artifacts
        Actions.sh("rm -rf " +@@artifactDirectory+"/")
        UI.success('artifact published: '+ artifactURL)
      end

      def self.computeCheckSum(params)
        checksum = Actions.sh("shasum -a 256 "+ params[:artifact_path]).split(' ').first
        Actions.lane_context[SharedValues::WORKPSPACE_ONE_SDK_SPM_CHECKSUM] = checksum
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Use this action only on WorkspaceONE SDK release branches only!!, This action publishes xcframework to vmwaresaas artifactory."
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :shouldParseFramework,
                                       env_name: "FL_PUBLISH_XCFRAMEWORK_TO_PUBLIC_ARTIFACTORY_SHOULD_PARSE_FRAMEWORK",
                                       description: "Optional Parameter to decide if the downloaded xcframework should be parsed",
                                       optional: true,
                                       default_value: true, # defaults to true i.e. downloaded xcframework would be parsed.
                                       is_string: false), # true: verifies the input is a string, false: every kind of value
          FastlaneCore::ConfigItem.new(key: :artifactFolderPath,
                                       env_name: "FL_PUBLISH_XCFRAMEWORK_TO_PUBLIC_ARTIFACTORY_ARTIFACT_FOLDER_PATH",
                                       description: "Optional Parameter for the folder path of the artfact in vmware saas",
                                       optional: true,
                                       default_value: 'MAMSDK/Release/', # defaults to 'MAMSDK/Release/'
                                       is_string: true), # true: verifies the input is a string, false: every kind of value
          FastlaneCore::ConfigItem.new(key: :licenseFilePath,
                                       env_name: "FL_PUBLISH_XCFRAMEWORK_TO_PUBLIC_ARTIFACTORY_LICENSE_FILE_PATH",
                                       description: "Optional Parameter for the local license file path that needs to be uploaded",
                                       optional: true,
                                       is_string: true), # true: verifies the input is a string, false: every kind of value
          FastlaneCore::ConfigItem.new(key: :otherArtifactsLocalPath,
                                       env_name: "FL_PUBLISH_XCFRAMEWORK_TO_PUBLIC_ARTIFACTORY_OTHER_ARTIFACTS_LOCAL_PATH",
                                       description: "Optional Parameter for any other artifacts to be uploaded which is ideally zipped",
                                       optional: true,
                                       is_string: true), # true: verifies the input is a string, false: every kind of value
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
