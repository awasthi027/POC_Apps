module Fastlane
  module Actions

    class InstallProfilesAction < Action
      def self.run(params)
        UI.message("Installing provisioning profiles...")
        profilesCopied = 0
        Dir.glob("**/*.mobileprovision") { |file|
          unless file.include? 'embedded' # dont copy embedded provisioning profiles
            profilesCopied += 1
            Actions.sh('cp -a ' + file.shellescape + ' ~/Library/MobileDevice/Provisioning\ Profiles/')
          end
        }

        if profilesCopied == 0
          UI.error("Error:: 0 provisioning profiles were found in this repository to install")
        end
        UI.success("Installed " + profilesCopied.to_s + " provisioning profiles")\
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Copies all provisioning profiles from the repo to the machines provisioning profiles directory"
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
