module Fastlane
  module Actions
    module SharedValues
      # MANDATORY
      WORKSPACE_NAME = :WORKSPACE_NAME                  #Should include .xcodeproj or .xcworkspace
      WORKSPACE_SCHEME = :WORKSPACE_SCHEME
      DEVELOPER_DIR = :DEVELOPER_DIR

      # OPTIONAL
      SIMULATOR_NAME = :SIMULATOR_NAME                        # defaults to {WORKSPACE_SCHEME}Simulator
      SIMULATOR_RUNTIME = :SIMULATOR_RUNTIME                  # defaults to "17-0"
      SIMULATOR_DEVICE_TYPE = :SIMULATOR_DEVICE_TYPE          # defaults to "iPhone-11"
      POD_INSTALL_REQUIRED = :POD_INSTALL_REQUIRED            # defaults to false
      BRANCH_NAME_FOR_POD_CREATION = :BRANCH_NAME_FOR_POD_CREATION # the branch for which new podspec versions will be pushed
      VERSION_DIGIT_TO_BUMP = :VERSION_DIGIT_TO_BUMP          # major, minor, OR patch
     # HTTPS_REPO_URL = :HTTPS_REPO_URL
      SSH_REPO_URL = :SSH_REPO_URL                            # This is only needed for automatic podspec creation; Requires everything following the @ sign in the HTTP link
      USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT = :USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT #if the podspec linter should user static libraries option
      SKIP_LINT_TESTS = :SKIP_LINT_TESTS
      RERUN_UNIT_TEST_COUNT = :RERUN_UNIT_TEST_COUNT          # defaults to 0
      BINARY_NAME = :BINARY_NAME                              # defaults to value of WORKSPACE_NAME (should not include .app or .frameowork extension)
      CUSTOM_BINARY_FILEPATH = :CUSTOM_BINARY_FILEPATH        # custom path for binary needed for sonar reporting (NOT RECOMMENDED)
      INFO_PLIST_PATH = :INFO_PLIST_PATH                      # defaults to value of WORKSPACE_NAME/info.plist
      FRAMEWORK_PROJECT = :FRAMEWORK_PROJECT                  # defaults to false
      ADHOC_CONFIGURATION = :ADHOC_CONFIGURATION              # defaults to Release
      APPSTORE_CONFIGURATION = :APPSTORE_CONFIGURATION        # defaults to Release
      ENTERPRISE_CONFIGURATION = :ENTERPRISE_CONFIGURATION    # defaults to Release
      DEVELOPMENT_CONFIGRUATION = :DEVELOPMENT_CONFIGRUATION  # defaults to Debug
      EXPORT_OPTIONS_PLIST_ADHOC = :EXPORT_OPTIONS_PLIST_ADHOC
      EXPORT_OPTIONS_PLIST_DEVELOPMENT = :EXPORT_OPTIONS_PLIST_DEVELOPMENT
      EXPORT_OPTIONS_PLIST_APPSTORE = :EXPORT_OPTIONS_PLIST_APPSTORE
      EXPORT_OPTIONS_PLIST_ENTERPRISE = :EXPORT_OPTIONS_PLIST_ENTERPRISE
      GYM_XCARGS = :GYM_XCARGS
      SCAN_XCARGS = :SCAN_XCARGS
      USE_MULTI_SCAN = :USE_MULTI_SCAN # DEFAULTS TO FALSE
      MULTI_SCAN_TRY_COUNT = :MULTI_SCAN_TRY_COUNT # defaults to 3
      MULTI_SCAN_BATCH_COUNT = :MULTI_SCAN_BATCH_COUNT # defaults to 2
      XSW_FRAMEWORK = :XSW_FRAMEWORK
      APPCHECK_TOKEN = :APPCHECK_TOKEN # generated from bamboo global variables
      BID = :BID # application base ID from release hub
      RID = :RID # application relase ID from release hub
      # Shared value to save SDK binary name
      SDK_XCFRAMEWORK_BINARY_NAME = :SDK_XCFRAMEWORK_BINARY_NAME #default to AWSDK.xcframework
      
      # Shared value to save path to swift package repo (bamboo will clone package repo at this path)
      SWIFT_PACKAGE_FOLDER_PATH = :SWIFT_PACKAGE_FOLDER_PATH #default to swiftpackage/workspaceonesdk-package
      SWIFT_PACKAGE_TEMPLATE_REPOSITORY_ORIGIN_URL = :SWIFT_PACKAGE_TEMPLATE_REPOSITORY_ORIGIN_URL #defaulted to https://stash-iossdk-svc:DFgJJk0LjN87@stash.air-watch.com/scm/isdkl/workspaceonesdk-package.git
      VMWARESAAS_ARTIFACT_IOS_REPO_AUTH_TOKEN = :VMWARESAAS_ARTIFACT_IOS_REPO_AUTH_TOKEN #provided from bamboo global variables
      PUBLIC_SPM_REPO_PATH = :PUBLIC_SPM_REPO_PATH #default to publicSwiftRepo/iOS-WorkspaceONE-SDK
      PUBLIC_SPM_REPO_GIT_URL = :PUBLIC_SPM_REPO_GIT_URL # defauled to @github.com/vmwareairwatchsdk/iOS-WorkspaceONE-SDK.git
      PUBLIC_SPM_REPO_README_FILE_NAME = :PUBLIC_SPM_REPO_README_FILE_NAME # defauled to WS1SDK-Package-README.md

      # Documentation
      JAZZY_CONFIG_PATH = :JAZZY_CONFIG_PATH
      JAZZY_OUTPUT_NAME = :JAZZY_OUTPUT_NAME                  # DEFAULTS TO `docs`\n

      # OPTIONAL - SIGNING
      SIGNING_IDENTITY = :SIGNING_IDENTITY
      ADHOC_PROVISIONING_MAPPING = :ADHOC_PROVISIONING_MAPPING # format "bunldeID => provisioning profile name"
      DEVELOPMENT_PROVISIONING_MAPPING = :DEVELOPMENT_PROVISIONING_MAPPING # format "bunldeID => provisioning profile name"
      ENTERPRISE_PROVISIONING_MAPPING = :ENTERPRISE_PROVISIONING_MAPPING # format "bunldeID => provisioning profile name"
      APPSTORE_PROVISIONING_MAPPING = :APPSTORE_PROVISIONING_MAPPING # format "bunldeID => provisioning profile name"
      ENTITLEMENTS_FILE_PATH = :ENTITLEMENTS_FILE_PATH
      APP_DISPLAY_NAME = :APP_DISPLAY_NAME            #defaults to value of WORKSPACE_NAME

      # OPTIONAL - SONAR
      SONAR_SERVER_URL = :SONAR_SERVER_URL
      SONAR_PROJECT_KEY = :SONAR_PROJECT_KEY
      SONAR_PROJECT_NAME = :SONAR_PROJECT_NAME
      SONAR_EXCLUSIONS = :SONAR_EXCLUSIONS              #should be comma seperated
      SONAR_DO_NOT_ADD_GENERIC_EXCLUSIONS = :SONAR_DO_NOT_ADD_GENERIC_EXCLUSIONS #defaults to false
      SONAR_USE_CFAMILY_COVERAGE_PATH_ONLY = :SONAR_USE_CFAMILY_COVERAGE #defaults to false
      SONAR_DEFAULT_BRANCH_NAME = :SONAR_DEFAULT_BRANCH_NAME # defaults to master
      SONAR_TARGET_BRANCH_NAME = :SONAR_TARGET_BRANCH_NAME   # defaults to master
      CUSTOM_SONAR_SCANNER_EXECUTION_DIRECTORY = :CUSTOM_SONAR_SCANNER_EXECUTION_DIRECTORY #relative to fastlane execution directory

      # OPTIONAL - ARTIFACTORY
      ARTIFACTORY_REPO_PATH = :ARTIFACTORY_REPO_PATH  #defaults to 'prod-apps-ios/WORKSPACE_NAME'
      CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS = :CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS #defaults to false
      BRANCHES_FOR_ARTIFACTORY_UPLOAD = :BRANCHES_FOR_ARTIFACTORY_UPLOAD #branches for which to uplaod to artifactory; defaults to none
      USE_SCHEME_NAME = :USE_SCHEME_NAME
      ARTIFACTORY_REPO_PATH_PRODUCTION = :ARTIFACTORY_REPO_PATH_PRODUCTION #defaults to 'Workspace-ONE-iOS-SDK/'
      VMWARESAAS_ARTIFACT_REPO_USERNAME = :VMWARESAAS_ARTIFACT_REPO_USERNAME # defaults to 'w1-ios-sdk-rw-token'

      # OPTIONAL - SLACK
      SLACK_URL = :SLACK_URL
      SLACK_CHANNEL = :SLACK_CHANNEL
      BRANCHES_FOR_SLACK_UPDATES = :BRANCHES_FOR_SLACK_UPDATES #branches to send slack updates for (comma seperated)
      SLACK_BOT_NAME = :SLACK_BOT_NAME                         #defaults to name of project

      # GENERIC GENERATED CONSTANTS
      DERIVED_DATA_DIRECTORY = :DERIVED_DATA_DIRECTORY
      ARTIFACT_OUTPUT_DIRECTORY = :ARTIFACT_OUTPUT_DIRECTORY
      WORKING_DIRECTORY = :WORKING_DIRECTORY
      XCODE_VERSION = :XCODE_VERSION # generated using xcodebuild -version with provided DEVELOPER_DIR
      BUILD_RESULTS_URL = :BUILD_RESULTS_URL # geneated from environment variable on bamboo
    end

    class DetectEnvironmentInformationAction < Action
      @@default_Simulator_Runtime = '17-0'
      @@default_Simulator_DeviceType = 'iPhone-11'
      @@generic_Sonar_exclusions = "Pods/**,Test/**,SampleApps/**,SampleApp/**,Scripts/**,derivedData/**,artifacts/**,**.h"
      @@default_ArtifactoryRepo = 'prod-apps-ios/'

      def self.run(params)
        printSupportedENVVariables
        setUniversalConstants
        other_action.get_current_branch_name
        readMandatoryVariablesFromENVFIle
        other_action.check_xcode_version_existance
        readOptionalVariablesFromENVFIle
        createArtifactOutputDirectory
        setAutoGeneratedConstants #this must take place after WORKSPACE_SCHEME has been read in
      end

      # reads in the environment variables from the .env file that are condisidered mandatory
      def self.readMandatoryVariablesFromENVFIle
        UI.important("Reading Mandatory Variables From .env File...")
        Actions.lane_context[SharedValues::WORKSPACE_NAME] = readENVValue(key:'WORKSPACE_NAME', mandatory:true)
        Actions.lane_context[SharedValues::WORKSPACE_SCHEME] = readENVValue(key:'WORKSPACE_SCHEME', mandatory:true)
        Actions.lane_context[SharedValues::DEVELOPER_DIR] = readENVValue(key:'DEVELOPER_DIR', mandatory:true)
      end

      # reads in the environment variables from the .env file that are condisidered optional
      def self.readOptionalVariablesFromENVFIle
        UI.important("Reading optional Variables From .env File...")
        Actions.lane_context[SharedValues::SONAR_PROJECT_KEY] = readENVValue(key:'SONAR_PROJECT_KEY', mandatory:false)
        Actions.lane_context[SharedValues::SONAR_PROJECT_NAME] = readENVValue(key:'SONAR_PROJECT_NAME', mandatory:false)
        Actions.lane_context[SharedValues::SONAR_EXCLUSIONS] = readENVValue(key:'SONAR_EXCLUSIONS', mandatory:false)
        Actions.lane_context[SharedValues::CUSTOM_SONAR_SCANNER_EXECUTION_DIRECTORY] = readENVValue(key:'CUSTOM_SONAR_SCANNER_EXECUTION_DIRECTORY', mandatory:false)

        Actions.lane_context[SharedValues::CUSTOM_BINARY_FILEPATH] = readENVValue(key:'CUSTOM_BINARY_FILEPATH', mandatory:false)
        Actions.lane_context[SharedValues::SLACK_URL] = readENVValue(key:'SLACK_URL', mandatory:false)
        Actions.lane_context[SharedValues::SLACK_CHANNEL] = readENVValue(key:'SLACK_CHANNEL', mandatory:false)
        Actions.lane_context[SharedValues::BRANCHES_FOR_SLACK_UPDATES] = readENVValue(key:'BRANCHES_FOR_SLACK_UPDATES', mandatory:false)
        Actions.lane_context[SharedValues::BRANCHES_FOR_ARTIFACTORY_UPLOAD] = readENVValue(key:'BRANCHES_FOR_ARTIFACTORY_UPLOAD', mandatory:false)

        Actions.lane_context[SharedValues::DEVELOPMENT_PROVISIONING_MAPPING] = readENVValue(key:'DEVELOPMENT_PROVISIONING_MAPPING', mandatory:false)
        Actions.lane_context[SharedValues::ENTERPRISE_PROVISIONING_MAPPING] = readENVValue(key:'ENTERPRISE_PROVISIONING_MAPPING', mandatory:false)
        Actions.lane_context[SharedValues::APPSTORE_PROVISIONING_MAPPING] = readENVValue(key:'APPSTORE_PROVISIONING_MAPPING', mandatory:false)
        Actions.lane_context[SharedValues::ADHOC_PROVISIONING_MAPPING] = readENVValue(key:'ADHOC_PROVISIONING_MAPPING', mandatory:false)

        Actions.lane_context[SharedValues::EXPORT_OPTIONS_PLIST_ADHOC] = readENVValue(key:'EXPORT_OPTIONS_PLIST_ADHOC', mandatory:false)
        Actions.lane_context[SharedValues::EXPORT_OPTIONS_PLIST_DEVELOPMENT] = readENVValue(key:'EXPORT_OPTIONS_PLIST_DEVELOPMENT', mandatory:false)
        Actions.lane_context[SharedValues::EXPORT_OPTIONS_PLIST_APPSTORE] = readENVValue(key:'EXPORT_OPTIONS_PLIST_APPSTORE', mandatory:false)
        Actions.lane_context[SharedValues::EXPORT_OPTIONS_PLIST_ENTERPRISE] = readENVValue(key:'EXPORT_OPTIONS_PLIST_ENTERPRISE', mandatory:false)
        Actions.lane_context[SharedValues::GYM_XCARGS] = readENVValue(key:'GYM_XCARGS', mandatory:false)
        Actions.lane_context[SharedValues::SCAN_XCARGS] = readENVValue(key:'SCAN_XCARGS', mandatory:false)

        Actions.lane_context[SharedValues::ENTITLEMENTS_FILE_PATH] = readENVValue(key:'ENTITLEMENTS_FILE_PATH', mandatory:false)
        Actions.lane_context[SharedValues::SIGNING_IDENTITY] = readENVValue(key:'SIGNING_IDENTITY', mandatory:false)
        Actions.lane_context[SharedValues::BRANCH_NAME_FOR_POD_CREATION] = readENVValue(key:'BRANCH_NAME_FOR_POD_CREATION', mandatory:false)
        #Actions.lane_context[SharedValues::HTTPS_REPO_URL] = readENVValue(key:'HTTPS_REPO_URL', mandatory:false)
        Actions.lane_context[SharedValues::SSH_REPO_URL] = readENVValue(key:'SSH_REPO_URL', mandatory:false)

        Actions.lane_context[SharedValues::JAZZY_CONFIG_PATH] = readENVValue(key:'JAZZY_CONFIG_PATH', mandatory:false)
        Actions.lane_context[SharedValues::XSW_FRAMEWORK] = readENVValue(key:'XSW_FRAMEWORK', mandatory:false)

        Actions.lane_context[SharedValues::RID] = readENVValue(key:'RID', mandatory:false)
        Actions.lane_context[SharedValues::BID] = readENVValue(key:'BID', mandatory:false)
        Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME] = readENVValue(key:'SDK_XCFRAMEWORK_BINARY_NAME', mandatory:false,
          defaultValue:"AWSDK.xcframework")

        appcheckToken = Actions.sh("(echo ${bamboo_g_appcheck_secret_token}) || true", log: false)
        Actions.lane_context[SharedValues::APPCHECK_TOKEN] = appcheckToken.to_s.gsub("\n",'')

        vmwaresaasAuthToken = Actions.sh("(echo ${vmware_saas_artifact_auth_token}) || true", log: false)
        Actions.lane_context[SharedValues::VMWARESAAS_ARTIFACT_IOS_REPO_AUTH_TOKEN] = vmwaresaasAuthToken.to_s.gsub("\n",'')


        ## Optional variables with default values
        UI.important("Reading optional Variables that have a default Value From .env File...")
        Actions.lane_context[SharedValues::SIMULATOR_NAME] = readENVValue(key:'SIMULATOR_NAME', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKSPACE_SCHEME].to_s + "Simulator"
        )
        Actions.lane_context[SharedValues::POD_INSTALL_REQUIRED] = readENVValue(key:'POD_INSTALL_REQUIRED', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT] = readENVValue(key:'USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT', mandatory:false,
          defaultValue: false
        )
        Actions.lane_context[SharedValues::USE_MULTI_SCAN] = readENVValue(key:'USE_MULTI_SCAN', mandatory:false,
          defaultValue: false
        )
        Actions.lane_context[SharedValues::MULTI_SCAN_TRY_COUNT] = readENVValue(key:'MULTI_SCAN_TRY_COUNT', mandatory:false,
          defaultValue: 3
        )
        Actions.lane_context[SharedValues::MULTI_SCAN_BATCH_COUNT] = readENVValue(key:'MULTI_SCAN_TRY_COUNT', mandatory:false,
          defaultValue: 2
        )
        Actions.lane_context[SharedValues::SKIP_LINT_TESTS] = readENVValue(key:'SKIP_LINT_TESTS', mandatory:false,
          defaultValue: false
        )
        Actions.lane_context[SharedValues::RERUN_UNIT_TEST_COUNT] = readENVValue(key:'RERUN_UNIT_TEST_COUNT', mandatory:false,
          defaultValue:'0'
        )
        Actions.lane_context[SharedValues::BINARY_NAME] = readENVValue(key:'BINARY_NAME', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKSPACE_NAME].gsub(".xcodeproj",'').gsub(".xcworkspace",'')
        )
        Actions.lane_context[SharedValues::APP_DISPLAY_NAME] = readENVValue(key:'APP_DISPLAY_NAME', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKSPACE_NAME].gsub(".xcodeproj",'').gsub(".xcworkspace",'')
        )
        Actions.lane_context[SharedValues::FRAMEWORK_PROJECT] = readENVValue(key:'FRAMEWORK_PROJECT', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::SIMULATOR_RUNTIME] = readENVValue(key:'SIMULATOR_RUNTIME', mandatory:false,
          defaultValue:@@default_Simulator_Runtime
        )
        Actions.lane_context[SharedValues::SIMULATOR_DEVICE_TYPE] = readENVValue(key:'SIMULATOR_DEVICE_TYPE', mandatory:false,
          defaultValue:@@default_Simulator_DeviceType
        )
        Actions.lane_context[SharedValues::INFO_PLIST_PATH] = Actions.lane_context[SharedValues::WORKING_DIRECTORY] + "/" + readENVValue(key:'INFO_PLIST_PATH', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKSPACE_NAME].gsub(".xcodeproj",'').gsub(".xcworkspace",'')+"/Info.plist"
        )
        Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH] = readENVValue(key:'ARTIFACTORY_REPO_PATH', mandatory:false,
          defaultValue:@@default_ArtifactoryRepo+"/"+Actions.lane_context[SharedValues::WORKSPACE_NAME].gsub(".xcodeproj",'').gsub(".xcworkspace",'')
        )
        Actions.lane_context[SharedValues::CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS] = readENVValue(key:'CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::USE_SCHEME_NAME] = readENVValue(key:'USE_SCHEME_NAME', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH_PRODUCTION] = readENVValue(key:'ARTIFACTORY_REPO_PATH_PRODUCTION', mandatory:false,
          defaultValue:"Workspace-ONE-iOS-SDK/"
        )
        Actions.lane_context[SharedValues::SLACK_BOT_NAME] = readENVValue(key:'SLACK_BOT_NAME', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKSPACE_NAME].gsub(".xcodeproj",'').gsub(".xcworkspace",'')
        )
        Actions.lane_context[SharedValues::SONAR_SERVER_URL] = readENVValue(key:'SONAR_SERVER_URL', mandatory:false,
          defaultValue:"https://sonar.air-watch.com"
        )
        Actions.lane_context[SharedValues::SONAR_USE_CFAMILY_COVERAGE_PATH_ONLY] = readENVValue(key:'SONAR_USE_CFAMILY_COVERAGE_PATH_ONLY', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::SONAR_DO_NOT_ADD_GENERIC_EXCLUSIONS] = readENVValue(key:'SONAR_DO_NOT_ADD_GENERIC_EXCLUSIONS', mandatory:false,
          defaultValue:false
        )
        Actions.lane_context[SharedValues::SONAR_DEFAULT_BRANCH_NAME] = readENVValue(key:'SONAR_DEFAULT_BRANCH_NAME', mandatory:false,
          defaultValue:"master"
        )
        Actions.lane_context[SharedValues::SONAR_TARGET_BRANCH_NAME] = readENVValue(key:'SONAR_TARGET_BRANCH_NAME', mandatory:false,
          defaultValue:"master"
        )
        Actions.lane_context[SharedValues::ADHOC_CONFIGURATION] = readENVValue(key:'ADHOC_CONFIGURATION', mandatory:false,
          defaultValue:"Release"
        )
        Actions.lane_context[SharedValues::APPSTORE_CONFIGURATION] = readENVValue(key:'APPSTORE_CONFIGURATION', mandatory:false,
          defaultValue:"Release"
        )
        Actions.lane_context[SharedValues::ENTERPRISE_CONFIGURATION] = readENVValue(key:'ENTERPRISE_CONFIGURATION', mandatory:false,
          defaultValue:"Release"
        )
        Actions.lane_context[SharedValues::DEVELOPMENT_CONFIGRUATION] = readENVValue(key:'DEVELOPMENT_CONFIGRUATION', mandatory:false,
          defaultValue:"Debug"
        )
        Actions.lane_context[SharedValues::VERSION_DIGIT_TO_BUMP] = readENVValue(key:'VERSION_DIGIT_TO_BUMP', mandatory:false,
          defaultValue:"minor"
        )
        Actions.lane_context[SharedValues::JAZZY_OUTPUT_NAME] = readENVValue(key:'JAZZY_OUTPUT_NAME', mandatory:false,
          defaultValue:"docs"
        )
        Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH] = readENVValue(key:'SWIFT_PACKAGE_FOLDER_PATH', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKING_DIRECTORY] + "/swiftpackage/workspaceonesdk-package"
        )
        Actions.lane_context[SharedValues::PUBLIC_SPM_REPO_PATH] = readENVValue(key:'PUBLIC_SPM_REPO_PATH', mandatory:false,
          defaultValue:Actions.lane_context[SharedValues::WORKING_DIRECTORY] + "/publicSwiftRepo/iOS-WorkspaceONE-SDK"
        )
        Actions.lane_context[SharedValues::PUBLIC_SPM_REPO_GIT_URL] = readENVValue(key:'PUBLIC_SPM_REPO_GIT_URL', mandatory:false,
          defaultValue:"@github.com/vmwareairwatchsdk/iOS-WorkspaceONE-SDK.git"
        )
        Actions.lane_context[SharedValues::PUBLIC_SPM_REPO_README_FILE_NAME] = readENVValue(key:'PUBLIC_SPM_REPO_README_FILE_NAME', mandatory:false,
          defaultValue:"WS1SDK-Package-README.md"
        )
        Actions.lane_context[SharedValues::SWIFT_PACKAGE_TEMPLATE_REPOSITORY_ORIGIN_URL] = readENVValue(key:'SWIFT_PACKAGE_TEMPLATE_REPOSITORY_ORIGIN_URL', mandatory:false,
          defaultValue:"https://stash-iossdk-svc:DFgJJk0LjN87@stash.air-watch.com/scm/isdkl/workspaceonesdk-package.git"
        )
        Actions.lane_context[SharedValues::VMWARESAAS_ARTIFACT_REPO_USERNAME] = readENVValue(key:'VMWARESAAS_ARTIFACT_REPO_USERNAME', mandatory:false,
          defaultValue:"w1-ios-sdk-rw-token"
        )
      end

      # read value for params[:key] from the .env file
      # if params[:mandatory] is true, fail fastlane execution if value is not found
      # if params[:defaultValue] is provided, the default value will be assigned if value is not found
      def self.readENVValue(params)
        value = ENV[params[:key]]
        UI.message("Reading ENV Value for Key: " + params[:key] + " Value Found: " + value.to_s)
        if value.to_s.empty? #if nil or empty
          if params.has_key?(:defaultValue)
            value = params[:defaultValue]
            UI.message("Assigning default value of " + value.to_s + " for Key: " + params[:key])
          end
          if params[:mandatory]
            UI.user_error!("Mandatory .env value: " + params[:key] + " was not found in .env file")
          end
        end
        return value
      end

      # set shared values that are universal constants and should not need to be changed
      def self.setUniversalConstants
        Actions.lane_context[SharedValues::WORKING_DIRECTORY] = Actions.sh('pwd', log: false).to_s.gsub("\n",'')
        Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY] = Actions.lane_context[SharedValues::WORKING_DIRECTORY] + "/derivedData"
        Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY] = Actions.lane_context[SharedValues::WORKING_DIRECTORY] + "/artifacts"
        ENV["FASTLANE_XCODEBUILD_SETTINGS_TIMEOUT"] = "30"
        ENV["FASTLANE_XCODEBUILD_SETTINGS_RETRIES"] = "5"
      end

      # set the automatically generated constants
      def self.setAutoGeneratedConstants
        UI.important("Checking for existance of plist in the location provided in env file: " + Actions.lane_context[SharedValues::INFO_PLIST_PATH].shellescape + "...")
        if !File.exist?(Actions.lane_context[SharedValues::INFO_PLIST_PATH])
          UI.user_error!("No plist was found in the directory provided in the .env file: "+ Actions.lane_context[SharedValues::INFO_PLIST_PATH].shellescape + "; \n
            Please provide correct path to the plist file. Failing fastlane execution...")
        end
        UI.success("plist file exists in the location provided in env file")
        # VERSION_NUMBER and BUILD_NUMBER dont need to be declared at top of file as they are initialized by fastlane as it starts up
        Actions.lane_context[SharedValues::VERSION_NUMBER] = Actions.sh("/usr/libexec/PlistBuddy -c \"Print :CFBundleShortVersionString\" "+ Actions.lane_context[SharedValues::INFO_PLIST_PATH].shellescape, log: true).gsub("\n",'')

        buildNumber = Actions.sh("/usr/libexec/PlistBuddy -c \"Print :CFBundleVersion\" "+ Actions.lane_context[SharedValues::INFO_PLIST_PATH].shellescape, log: true).gsub("\n",'')
        if buildNumber.include? '$('
          buildNumber = "0" #default if the user forgot to set the build number in their bamboo plan
        end
        Actions.lane_context[SharedValues::BUILD_NUMBER] = buildNumber

        Actions.lane_context[SharedValues::XCODE_VERSION] = Actions.sh("xcodebuild -version", log: false).split(/\n+/).first.strip

        bambooResultsURL = Actions.sh("(echo ${buildResultsUrl}) || true", log: true).strip
        if (bambooResultsURL.include? 'bad substitution') ||  (bambooResultsURL.to_s.empty?)
          bambooResultsURL = "null"
        end
        Actions.lane_context[SharedValues::BUILD_RESULTS_URL] = bambooResultsURL

        # add generic exclusions to sonar exclusion list
        if Actions.lane_context[SharedValues::SONAR_DO_NOT_ADD_GENERIC_EXCLUSIONS]
          UI.message("Skipping the addition of the generic sonar exclusions...")
        else
          UI.message("Adding the following generic sonar exclusions: " + @@generic_Sonar_exclusions)
          Actions.lane_context[SharedValues::SONAR_EXCLUSIONS] = @@generic_Sonar_exclusions + "," + Actions.lane_context[SharedValues::SONAR_EXCLUSIONS].to_s
        end
      end

      # create the artifact output directory and the derived Data directory
      # if the directory does not already exist to prevent
      # failure in actions writing artifacts to these directory
      # Scecifically the build wrapper for sonar will fail if derivedData directory isnt created
      # BEFORE the xcode build command is issued
      def self.createArtifactOutputDirectory
        Actions.sh("mkdir -p " + Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY])
        Actions.sh("mkdir -p " + Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY])
      end

      # print out the current list of supported environment variables that this action can
      # read in and add to the lane_context
      def self.printSupportedENVVariables
        UI.header("-----Supported .env varibles-----\n
            -----MANDATORY VARIABLES-----\n
            WORKSPACE_NAME  (Should include .xcodeproj or .xcworkspace)\n
            WORKSPACE_SCHEME\n
            DEVELOPER_DIR\n

            -----OPTIONAL VARIABLES-----\n
            SIMULATOR_NAME (defaults to {WORKSPACE_SCHEME}Simulator)\n
            SIMULATOR_RUNTIME (defaults to "+@@default_Simulator_Runtime+")\n
            SIMULATOR_DEVICE_TYPE (defaults to "+@@default_Simulator_DeviceType+")\n
            FRAMEWORK_PROJECT (defaults to false)\n
            POD_INSTALL_REQUIRED (defaults to false)\n
            BRANCH_NAME_FOR_POD_CREATION (the branch for which new podspec versions will be pushed)\n
            VERSION_DIGIT_TO_BUMP (major, minor, or patch; defaults to minor)\n
            #HTTPS_REPO_URL (This is only needed for automatic podspec creation)\n
            SSH_REPO_URL (This is only needed for automatic podspec creation)\n
            USE_STATIC_FRAMEWORKS_FOR_PODSPEC_LINT (If the podsepc linter should use static libraries option; defaults to false) \n
            RERUN_UNIT_TEST_COUNT (defaults to 0)\n
            BINARY_NAME (defaults to value of WORKSPACE_SCHEME, should not include .app or .frameowork with name)\n
            CUSTOM_BINARY_FILEPATH (custom path for binary needed for sonar reporting ~NOT RECOMMENDED~)\n
            INFO_PLIST_PATH (defaults to value of WORKSPACE_NAME/info.plist)\n
            FRAMEWORK_PROJECT (defaults to false)\n
            ADHOC_CONFIGURATION (defaults to Release)\n
            DEVELOPMENT_CONFIGRUATION (defaults to Debug)\n
            APPSTORE_CONFIGURATION (defaults to Release)\n
            ENTERPRISE_CONFIGURATION (defaults to Release)\n

            EXPORT_OPTIONS_PLIST_ADHOC \n
            EXPORT_OPTIONS_PLIST_DEVELOPMENT \n
            EXPORT_OPTIONS_PLIST_APPSTORE \n
            EXPORT_OPTIONS_PLIST_ENTERPRISE \n
            GYM_XCARGS \n
            SCAN_XCARGS \n
            USE_MULTI_SCAN \n
            MULTI_SCAN_TRY_COUNT  (defaults to 3)\n
            MULTI_SCAN_BATCH_COUNT (defaults to 2)\n
            DISABLE_OBJC_WRAPPER (defaults to false)\n

            JAZZY_CONFIG_PATH \n
            JAZZY_OUTPUT_NAME (DEFAULTS TO `docs`)\n

            -----OPTIONAL VARIABLES: SIGNING-----\n
            SIGNING_IDENTITY\n
            ADHOC_PROVISIONING_MAPPING (format \"bunldeID => provisioning profile name\")\n
            DEVELOPMENT_PROVISIONING_MAPPING (format \"bunldeID => provisioning profile name\")\n
            ENTERPRISE_PROVISIONING_MAPPING (format \"bunldeID => provisioning profile name\")\n
            APPSTORE_PROVISIONING_MAPPING (format \"bunldeID => provisioning profile name\")\n
            ENTITLEMENTS_FILE_PATH\n
            APP_DISPLAY_NAME (defaults to value of WORKSPACE_NAME)\n

            -----OPTIONAL VARIABLES: SONAR-----\n
            SONAR_SERVER_URL (Defaults to https://sonar.air-watch.com)\n
            SONAR_PROJECT_KEY\n
            SONAR_PROJECT_NAME\n
            SONAR_EXCLUSIONS (should be comma seperated)\n
            SONAR_USE_CFAMILY_COVERAGE_PATH_ONLY (use the cfamily coverage report tool instead of swift; defaults to false)\n
            SONAR_DEFAULT_BRANCH_NAME(defaults to master)\n
            SONAR_TARGET_BRANCH_NAME (defaults to master)\n
            CUSTOM_SONAR_SCANNER_EXECUTION_DIRECTORY (relative to fastlane execution directory)\n

            -----OPTIONAL VARIABLES: ARTIFACTORY-----\n
            ARTIFACTORY_REPO_PATH (defaults to 'prod-apps-ios/WORKSPACE_NAME')\n
            BRANCHES_FOR_ARTIFACTORY_UPLOAD (branches for which to uplaod to artifactory) (defaults to none)\n
            CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS (defaults to false)\n
            ARTIFACTORY_REPO_PATH_PRODUCTION (defaults to 'Workspace-ONE-iOS-SDK/')\n

            -----OPTIONAL VARIABLES: SLACK-----\n
            SLACK_URL\n
            SLACK_CHANNEL\n
            SLACK_BOT_NAME (defaults to name of project)\n
            BRANCHES_FOR_SLACK_UPDATES (branches for which to send slack updates)")
      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Reads in environment variables from .env file and adds them to lane_context."
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
