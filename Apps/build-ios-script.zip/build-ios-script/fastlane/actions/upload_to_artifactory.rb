module Fastlane
  module Actions
    module SharedValues
      UPLOADED_ARTIFACTORY_ARTIFACT_URL = :UPLOADED_ARTIFACTORY_ARTIFACT_URL
    end

    class UploadToArtifactoryAction < Action
      @@artifactoryURL = 'https://artifactory.abc.com/artifactory/'
      @@artifactoryUsername = 'deployer'
      @@artifactoryPassword = 'AP2N7ob4YK1FedaGuYrBJ3Wsddr'

      def self.run(params)
        unless currentBranchIsRegisteredForArtifactoryUpload
          UI.message("Skipping artifactory upload...")
          return
        end

        localPathToArtifact = params[:localPathToArtifact]
        destination_repo_path = params[:destination_repo_path] #prod-apps-ios/ISDK/
        artifact_folder_path = params[:artifactFolderName] #based on branch ??
        artifactName = params[:artifactName] # AWSDK.xcframework
        copyToLatestFolder = params[:copyToLatestFolder]
        currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        taggedBuildID = Actions.lane_context[SharedValues::VERSION_NUMBER].to_s.gsub("\n",'') + '.' + Actions.lane_context[SharedValues::BUILD_NUMBER].to_s.gsub("\n",'')
        artifactoryRepoPath = destination_repo_path+"/"+currentBranch+"/"+taggedBuildID+"/"+artifactName # Path to place the artifact including its filename
        if (artifact_folder_path.nil? || artifact_folder_path.empty?) == false
            artifactoryRepoPath = destination_repo_path+"/"+currentBranch+"/"+taggedBuildID+"/"+artifact_folder_path+"/"+artifactName # Path to place the artifact including its filename
            artifactoryRepoPath = artifactoryRepoPath.gsub("//", "/") #remove any double slashes
        end
        
        UI.message("localPathToArtifact = " + localPathToArtifact)
        UI.message("destination_repo_path = " + destination_repo_path)
        UI.message("taggedBuildID = " + taggedBuildID)
        UI.message("currentBranch = " + currentBranch)
        UI.message("Artifactory destination path will be " + artifactoryRepoPath)
        uploadArtifact(
          pathToArtifact: localPathToArtifact,
          destination_repo_path: artifactoryRepoPath,
          currentBranch: currentBranch,
          taggedBuildID: taggedBuildID
        )
        if copyToLatestFolder #should also upload copy to the latest folder
          UI.header('Also uploading to latest folder as well')
          artifactoryRepoPath = destination_repo_path+"/"+currentBranch+"/latest/"+artifactName # Path to place the artifact including its filename
          if (artifact_folder_path.nil? || artifact_folder_path.empty?) == false
          artifactoryRepoPath = destination_repo_path+"/"+currentBranch+"/latest/"+artifact_folder_path+"/"+artifactName # Path to place the artifact including its filename
          artifactoryRepoPath = artifactoryRepoPath.gsub("//", "/") #remove any double slashes
          end
          UI.message("Aritfactory destination path will be " + artifactoryRepoPath)
          UI.message("First attempting to delete any object matching this name in latest folder so that the created date will be updated")
          deleteArtifact(destination_repo_path:artifactoryRepoPath) #delete artfict in latest folder if it exists
          uploadArtifact(
            pathToArtifact: localPathToArtifact,
            destination_repo_path: artifactoryRepoPath,
            currentBranch: currentBranch,
            taggedBuildID: taggedBuildID
          )
          UI.important("Updating lastModifiedDate of latest folder...")
          lastestFolderArtifcatoryRepoPath = destination_repo_path+"/"+currentBranch+"/latest/"
          lastModifiedDateCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X PUT "+@@artifactoryURL+"api/storage/"+lastestFolderArtifcatoryRepoPath+"?properties=modifedDate=\"" + Time.now.to_s.gsub(" ","_") + "\""
          UI.important("lastModifiedDateCommand  = " + lastModifiedDateCommand)
          Actions.sh(lastModifiedDateCommand, log:true)
        end

        # clean up action will print out the values it would delete if env variable is set to false
        other_action.cleanup_artifactory_artifacts(
          destination_repo_path: params[:destination_repo_path]
        )
      end

      # upload the artifact to artifactory with the provided params
      # assigns 2 properties to the artifact that it uploads (1) a buildID and
      # (2) the name of the current branch
      def self.uploadArtifact(params)
        uploadCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -T "+params[:pathToArtifact]+" "+@@artifactoryURL+params[:destination_repo_path]
        UI.important("Upload command = " + uploadCommand)
        Actions.sh(uploadCommand, log:true)
        addIDPropertyCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X PUT "+@@artifactoryURL+"api/storage/"+params[:destination_repo_path]+"?properties=taggedBuildID="+params[:taggedBuildID]
        addBranchPropertyCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X PUT "+@@artifactoryURL+"api/storage/"+params[:destination_repo_path]+"?properties=currentBranch="+params[:currentBranch]

        currentGITCommitHash = Actions.sh("git rev-parse HEAD").strip
        currentGITCommitTimeStamp = Actions.sh("git show -s --format=%ci " + currentGITCommitHash).gsub(" ","_")
        currentGITCommitHashCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X PUT "+@@artifactoryURL+"api/storage/"+params[:destination_repo_path]+"?properties=currentGITCommitHash="+currentGITCommitHash
        currentGITCommitTimeStampCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X PUT "+@@artifactoryURL+"api/storage/"+params[:destination_repo_path]+"?properties=currentGITCommitTimeStamp="+currentGITCommitTimeStamp
        UI.important("addIDPropertyCommand  = " + addIDPropertyCommand)
        UI.important("addBranchPropertyCommand  = " + addBranchPropertyCommand)
        Actions.sh(addIDPropertyCommand, log:true)
        Actions.sh(addBranchPropertyCommand, log:true)
        Actions.sh(currentGITCommitHashCommand, log:true)
        Actions.sh(currentGITCommitTimeStampCommand, log:true)
      end

      # deletes any artifacts found at the [destination_repo_path] on the artifactory server.
      # this is used to delete the contents of the latests folder before uploading a new artifact to it
      # so that the "created date" on the latests artfact will be reset every time a new artifact is uploaded
      # this will help avoid confusion when someone is downloading the artifact and sees and old "created date"
      def self.deleteArtifact(params)
        deleteCommand = "curl -u "+@@artifactoryUsername+":"+@@artifactoryPassword+" -X DELETE "+@@artifactoryURL+params[:destination_repo_path]
        UI.message("deleteCommand = "+ deleteCommand)
        Actions.sh(deleteCommand, log:true)
      end

      # To prevent artifactory uploads on every single feature branch the current branch
      # must be registered in order fo the artifact to be uploaded.
      # This method checks the env value BRANCHES_FOR_ARTIFACTORY_UPLOAD and if current branch
      # is registered it returns true; false otherwise
      def self.currentBranchIsRegisteredForArtifactoryUpload
        if Actions.lane_context[SharedValues::BRANCHES_FOR_ARTIFACTORY_UPLOAD] == nil
          UI.important("There are no registered branches for artifactory upload. Skipping this step...")
          return
        end
        branches = Actions.lane_context[SharedValues::BRANCHES_FOR_ARTIFACTORY_UPLOAD].split(",")
        currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        UI.message("Checking to see if currentBranch ("+currentBranch.to_s+") is registered to upload to artifactory...")
        branches.each { |registeredBranch|
          if (registeredBranch.to_s.include? currentBranch) ||  (currentBranch.to_s.include? registeredBranch)
            UI.important("Current branch ("+currentBranch.to_s+") is registered for artifactory upload. Matched registeredBranch: " + registeredBranch.to_s)
            return true
          end
          if (registeredBranch.to_s.include? "ALL_BRANCHES")
            UI.important("ALL_BRANCHES are currently registered for artifactory upload.")
            return true
          end
        }
        UI.important("Current branch ("+currentBranch.to_s+") is not registered for artifactory upload.\n\t"+
        "The currently registered branches include: \n\t\t" +branches.to_s)
        return false
      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :localPathToArtifact,
                                       env_name: "FL_UPLOAD_TO_ARTIFACTORY_LOCAL_PATH_TO_ARTIFACT", # The name of the environment variable
                                       description: "localPathToArtifact", # a short description of this parameter
                                       optional: false,
                                       is_string: true),
          FastlaneCore::ConfigItem.new(key: :destination_repo_path,
                                        env_name: "FL_UPLOAD_TO_ARTIFACTORY_DESTINATION_REPO_PATH", # The name of the environment variable
                                        description: "destination_repo_path", # a short description of this parameter
                                        optional: false,
                                        is_string: true),
          FastlaneCore::ConfigItem.new(key: :artifactName,
                                       env_name: "FL_UPLOAD_TO_ARTIFACTORY_ARTIFACT_NAME",
                                       description: "artifactName",
                                       optional: false,
                                       is_string: true),
         FastlaneCore::ConfigItem.new(key: :copyToLatestFolder,
                                      env_name: "FL_UPLOAD_TO_ARTIFACTORY_COPY_TO_LATEST_FOLDER",
                                      description: "artifactName",
                                      optional: true,
                                      is_string: false,
                                      default_value: true), # the default value if the user didn't provide one)
         FastlaneCore::ConfigItem.new(key: :artifactFolderName,
                                      env_name: "FL_UPLOAD_TO_ARTIFACTORY_ARITIFACT_FOLDER_NAME",
                                      description: "artifactFolderName",
                                      optional: true,
                                      is_string: true,
                                      default_value: "") # the default value if the user didn't provide one)
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
