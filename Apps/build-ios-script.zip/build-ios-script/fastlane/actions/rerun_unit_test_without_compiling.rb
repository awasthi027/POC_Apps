module Fastlane
  module Actions
    module SharedValues
      RERUN_UNIT_TEST_WITHOUT_COMPILING_CUSTOM_VALUE = :RERUN_UNIT_TEST_WITHOUT_COMPILING_CUSTOM_VALUE
    end

    class RerunUnitTestWithoutCompilingAction < Action
      def self.run(params)
        UI.message("Rerunning unit test without re-compiling: (" + Actions.lane_context[SharedValues::RERUN_UNIT_TEST_COUNT] + ") times")
        numberOfTimesToReRun = Integer(Actions.lane_context[SharedValues::RERUN_UNIT_TEST_COUNT])
        puts "numberOfTimesToReRun " + numberOfTimesToReRun.to_s
        count = 0
        while count < numberOfTimesToReRun
          UI.header("Rerunning unit test without re-compiling... Iteration # " + count.to_s)
          runUnitTests
          UI.header("Completed rerunning unit test without re-compiling. Iteration # " + count.to_s)
          count += 1
        end
        UI.success("Finished reruning unit tests.")
      end

      def self.runUnitTests
        pathToProjectFile = Actions.lane_context[SharedValues::WORKING_DIRECTORY]+"/"+Actions.lane_context[SharedValues::WORKSPACE_NAME]
        if Actions.lane_context[SharedValues::WORKSPACE_NAME].include? ".xcodeproj"
          testProjct(pathToProjectFile: pathToProjectFile)
        else
          testWorkspace(pathToProjectFile: pathToProjectFile)
        end
      end

      # wrapper around fastlane's scan action specifying project is a workspace and
      # uses the env varialbes provided.
      def self.testWorkspace(params)
        other_action.scan(
          workspace: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          clean: false,
          code_coverage: true,
          output_types: 'junit',
          output_files: 'junit-report.xml',
          fail_build: false,
          test_without_building: true,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      # wrapper around fastlane's scan action specifying project is a xcodeproj and
      # uses the env varialbes provided.
      def self.testProjct(params)
        other_action.scan(
          project: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          clean: false,
          code_coverage: true,
          output_types: 'junit',
          output_files: 'junit-report.xml',
          fail_build: true,
          test_without_building: true,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Runs unit test multiple time to attempt to catch intermittendly failing Unit Tests."
      end

      def self.details
        "In order to prevent intermittantly failing Unit tests, this action will
         re-run the unit test without re-compiling the application/framework
         the number of times it will re-run the unit tests can be set in the
          .env file using the environment variable: RERUN_UNIT_TEST_COUNT"
      end

      def self.is_supported?(platform)
        platform == :ios
      end
    end
  end
end
