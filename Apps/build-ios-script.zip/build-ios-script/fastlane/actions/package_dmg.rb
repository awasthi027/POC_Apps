module Fastlane
  module Actions
    module SharedValues
      PACKAGE_DMG_CUSTOM_VALUE = :PACKAGE_DMG_CUSTOM_VALUE
    end

    class PackageDmgAction < Action

      def self.run(params)
        currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        other_action.download_latest_ios_sdk_frameworks_from_artifactory(branchName:currentBranch.to_s)
        organizeFrameworkFilesIntoSingleFolder
        moveLicenseAndAcknowledgementsToArtifactsFolder
        selectProperSDKDocumentation
        moveSampleAppToArtifactsFolder
        replaceFrameworkFilesInSampleApp
        compliationCheckForSampleApp

        moveDMGGeneratorResourcesToArtifactsFolder
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        Actions.sh("(cd "+ artifactsDirectory+"; ls)")
        Actions.sh("(cd "+ artifactsDirectory+"; dmgbuild -s dmgFormatTemplate.py \"VMwareWorkspaceONESDK\" \"VMwareWorkspaceONESDK.dmg\")")
      end

      def self.organizeFrameworkFilesIntoSingleFolder
        UI.important('Organizing framework files into a single folder...')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s

        Actions.sh(" mkdir -p " + artifactsDirectory + "/Frameworks/")
        UI.message("seaching for file names matching with .zip extension...")

        zipfilesFound = 0
        Dir.glob("**/*.zip") { |file|
          UI.message("Found file named = " + file)
          if file.include? "Frameworks"
            Actions.sh("unzip " + file + " -d "+ artifactsDirectory + "/Frameworks/ 2>&1 > /dev/null", log:true)
            Actions.sh("rm -f " + file + " 2>&1 > /dev/null", log:true)
            if zipfilesFound == 0 # only copy first zip file artifacts to base artifacts folder so that it can be used in example app
              Actions.sh("cp -a " + artifactsDirectory + "/Frameworks/Frameworks-*/AWSDK.framework " + artifactsDirectory + "/AWSDK.framework", log:true)
              Actions.sh("cp -a " + artifactsDirectory + "/Frameworks/Frameworks-*/AWCMWrapper.framework " + artifactsDirectory + "/AWCMWrapper.framework", log:true)
            end
            zipfilesFound += 1
          else
            UI.message("File named: " + file + " does not include Frameworks in name and will therefore be deleted.")
            Actions.sh("rm -rf " + file)
          end
        }
        # if there is more than 1 set of .zip files that means there is multiple compiled sdk versions
        # and they will be seperated into different folders with swift version; if not this will
        # move framework files up into parent "Frameworks" folder
        if zipfilesFound == 1
            Actions.sh("cp -a " + artifactsDirectory + "/Frameworks/Frameworks-*/AWSDK.framework " + artifactsDirectory + "/Frameworks/AWSDK.framework", log:true)
            Actions.sh("cp -a " + artifactsDirectory + "/Frameworks/Frameworks-*/AWCMWrapper.framework " + artifactsDirectory + "/Frameworks/AWCMWrapper.framework", log:true)
            Actions.sh("rm -rf " + artifactsDirectory + "/Frameworks/Frameworks-*/ 2>&1 > /dev/null")
        elsif zipfilesFound == 0
            UI.user_error!("Failed to locate any frameworks for this dmg packaging")
        end
        Actions.sh("rm -rf -v " + artifactsDirectory + "/Frameworks/*/*.dSYM 2>&1 > /dev/null")
        Actions.sh("rm -rf -v " + artifactsDirectory + "/Frameworks/*.dSYM 2>&1 > /dev/null")
        UI.success("Framework files organized into single folder. Moved "+ zipfilesFound.to_s+ " zip files")
      end

      # Moves the license and the Acknowledgements files from the working directory
      # into the artifact directory so that they can be added to the DMG.
      def self.moveLicenseAndAcknowledgementsToArtifactsFolder
        UI.important('Moving license and Acknowledgements files to artifacts folder...')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
        Actions.sh("cp -a -v "+workingDirectory+"/LICENSE.txt " + artifactsDirectory + "/LICENSE.txt") #LICENSE file
        Actions.sh("cp -a -v "+workingDirectory+"/Acknowledgements.txt " + artifactsDirectory + "/Acknowledgements.txt") #Acknowledgements file
        UI.success('Finshed moving license and Acknowledgements files to artifacts folder.')
      end

      # Attempts to determine the proper SDK Documentation version form the pdf's
      # stored in the resources folder based off of current branch name, if it fails to
      # find matching documentation it defaults to the default pdf
      def self.selectProperSDKDocumentation
        UI.important('Selecting proper documentation file')
      	currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        desiredFileName = "fastlane/resources/Documentation/" + currentBranch + ".pdf"
        Actions.sh("ls fastlane/resources/Documentation/")

        if File.exist?(desiredFileName)
          UI.message("Found Documentation matching branch named: " + desiredFileName)
          Actions.sh("cp -a -v " + desiredFileName + " " + artifactsDirectory + "/\"VMware Workspace ONE SDK.pdf\"", log: true)
        else
          UI.important("Could not find documentation maching branch name(" + currentBranch.to_s + "); Grabbing default documentation file (18.4)")
          Actions.sh("cp -a -v fastlane/resources/Documentation/release-18.4.pdf "+ artifactsDirectory + "/\"VMware Workspace ONE SDK.pdf\"", log: true)
        end
      end

      # Moves all of the required resources needed for the dmg cfeation into the
      # artifacts folder where the DMG generator will be expecting it to be.
      # The resourses include: formatTemplate.json, background.png, and dmgIcon.icns
      def self.moveDMGGeneratorResourcesToArtifactsFolder
        UI.important('Moving DMG Generator Resources To Artifacts Folder')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        Actions.sh("cp -a -v fastlane/resources/dmgFormatTemplate.py "+ artifactsDirectory+"/dmgFormatTemplate.py")
        Actions.sh("cp -a -v fastlane/resources/background.png "+ artifactsDirectory+"/background.png")
        Actions.sh("cp -a -v fastlane/resources/dmgIcon.icns "+ artifactsDirectory+"/dmgIcon.icns")
      end

      # Copies the SDKExampleApplication form the SampleApps directory inside the
      # AirWatchSDK repo into the artifacts folder where it can then be used for compilation
      # testing and for packaging into a dmg if the package_dmg action is later run
      def self.moveSampleAppToArtifactsFolder
        UI.important('Moving sample application to artifacts folder')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        Actions.sh("cp -a SampleApps/SDKExampleApplication " + artifactsDirectory + "/SDKExampleApplication", log:true)
      end

      # Deletes the old AirWatchSDK frameworks out of the SDKExampleApplication and
      # replaces them with the framework files found in the artifacts directory
      # Precondition - the SampleApp must have been moved to the artifacts directory
      def self.replaceFrameworkFilesInSampleApp
        UI.important('replacing old frameworks with those from artifacts folder')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        #delete old framework files from directory
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWSDK.framework",log:true)
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWCMWrapper.framework",log:true)
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/3.2/AWSDK.framework",log:true)
        Actions.sh("rm -rf " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/3.2/AWCMWrapper.framework",log:true)
        Actions.sh("mkdir -p " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/")
        #copy new framework files into directory
        Actions.sh("cp -a " + artifactsDirectory + "/AWSDK.framework " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWSDK.framework", log:true)
        Actions.sh("cp -a " + artifactsDirectory + "/AWCMWrapper.framework " + artifactsDirectory + "/SDKExampleApplication/SDKExampleApplication/Frameworks/AWCMWrapper.framework", log:true)
        Actions.sh("(cd "+artifactsDirectory+"/SDKExampleApplication/SDKExampleApplication/Frameworks/; ls)")
      end

      # Check that the sample app we have placed in the DMG will compiled.
      # Fail fastlane execution if it fails to compile.
      def self.compliationCheckForSampleApp
        UI.important("Begining compiliation check for the sample application...")
        #TODO::
        UI.success("Completed compiliation check for the sample application.")
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Package SDK frameworks, Docs, Sample App into a dmg"
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
