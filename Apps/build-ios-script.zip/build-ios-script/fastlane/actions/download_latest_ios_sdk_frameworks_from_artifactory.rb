module Fastlane
  module Actions
    module SharedValues
        # Shared value to save AWSDK.xcframework.zip artificat url to download (used to update Internal-Package.swift file)
        SDK_XCFRAMEWORK_DOWNLOAD_URI = :SDK_XCFRAMEWORK_DOWNLOAD_URI
    end

    class DownloadLatestIosSdkFrameworksFromArtifactoryAction < Action
      @@artifactoryURL = 'https://artifactory.abc.com/artifactory/'
      @@artifactoryUsername = 'deployer'
      @@artifactoryPassword = 'AP2N7ob4YK1FedaGuYrBJ3W8sd'

      def self.run(params)
        desiredBranchName = params[:branchName]
        artifactoryRepoPath = params[:artifactoryRepoPath]
        artifactoryRepoPath = (artifactoryRepoPath.nil? || artifactoryRepoPath.to_s.empty?) ? "prod-apps-ios/ISDK/" : artifactoryRepoPath
        artifactDownloadURL = "https://artifactory.air-watch.com/artifactory/api/storage/"+artifactoryRepoPath+"snapshots/"+desiredBranchName.to_s+"/latest/"
        downloadLatestFromArtifactory(artifactoryRepoPath: artifactDownloadURL)
      end

      # Downloads the latest SDK ThirdPartyRelease frameworks from artifactory
      def self.downloadLatestFromArtifactory(params)
        UI.important('Downloading Frameworks from Artifactory')
        artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
        url = params[:artifactoryRepoPath]
        uri = URI(url)
        response = Net::HTTP.get(uri)
        jsonResult = JSON.parse(response)
        downloadURI = jsonResult['uri'].gsub('api/storage/','')
        UI.message ("downloadURI  " + downloadURI)
        children = jsonResult['children']
        UI.message ("children = " + children.to_s)
        children.each do |child|
          childUri = child['uri'].gsub('/','')
          # updated to download SDK zip inside Frameworks-Xcode folder
          if child['folder'] == true
            # URL consstruct to framework inside folder eg: Frameworks-Xcode/AWSDK.xcframework.zip
            binaryFrameworkPath = "/" + Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME] + ".zip"
            binaryDownloadUri = downloadURI+"/"+childUri+binaryFrameworkPath
            Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_DOWNLOAD_URI] = binaryDownloadUri
            downloadCommand = "curl -u " + @@artifactoryUsername+":"+@@artifactoryPassword+" "+binaryDownloadUri+" --output " +artifactsDirectory+binaryFrameworkPath
            Actions.sh(downloadCommand, log:true)
          elsif !childUri.include? ".dmg"
            downloadCommand = "curl -u " + @@artifactoryUsername+":"+@@artifactoryPassword+" "+downloadURI+"/"+childUri+" --output " +artifactsDirectory+"/"+childUri
            Actions.sh(downloadCommand, log:true)
          end
        end
        UI.success("Finisheds downloading latest frameworks from artifactory.")
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Downloads the latest frameworks and puts them into the Artifact Directory
        so that they may be used by other actions"
      end

      def self.details
        "This action takes the provided branch name and downloads the latest
        SDK Frameworks off of artifactory under the matching branch name if any
        currently exist."
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :branchName,
                                       env_name: "FL_DOWNLOAD_LATEST_IOS_SDK_FRAMEWORKS_FROM_ARTIFACTORY_BRANCH_NAME",
                                       description: "The branch name of the SDK of which to download latest frameworks",
                                       is_string: true), # true: verifies the input is a string, false: every kind of value
          FastlaneCore::ConfigItem.new(key: :artifactoryRepoPath,
                                       env_name: "FL_DOWNLOAD_LATEST_IOS_SDK_FRAMEWORKS_FROM_ARTIFACTORY_REPO_PATH",
                                       description: "The artifactory repo path where the artifact is located",
                                       optional: true,
                                       is_string: true) # true: verifies the input is a string, false: every kind of value
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
