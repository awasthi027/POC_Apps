module Fastlane
  module Actions
    module SharedValues
      RESIGN_IPA_CUSTOM_VALUE = :RESIGN_IPA_CUSTOM_VALUE
    end

    class ResignIpaAction < Action
      def self.run(params)
        validateENVVariables
        if params[:exportMethod].to_s == 'ad-hoc'
          ad_hoc
        elsif params[:exportMethod].to_s == 'appstore'
          appstore
        elsif params[:exportMethod].to_s == 'enterprise'
          enterprise
        else
          UI.user_error!("Resign_IPA_Action: Unsupported export method error: " + params[:exportMethod].to_s +
            " is not supported. The supported methods are: 'ad-hoc', 'appstore', and 'enterprise'")
        end
        UI.success("Successfully resigned Application")
      end

      def self.ad_hoc
        UI.important('resigning ipa as ah-hoc...')
        display_name = Actions.lane_context[SharedValues::APP_DISPLAY_NAME].to_s
        path_to_ipa = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]+ "/" + display_name + ".ipa"
        other_action.resign(
          ipa: path_to_ipa,
          signing_identity: Actions.lane_context[SharedValues::SIGNING_IDENTITY].to_s,
          entitlements: Actions.lane_context[SharedValues::ENTITLEMENTS_FILE_PATH].to_s,
          provisioning_profile: Actions.lane_context[SharedValues::ADHOC_PROVISIONING_PROFILE].to_s,
          display_name: display_name
        )
      end

      def self.appstore
        UI.important('resigning ipa as appstore...')
        display_name = Actions.lane_context[SharedValues::APP_DISPLAY_NAME].to_s
        path_to_ipa = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]+ "/" + display_name + ".ipa"
        other_action.resign(
          ipa: path_to_ipa,
          signing_identity: Actions.lane_context[SharedValues::SIGNING_IDENTITY].to_s,
          entitlements: Actions.lane_context[SharedValues::ENTITLEMENTS_FILE_PATH].to_s,
          provisioning_profile: Actions.lane_context[SharedValues::APPSTORE_PROVISIONING_PROFILE].to_s,
          display_name: display_name
        )
      end

      def self.enterprise
        UI.important('resigning ipa as enterprise...')
        display_name = Actions.lane_context[SharedValues::APP_DISPLAY_NAME].to_s
        path_to_ipa = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]+ "/" + display_name + ".ipa"
        other_action.resign(
          ipa: path_to_ipa,
          signing_identity: Actions.lane_context[SharedValues::SIGNING_IDENTITY].to_s,
          entitlements: Actions.lane_context[SharedValues::ENTITLEMENTS_FILE_PATH].to_s,
          provisioning_profile: Actions.lane_context[SharedValues::ENTERPRISE_PROVISIONING_PROFILE].to_s,
          display_name: display_name
        )
      end

      # validate that the ENV variables needed for this actions are provided in the .env file are valid
      # Fails this actions if they are invalid or missing
      def self.validateENVVariables(params)
        if Actions.lane_context[SharedValues::SIGNING_IDENTITY].to_s.empty?
          UI.user_error!("The provided SIGNING_IDENTITY is nil or empty. Please provide a valid SIGNING_IDENTITY in the .env file.")
        end
        if Actions.lane_context[SharedValues::ENTITLEMENTS_FILE_PATH].to_s.empty?
          UI.user_error!("The provided ENTITLEMENTS_FILE_PATH is nil or empty. Please provide a valid ENTITLEMENTS_FILE_PATH in the .env file.")
        end
        if Actions.lane_context[SharedValues::APP_DISPLAY_NAME].to_s.empty?
          UI.user_error!("The provided APP_DISPLAY_NAME is nil or empty. Please provide a valid APP_DISPLAY_NAME in the .env file.")
        end
        if params[:exportMethod].to_s == 'ad-hoc'
          if Actions.lane_context[SharedValues::ADHOC_PROVISIONING_PROFILE].to_s.empty?
            UI.user_error!("The provided ADHOC_PROVISIONING_PROFILE is nil or empty. Please provide a valid ADHOC_PROVISIONING_PROFILE in the .env file.")
          end
        elsif params[:exportMethod].to_s == 'appstore'
          if Actions.lane_context[SharedValues::APPSTORE_PROVISIONING_PROFILE].to_s.empty?
            UI.user_error!("The provided APPSTORE_PROVISIONING_PROFILE is nil or empty. Please provide a valid APPSTORE_PROVISIONING_PROFILE in the .env file.")
          end
        elsif params[:exportMethod].to_s == 'enterprise'
          if Actions.lane_context[SharedValues::ENTERPRISE_PROVISIONING_PROFILE].to_s.empty?
            UI.user_error!("The provided ENTERPRISE_PROVISIONING_PROFILE is nil or empty. Please provide a valid ENTERPRISE_PROVISIONING_PROFILE in the .env file.")
          end
        end

      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.details
        "You can use this action to do cool things..."
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :exportMethod,
                                       env_name: "FL_RESIGN_IPA_EXPORT_METHOD",
                                       description: "The desired export method for resigning",
                                       is_string: true)
        ]
      end

      def self.is_supported?(platform)
        platform == :ios
      end
    end
  end
end
