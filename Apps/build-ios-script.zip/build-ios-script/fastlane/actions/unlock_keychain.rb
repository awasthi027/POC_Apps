module Fastlane
  module Actions

    class UnlockKeychainAction < Action
      def self.run(params)
      UI.message("Unlocking the keychain...")
      whoami = Actions.sh("whoami")
      unless whoami.to_s.include? "bamboo"
        UI.important("!!!SKIPPING UNLOCK KEYCHAIN AS THIS IS NOT A BUILD MACHINE!!!!")
        return
      else
        UI.important("Determined that this is a build machine. Proceeding with Keychain Unlock...")
      end

        Actions.sh('security unlock-keychain -p password /Users/bamboo/Library/Keychains/appledev.keychain-db')

      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "This action unlocks the appledev Keychain for codesigning."
      end

      def self.is_supported?(platform)
          [:ios, :mac].include?(platform)
      end
    end
  end
end
