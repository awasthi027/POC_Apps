module Fastlane
    module Actions
        @@artifactoryRepoURL
        @@frameworkChecksum
        class PublishSwiftPackageInternalAction < Action
			##################################################
            # Workspace One SDK Swift Package Helper Methods #
            ##################################################

            def self.run(params)
                if(params[:artifactoryRepoURL].to_s.empty? == false && params[:frameworkChecksum].to_s.empty? == false)
                    UI.message("Skipping download parameters passed to action")
                    UI.message("Binary url "+ params[:artifactoryRepoURL])
                    UI.message("Binary checksum "+ params[:frameworkChecksum])
                    @@artifactoryRepoURL = params[:artifactoryRepoURL]
                    @@frameworkChecksum = params[:frameworkChecksum]
                else
                    UI.message("Downloading frameworks params are empty.")
                    currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
                    binaryFramework = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]
                    artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                    artifactoryRepoPath = Actions.lane_context[SharedValues::ARTIFACTORY_REPO_PATH]
                    other_action.download_latest_ios_sdk_frameworks_from_artifactory(branchName:currentBranch.to_s, 
                                                                                     artifactoryRepoPath:artifactoryRepoPath)
                    @@artifactoryRepoURL = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_DOWNLOAD_URI].to_s
                    @@frameworkChecksum = Actions.sh("shasum -a 256 "+artifactsDirectory+"/"+binaryFramework+".zip").split(' ').first
                end
            	# Package WS1 SDK for internal
                prepareWorkspaceONESDKFilesForSwiftPackage

            end

            def self.prepareWorkspaceONESDKFilesForSwiftPackage
                UI.important('Preparing WorkspaceOneSDK swift package for internal usage')
                setSwiftPackageGITRemoteAndUserInfo
                createBranchInSwiftPackageRepo
                removeAllFilesAndFrameworksInPackageRepo
                createSwiftManifestFileForInternalUse
                pushUpdatedManifestFileToPackageRepo
                UI.success('Moving framework into a package source folder...')
            end

            def self.setSwiftPackageGITRemoteAndUserInfo
                packageDirectoryPath = Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH]
                # Defaulted to https://stash-iossdk-svc:DFgJJk0LjN87@stash.air-watch.com/scm/isdkl/workspaceonesdk-package.git
                swiftPackageTemplateRepositoryOriginURL = Actions.lane_context[SharedValues::SWIFT_PACKAGE_TEMPLATE_REPOSITORY_ORIGIN_URL]
                Actions.sh("(cd "+packageDirectoryPath+"; git remote set-url origin " + swiftPackageTemplateRepositoryOriginURL + ")")
                Actions.sh("(cd "+packageDirectoryPath+"; git config user.name \"SDK Swift Package Publisher\""+")")
                Actions.sh("(cd "+packageDirectoryPath+"; git config user.email \"stash-iossdk-svc@abc,om.com\""+")")
            end

            def self.createBranchInSwiftPackageRepo
                UI.important('Starting to create a package repo branch')
                branch_name = Actions.sh('git rev-parse --abbrev-ref HEAD', log: false).gsub("\n",'')
                packageDirectoryPath = Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH]
                # cd to package repo directory and checkout/create same branch
                Actions.sh("(cd "+packageDirectoryPath+"; ls; git fetch origin; git status; git checkout "+branch_name+" 2>/dev/null || git checkout -b "+branch_name+")")
                UI.success("Current Branch = " + branch_name.to_s)
            end         

            def self.removeAllFilesAndFrameworksInPackageRepo
                UI.important('Cleaning package repo to add package manifest file.')
                packageDirectoryPath = Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH]
                # remove if any unwanted files and folder form package
                Actions.sh("rm -rf " +packageDirectoryPath+"/.swiftpm")
                Actions.sh("rm -rf " +packageDirectoryPath+"/.build")
                Actions.sh("rm -f " +packageDirectoryPath+"/Package.swift")  
                UI.success("Removed files from Package repo.")
            end

            def self.createSwiftManifestFileForInternalUse
                workingDirectory = Actions.lane_context[SharedValues::WORKING_DIRECTORY]
                packageDirectoryPath = Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH]
                artifactsDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]
                binaryFramework = Actions.lane_context[SharedValues::SDK_XCFRAMEWORK_BINARY_NAME]

                manifestFilePath = packageDirectoryPath+"/Package.swift" #manifest file

                # Move Internal-Package.swift manifest file to Internal package repo
                Actions.sh("mv "+workingDirectory+"/Release-Package.swift " + manifestFilePath)
                
                packageText = File.read(manifestFilePath)
                new_contents = packageText.gsub('url_template', @@artifactoryRepoURL)
                new_contents = new_contents.gsub('checksum_template', @@frameworkChecksum)

                # To write changes to the file
                File.open(manifestFilePath, "w") {|file| file.puts new_contents }

                # remove downloaded artifacts
                Actions.sh("rm -rf " +artifactsDirectory+"/")
                UI.success("Manifest file updated for internal use.")

            end

            # !!!WARNING!!!! This method makes a git commit!! Be very careful calling this method!!
            def self.pushUpdatedManifestFileToPackageRepo
                UI.important('Starting to commit changes to package repo')
                branch_name = Actions.sh('git rev-parse --abbrev-ref HEAD', log: false).gsub("\n",'')
                packageDirectoryPath = Actions.lane_context[SharedValues::SWIFT_PACKAGE_FOLDER_PATH]

                filesModifiedToCommit = true
                modifiedFiles = Actions.sh("(cd "+packageDirectoryPath+"; git status"+")").split("\n").each do |line|
                    if line.include? "nothing to commit, working tree clean"
                        filesModifiedToCommit = false
                    end
                end

                if filesModifiedToCommit == true
                    UI.message("Modified files were found to commit.")

                    Actions.sh("(cd "+packageDirectoryPath+"; ls; git add -A)")

                    remote_Branch_Exists = Actions.sh("(cd "+packageDirectoryPath+"; git ls-remote --heads origin "+branch_name+")")
                    if remote_Branch_Exists.to_s.empty?
                        Actions.sh("(cd "+packageDirectoryPath+"; git push origin "+branch_name+")")
                    end

                    Actions.sh("(cd "+packageDirectoryPath+"; git commit -m "+"\""+"Publishing New package: "+  +Actions.lane_context[SharedValues::BUILD_NUMBER].to_s.gsub("\n",'')+"\""+")")
                    Actions.sh("(cd "+packageDirectoryPath+"; git push --set-upstream origin " +branch_name+")")
                    UI.success("Successfully committed update.")
                else
                    UI.message("No modified files were found to commit.")
                end
            end


            #####################################################
            # @!group Documentation
            #####################################################

            def self.description
                "Downloads artifacts of current branch, create a reference to artifact uri in package manifest file and updates internal swift package repo with updated manifest file."
            end

            def self.available_options 
                [
                    FastlaneCore::ConfigItem.new(key: :artifactoryRepoURL,
                                       env_name: "FL_UPLOADED_ARTIFACTORY_REPO_URL", # The name of the environment variable
                                       description: "artifactoryRepoURL", # a short description of this parameter
                                       optional: true,
                                       is_string: true),
                    FastlaneCore::ConfigItem.new(key: :frameworkChecksum,
                                        env_name: "FL_FRAMEWORK_ZIP_CHECKSUM", # The name of the environment variable
                                        description: "frameworkChecksum", # a short description of this parameter
                                        optional: true,
                                        is_string: true)
                ]
            end

            def self.is_supported?(platform)
                [:ios, :mac].include?(platform)
            end
        end
    end
end
