module Fastlane
  module Actions
    module SharedValues
      MULTISCAN_TEST_METRICS = :MULTISCAN_TEST_METRICS
    end

    class MultiscanAction < Action
      def self.run(params)
        puts "build for testing = " + params[:buildForTestingOnly].to_s
        puts "specificTestClassesToRun = " + params[:specificTestClassesToRun].to_s
        pathToProjectFile = Actions.lane_context[SharedValues::WORKING_DIRECTORY]+"/"+Actions.lane_context[SharedValues::WORKSPACE_NAME]
        if params[:useSonarBuildWrapper]
          testWithSonarBuildWrapper(pathToProjectFile: pathToProjectFile)
        elsif Actions.lane_context[SharedValues::WORKSPACE_NAME].include? ".xcodeproj"
          testProject(pathToProjectFile: pathToProjectFile, buildForTestingOnly: params[:buildForTestingOnly], specificTestClassesToRun: params[:specificTestClassesToRun])
        else
          testWorkspace(pathToProjectFile: pathToProjectFile, buildForTestingOnly: params[:buildForTestingOnly], specificTestClassesToRun: params[:specificTestClassesToRun])
        end
        collectMetricsFromUnitTests
      end

      # wrapper around fastlane's scan action specifying project is a workspace and
      # uses the env varialbes provided.
      def self.testWorkspace(params)
          if params[:specificTestClassesToRun].empty?
              testWorkspaceAllClasses(pathToProjectFile: params[:pathToProjectFile], buildForTestingOnly: params[:buildForTestingOnly])
          else
              testWorkspaceSpecificTestClasses(pathToProjectFile: params[:pathToProjectFile], buildForTestingOnly: params[:buildForTestingOnly], specificTestClassesToRun: params[:specificTestClassesToRun])
          end
      end

      # wrapper around fastlane's scan action specifying project is a workspace and
      # uses the env varialbes provided.
      def self.testProject(params)
          if params[:specificTestClassesToRun].empty?
              testProjectAllClasses(pathToProjectFile: params[:pathToProjectFile], buildForTestingOnly: params[:buildForTestingOnly])
          else
              testProjectSpecificTestClasses(pathToProjectFile: params[:pathToProjectFile], buildForTestingOnly: params[:buildForTestingOnly], specificTestClassesToRun: params[:specificTestClassesToRun])
          end
      end

      # wrapper around fastlane's scan action specifying project is a workspace and
      # uses the env varialbes provided.
      def self.testWorkspaceAllClasses(params)
        puts "ALL CLASSES"
        other_action.multi_scan(
          workspace: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          try_count: Actions.lane_context[SharedValues::MULTI_SCAN_TRY_COUNT],
          batch_count: Actions.lane_context[SharedValues::MULTI_SCAN_BATCH_COUNT],
          result_bundle: true,
          code_coverage: true,
          fail_build: false,
          xcargs: Actions.lane_context[SharedValues::SCAN_XCARGS].to_s,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      def self.testWorkspaceSpecificTestClasses(params)
        puts "SPECIFIC CLASSES"
        other_action.multi_scan(
          workspace: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          try_count: Actions.lane_context[SharedValues::MULTI_SCAN_TRY_COUNT],
          batch_count: Actions.lane_context[SharedValues::MULTI_SCAN_BATCH_COUNT],
          result_bundle: true,
          code_coverage: true,
          fail_build: false,
          only_testing: params[:specificTestClassesToRun].split(','),#split comma seperated list into an array of strings,
          xcargs: Actions.lane_context[SharedValues::SCAN_XCARGS].to_s,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      # wrapper around fastlane's scan action specifying project is a xcodeproj and
      # uses the env varialbes provided.
      def self.testProjectAllClasses(params)
        other_action.multi_scan(
          project: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          try_count: Actions.lane_context[SharedValues::MULTI_SCAN_TRY_COUNT],
          batch_count: Actions.lane_context[SharedValues::MULTI_SCAN_BATCH_COUNT],
          result_bundle: true,
          code_coverage: true,
          fail_build: false,
          xcargs: Actions.lane_context[SharedValues::SCAN_XCARGS].to_s,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      def self.testProjectSpecificTestClasses(params)
        other_action.multi_scan(
          project: params[:pathToProjectFile],
          scheme: Actions.lane_context[SharedValues::WORKSPACE_SCHEME],
          try_count: Actions.lane_context[SharedValues::MULTI_SCAN_TRY_COUNT],
          batch_count: Actions.lane_context[SharedValues::MULTI_SCAN_BATCH_COUNT],
          result_bundle: true,
          code_coverage: true,
          fail_build: false,
          only_testing: params[:specificTestClassesToRun].split(','),#split comma seperated list into an array of strings
          xcargs: Actions.lane_context[SharedValues::SCAN_XCARGS].to_s,
          derived_data_path: Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY],
          buildlog_path: Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY],
          skip_slack:true #slack notifications are sent at end of fastlane execution
        )
      end

      # use sonar's build wrapper to wrap around the execution of fastlane's scan action
      def self.testWithSonarBuildWrapper(params)
        UI.message("Attempting to test with sonar build wrapper wrapping execution...")

        build_wrapper_localtion = "~/bamboo-agent-home/xml-data/buildtools/build-wrapper/build-wrapper-macosx-x86"
        derivedDataPath = Actions.lane_context[SharedValues::DERIVED_DATA_DIRECTORY].to_s
        artifactDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s
        scheme = Actions.lane_context[SharedValues::WORKSPACE_SCHEME]
        project_name = Actions.lane_context[SharedValues::WORKSPACE_NAME]

        if project_name.include? ".xcodeproj"
          Actions.sh(build_wrapper_localtion + " --out-dir " + derivedDataPath +
            "/compilation-database fastlane multi_scan --project \"" + project_name + "\" --scheme \"" + scheme.to_s + "\" --derived_data_path " + derivedDataPath +
            " --buildlog_path " + artifactDirectory + " --skip_slack true --code_coverage true")
        else
          Actions.sh(build_wrapper_localtion + " --out-dir " + derivedDataPath +
            "/compilation-database fastlane multi_scan --workspace \"" + project_name + "\" --scheme \"" + scheme.to_s + "\" --derived_data_path " + derivedDataPath +
            " --buildlog_path " + artifactDirectory + " --skip_slack true --code_coverage true")
        end

        UI.success("Completed testing with sonar build wrapper wrapping execution.")
      end

      # Method to collect unit test metrics and save as SharedValues so other actions can use this information
      # (1) time taken to execute unit tests
      # (2) # of unit tests runs
      # (3) # of unit tests failed
      def self.collectMetricsFromUnitTests
        Dir.glob(Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY]+"/*.log") { |file|
          UI.message("Logfile found for metrics reporting: " + file)
          executionResults = []
          File.readlines(file).each { |line|
            if line.include? "Executed"
              executionResults << line.strip
            end
          }
          Actions.lane_context[SharedValues::MULTISCAN_TEST_METRICS] = executionResults.last.to_s
          UI.message("Result Metrics = " + Actions.lane_context[SharedValues::MULTISCAN_TEST_METRICS])
        }
      end
      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "Runs unit tests via the fastlane multi_scan plug-in."
      end

      def self.details
        "The purpose of this action is to abstract away and simply the decision between
        calling scan with xcworkspace and scan with an xcodeproj and to use the fastlane multiscan plug in."
      end

      def self.available_options
        [
         FastlaneCore::ConfigItem.new(key: :useSonarBuildWrapper,
                                      env_name: "FL_USE_SONAR_BUILD_WRAPPER",
                                      description: "useSonarBuildWrapper",
                                      optional: true,
                                      is_string: false,
                                      default_value: false), # the default value if the user didn't provide one
         FastlaneCore::ConfigItem.new(key: :buildForTestingOnly,
                                        env_name: "FL_BUILD_FOR_TESTING_ONLY",
                                        description: "buildForTestingOnly",
                                        optional: true,
                                        is_string: false,
                                        default_value: false), # the default value if the user didn't provide one
         FastlaneCore::ConfigItem.new(key: :specificTestClassesToRun,
                                        env_name: "FL_CLASSES_TO_RUN",
                                        description: "specificClassesToRun-CommaSeperatedList",
                                        optional: true,
                                        is_string: false,
                                        default_value: "")
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
