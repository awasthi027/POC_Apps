require 'net/http'
require 'json'

module Fastlane
  module Actions

    class CleanupArtifactoryArtifactsAction < Action
      @@artifactoryURL = 'https://artifactory.abc.com/artifactory/'
      @@artifactoryUsername = 'deployer'
      @@artifactoryPassword = 'AP2N7ob4YK1FedaGuYrdddd'
      @@numberOfPreviousArtifactsToKeep = 10

      def self.run(params)
        destination_repo_path = params[:destination_repo_path]
        currentBranch = Actions.lane_context[SharedValues::CURRENT_BRANCH_NAME]
        artifactoryRepoPathToClean = @@artifactoryURL +"api/storage/"+destination_repo_path+"/"+currentBranch
        childrenURIsFound = findCurrentlyStoredArtifactsInPath(artifactoryRepoPathToClean: artifactoryRepoPathToClean)
        deleteCommands = createDeleteCommands(childrenURIsFound:childrenURIsFound, artifactoryRepoPathToClean: artifactoryRepoPathToClean.gsub("api/storage/",''))
        runDeleteCommands(deletionCommands: deleteCommands)
      end

      # Find all artifactory artifacts at the given artifactory
      # excludes any artifact under the folder named "latest"
      # returns the URI for all found artifacts
      def self.findCurrentlyStoredArtifactsInPath(params)
        url = params[:artifactoryRepoPathToClean]
        uri = URI(url)
        response = Net::HTTP.get(uri)
        jsonResult = JSON.parse(response)
        UI.message("jsonResult = " + jsonResult.to_s)
        children = jsonResult['children']
        UI.message("children: " + children.to_s)
        childrenURIsFound = []
        children.each do |child|
          childURI= child['uri'].gsub('/','')
          if !childURI.include? "latest" #exclude any folder that is not a build number i.e. "latest"
            childrenURIsFound << childURI
           end
        end
        UI.message("childrenURIsFound found = " + childrenURIsFound.to_s)
        return childrenURIsFound
      end

      # construct the delete command that will be executed to remove an old artifact
      def self.createDeleteCommands(params)
        storedArtifacts = params[:childrenURIsFound]
        artifactoryRepoPathToClean = params[:artifactoryRepoPathToClean]

        deletionCommands = []
        artifactsThatWillBeDeleted = [] # this array is just used for logging output purposes
        numToDelete = storedArtifacts.length - @@numberOfPreviousArtifactsToKeep
        storedArtifacts.each do |artifact|
          if deletionCommands.length < numToDelete
            command = "curl -u " + @@artifactoryUsername +":" +
             @@artifactoryPassword + " -X DELETE " + artifactoryRepoPathToClean +
              "/"+artifact+"/"
            command = command.gsub("//","/").gsub("https:/a","https://a") #remove all double // except for https://
            deletionCommands << command
            artifactsThatWillBeDeleted << artifact
            UI.important("Created following deletion command: \"" + command+ "\"")
          end
        end
        if numToDelete > 0
          printArtifactsThatWillBeDeleted(artifactsThatWillBeDeleted: artifactsThatWillBeDeleted)
        end
        return deletionCommands
      end

      # print the artifacts that will be deleted if the ENV variable CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS is true
      def self.printArtifactsThatWillBeDeleted(params)
        artifactsThatWillBeDeleted = params[:artifactsThatWillBeDeleted]
        outputMessage = "The following artifacts will be deleted:"
        artifactCount = 1
        artifactsThatWillBeDeleted.each do |artifact|
          outputMessage = outputMessage + "\n\t\t(" + artifactCount.to_s + ") " + artifact
          artifactCount += 1
        end
        UI.important(outputMessage)
      end

      # run the actual curl command that deletes the desired artifact on artifactory
      def self.runDeleteCommands(params)
        deletionCommands = params[:deletionCommands]
        if Actions.lane_context[SharedValues::CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS].to_s.downcase.strip == 'true'
          UI.header("CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS is true; Deletion commands will execute")
          deletionCommands.each do |command|
            UI.message("Excuting following command: "+ command)
            Actions.sh(command, log: false)
          end
        else
          UI.header("CLEAN_UP_OLD_ARTIFACTORY_ARTIFACTS is false; Nothing will be deleted, but this action will print what would have been deleted if had been set to true")
        end
      end

      #####################################################
      # @!group Documentation
      #####################################################

      def self.description
        "A short description with <= 80 characters of what this action does"
      end

      def self.details
        "You can use this action to do cool things..."
      end

      def self.available_options
        [
          FastlaneCore::ConfigItem.new(key: :destination_repo_path,
                                        env_name: "FL_UPLOAD_TO_ARTIFACTORY_REPO_PATH", # The name of the environment variable
                                        description: "destination_repo_path", # a short description of this parameter
                                        optional: false,
                                        is_string: true)
        ]
      end

      def self.is_supported?(platform)
        [:ios, :mac].include?(platform)
      end
    end
  end
end
