module Fastlane
    module Actions
      module SharedValues
          JAZZY_DOCUMENTATION_OUTPUT_ZIP_FILE = :JAZZY_DOCUMENTATION_OUTPUT_ZIP_FILE
      end

      class GenerateJazzyDocumentationAction < Action
        def self.run(params)
          workingDirectory =  Actions.lane_context[SharedValues::WORKING_DIRECTORY].to_s

          if Actions.lane_context[SharedValues::JAZZY_CONFIG_PATH].to_s.empty?
            UI.important("No jazzy Config File Location provided. Running without custom configurations file Please add `JAZZY_CONFIG_PATH` to your .env file to customize jazzy")
            Actions.sh("jazzy")
          else
            jazzyConfigFileLocation = workingDirectory + "/" + Actions.lane_context[SharedValues::JAZZY_CONFIG_PATH].to_s
            UI.important("Running jazzy documentation action with the config file located at: " + jazzyConfigFileLocation.to_s)
            Actions.sh("jazzy --config " + jazzyConfigFileLocation)
          end
          UI.success("Finished generating jazzy documentation")

          # rename output directory to name specified in the .env file
          UI.message("Determining if the docs output folder needs to be renamed...")
          desiredName = Actions.lane_context[SharedValues::JAZZY_OUTPUT_NAME].to_s.gsub(" ","-")
          UI.message("Desired name for the docs output folder is: " + desiredName)
          Actions.sh("(cd " + workingDirectory + "; ls)")
          Actions.sh("mv " + workingDirectory + "/docs " + workingDirectory + "/" + desiredName)
          UI.success("Successfully renamed and moved docs folder to the working directory.")
          Actions.sh("(cd " + workingDirectory + "; ls)")
          # zip output and move to artifacts directory
          UI.important("Zipping generated documents and moving to artifact directory...")
          other_action.zip(
            path: workingDirectory + "/" + desiredName,
            output_path: workingDirectory + "/" + desiredName + ".zip",
            verbose: true
          )
          UI.success("Successfully zipped docs folder.")
          artifactDirectory = Actions.lane_context[SharedValues::ARTIFACT_OUTPUT_DIRECTORY].to_s
          Actions.sh("mv " + workingDirectory + "/" + desiredName + ".zip " + artifactDirectory + "/" + desiredName + ".zip")

          Actions.lane_context[SharedValues::JAZZY_DOCUMENTATION_OUTPUT_ZIP_FILE] = desiredName + ".zip"
          UI.success("Successfully moved zipped docs folder to the artifacts directory.")
          Actions.sh("(cd " + artifactDirectory + "/; ls)")
        end

        #####################################################
        # @!group Documentation
        #####################################################

        def self.description
          "Uses jazzy to create documentation"
        end

        def self.is_supported?(platform)
          [:ios, :mac].include?(platform)
        end
      end
    end
  end
