fastlane documentation
================
# Installation

Make sure you have the latest version of the Xcode command line tools installed:

```
xcode-select --install
```

Install _fastlane_ using
```
[sudo] gem install fastlane -NV
```
or alternatively using `brew install fastlane`

# Available Actions
## iOS
### ios unitTest
```
fastlane ios unitTest
```

### ios targetedTesting
```
fastlane ios targetedTesting
```

### ios unitTestWithBuildWrapper
```
fastlane ios unitTestWithBuildWrapper
```

### ios unitTestWithSonar
```
fastlane ios unitTestWithSonar
```

### ios complitationCheckBuildForTesting
```
fastlane ios complitationCheckBuildForTesting
```

### ios unitTestWithSonarNoLint
```
fastlane ios unitTestWithSonarNoLint
```

### ios xcode_analyze
```
fastlane ios xcode_analyze
```

### ios adhoc
```
fastlane ios adhoc
```

### ios development
```
fastlane ios development
```

### ios enterprise
```
fastlane ios enterprise
```

### ios app_store
```
fastlane ios app_store
```

### ios simulator
```
fastlane ios simulator
```

### ios resign_adhoc
```
fastlane ios resign_adhoc
```

### ios resign_enterprise
```
fastlane ios resign_enterprise
```

### ios resign_appstore
```
fastlane ios resign_appstore
```

### ios createFramework_upload_artifactory
```
fastlane ios createFramework_upload_artifactory
```

### ios thirdPartySDKFrameworks
```
fastlane ios thirdPartySDKFrameworks
```

### ios thirdPartyXamarinCompatibleSDKFrameworks
```
fastlane ios thirdPartyXamarinCompatibleSDKFrameworks
```

### ios externalSDKDistribution
```
fastlane ios externalSDKDistribution
```

### ios externalSDKDistributionWithAWPrivacy
```
fastlane ios externalSDKDistributionWithAWPrivacy
```

### ios internalSwiftPackageDistribution
```
fastlane ios internalSwiftPackageDistribution
```

### ios updatePodVersion
```
fastlane ios updatePodVersion
```

### ios updateXSWPodVersion
```
fastlane ios updateXSWPodVersion
```

### ios podLibLint
```
fastlane ios podLibLint
```

### ios manualPodRepoPush
```
fastlane ios manualPodRepoPush
```

### ios updateAWCMWrapper
```
fastlane ios updateAWCMWrapper
```

### ios jazzyDocumentGeneration
```
fastlane ios jazzyDocumentGeneration
```

### ios deploySITHApplication
```
fastlane ios deploySITHApplication
```

### ios PublishWorkspaceOneSDKToPublicRepos
```
fastlane ios PublishWorkspaceOneSDKToPublicRepos
```

### ios PublishSwiftManifestToPublicRepo
```
fastlane ios PublishSwiftManifestToPublicRepo
```


----

## Mac
### mac unitTest
```
fastlane mac unitTest
```

### mac xcode_analyze
```
fastlane mac xcode_analyze
```


----

This README.md is auto-generated and will be re-generated every time [fastlane](https://fastlane.tools) is run.
More information about fastlane can be found on [fastlane.tools](https://fastlane.tools).
The documentation of fastlane can be found on [docs.fastlane.tools](https://docs.fastlane.tools).
