Congratulations on downloading the VMware Workspace ONE Software Development
Kit (SDK) for iOS.

The Frameworks-Xcode/ directory contains a set of frameworks for use with
Xcode. The frameworks are compatible with all versions of Xcode that are
supported by this version of the SDK. Some previous versions of the SDK were
packaged as multiple framework sets, each set being compatible with only one
version of Xcode.

Developer documentation for the SDK is available on the code.vmware.com
website. See: https://code.vmware.com/web/sdk/Native/airwatch-ios