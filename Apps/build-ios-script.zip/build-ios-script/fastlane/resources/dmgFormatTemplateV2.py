# -*- coding: utf-8 -*-
from __future__ import unicode_literals

filename = 'VMwareWorkspaceONESDK.dmg'
volume_name = 'VMware WS1 SDK'

# Files to include
files = [ 'Workspace ONE SDK', 'Privacy SDK' ]

# Volume format (see hdiutil create -help)
format = defines.get('format', 'UDBZ')

# Volume size
size = defines.get('size', None)

# Volume icon
#
# You can either define icon, in which case that icon file will be copied to the
# image, *or* you can define badge_icon, in which case the icon file you specify
# will be used to badge the system's Removable Disk icon
#
icon = 'dmgIcon.icns'

# Where to put the icons
icon_locations = {
    'Workspace ONE SDK' : (250, 200),
    'Privacy SDK'       : (550, 200),
    '.VolumeIcon.icns'  : (150, 850),
    '.background.png'   : (150, 850)
}

# .. Window configuration ......................................................
background = 'background.png'

show_status_bar = False
show_tab_view = False
show_toolbar = False
show_pathbar = False
show_sidebar = False
sidebar_width = 180

# Window position in ((x, y), (w, h)) format
window_rect = ((100, 100), (790, 625))

# Select the default view
default_view = 'icon-view'

# General view configuration
show_icon_preview = False

# Set these to True to force inclusion of icon/list view settings (otherwise
# we only include settings for the default view)
include_icon_view_settings = 'auto'
include_list_view_settings = 'auto'

# .. Icon view configuration ...................................................

arrange_by = None
grid_offset = (0, 0)
grid_spacing = 100
scroll_position = (0, 0)
label_pos = 'bottom' # or 'right'
text_size = 16
icon_size = 128
