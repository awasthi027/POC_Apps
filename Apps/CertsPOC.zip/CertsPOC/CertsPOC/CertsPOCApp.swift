//
//  CertsPOCApp.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

import SwiftUI

@main
struct CertsPOCApp: App {
    var body: some Scene {
        WindowGroup {
            CertificateManagerView()
        }
    }
}
