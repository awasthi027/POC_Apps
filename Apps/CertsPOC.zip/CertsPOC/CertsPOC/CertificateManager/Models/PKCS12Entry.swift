//
//  PKCS12Entry.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

import Foundation

public final class PKCS12Entry {
    public let identity: SecIdentity
    public let trust: SecTrust


    public init(identity: SecIdentity, trust: SecTrust) {
        self.identity = identity
        self.trust = trust
    }

    public var certificate: SecCertificate? {
        var certificate: SecCertificate? = nil
        _ = SecIdentityCopyCertificate(self.identity, &certificate)
        return certificate
    }
}
