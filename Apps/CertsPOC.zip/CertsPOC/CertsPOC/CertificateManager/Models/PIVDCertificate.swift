//
//  PIVDCertificate.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

import Foundation

/// This enumeration will be useful to track expiry status of a certificate.
enum CertificateExpiryStatus {
    case aboutToExpire, expired, valid, none
}


internal class PIVDCertificate {

    let x509: X509Certificate
    var displayType: String?
    /// x509 data.
    var data: Data?
    /// Holds the expiry status of the certificate. .expired, .aboutToExpire etc.
    var certificateStatus: CertificateExpiryStatus?
    /// This is the accessory certificate
    var secCertificate: SecCertificate?

    init?(certificateData: Data?, secCertificate: SecCertificate? = nil) {

        guard let x509Cert = X509Certificate.init(certificateData: certificateData) else {
            return nil
        }
        self.data = certificateData
        self.x509 = x509Cert
        self.displayType = x509Cert.type
        self.secCertificate = secCertificate
    }
}

/// X509Certificate
@objc
public class X509Certificate: CertificateWrapper {

    /// Specifies the type of certificate. Example: Authentication, Signing, Encryption.
    public fileprivate(set) var type: String?

    /// Specifies subjectDetail of certificate. Example: subjectDetail = "CN=Johnny.Cakes.8884444892,OU=ARMY,OU=PKI,OU=DoD,O=U.S. Government,C=US"
    public fileprivate(set) var subjectDetail: String?

    /// Specifies issuerDetail of certificate. Example: issuerDetail = "CN=DOD PB ID SW CA-46,OU=PKI,OU=DoD,O=U.S. Government,C=US"
    public fileprivate(set) var issuerDetail: String?



    /// Instanticates the certificate object with the certificate data.
    /// Intializes certificate object with data for the certificate represented in DER or PEM format.
    /// - Parameter certificate: PEM or DER representation of certificate data.
    public override init?(certificateData certificate: Data?) {
        /// call AWX509Wrapper.init
        super.init(certificateData: certificate)

        self.subjectDetail = self.subjectDetail(with: SubjectFormat.RFC2253)
        self.issuerDetail  = self.issuerDetail(with: SubjectFormat.RFC2253)

        /// Authenication certificate should have ExtendedKeyUsage SSL_Client and universalPrincipalName
        /// Singing certificate should have KeyUsage DigitalSignature and emailAddress
        /// Encryption certificate should have KeyUsage DataEncipherment or KeyEncipherment, and emailAddress

        var types = [String]()
        if self.hasExtendedUsage(ExtendedKeyUsage.SSL_Client) {
            types.append(CertificateType.authentication.stringValue)
        }

        if self.canUse(for: KeyUsage.DigitalSignature) {
            types.append(CertificateType.signing.stringValue)
        }

        if self.canUse(for: KeyUsage.DataEncipherment) || self.canUse(for: KeyUsage.KeyEncipherment) {
            types.append(CertificateType.encryption.stringValue)
        }

        self.type = types.joined(separator: ", ")
    }

    /// This is used to log the certificate information
    /// - Returns: X509 Certificate's log information.
    var certDebugInfo: String {

        return "Common name: \(self.commonName() ?? "")\n"
        + "Subject: \(self.subjectDetail ?? "")\n"
        + "Issuer: \(self.issuerDetail ?? "")\n"
        + "purpose: \(self.type ?? "")\n"
        + "validity: \(self.isValid())\n"
    }
}
