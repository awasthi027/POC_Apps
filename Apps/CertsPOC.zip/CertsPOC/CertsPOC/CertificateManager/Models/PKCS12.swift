//
//  PKCS12.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

import Foundation

public final class PKCS12 {

    public let entries: [PKCS12Entry]

    public init?(p12Data: Data, password: String) {

        var options: [String: CFTypeRef] = [kSecImportExportPassphrase as String: password as CFString]
        #if os(OSX)
            // Create a temporary keychain for the PKCS12 to be imported into
            let keychain = PKCS12.createTempKeychain()
            options[kSecImportExportKeychain as String] = keychain
            // Then delete the keychain from the device
            defer { SecKeychainDelete(keychain) }
        #endif

        var items: CFArray? = nil
        let result = SecPKCS12Import(p12Data as CFData, options as CFDictionary, &items)
        guard result == errSecSuccess, let extractedItems = items as [AnyObject]?, extractedItems.count > 0 else {
            debugPrint("PKCS12 Import did not yield any certificates or identities")
            return nil
        }

        var pkcs12Entries: [PKCS12Entry] = []
        for certificateDict in extractedItems {
            if let identityDictionary = certificateDict as? [AnyHashable: AnyObject],
                let identity = identityDictionary[String(kSecImportItemIdentity)],
                let trust = identityDictionary[String(kSecImportItemTrust)] {
                let entry = PKCS12Entry(identity: identity as! SecIdentity, trust: trust as! SecTrust)
                pkcs12Entries.append(entry)
            }
        }
        self.entries = pkcs12Entries
    }

    #if os(OSX)
    internal static func createTempKeychain() -> SecKeychain? {

        let tempDir = URL(fileURLWithPath: NSTemporaryDirectory())

        var tempKeychain: SecKeychain? = nil
        let _ = SecKeychainCreate(tempDir.appendingPathComponent("\(UUID().uuidString).keychain").absoluteString, 0, "", false, nil, &tempKeychain)
        return tempKeychain
    }
    #endif

    public convenience init?(filePath: String, password: String) {
        let data = try? Data(contentsOf: URL(fileURLWithPath: filePath))
        guard let certificateData = data else {
            return nil
        }

        self.init(p12Data: certificateData, password: password)
    }
}
