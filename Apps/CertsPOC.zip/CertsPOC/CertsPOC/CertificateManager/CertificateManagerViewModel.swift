//
//  CertsViewModel.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

import Foundation


//import OpenSSL

public class CertificateManagerViewModel: ObservableObject {

    public init() {
        CMWrapperInitilizer.initializeModule()
    }

    func createClientIdCertificate(attributes: [String : Any], publicKey: String) {
        let attributes: [String : Any] = [ "AWCertificateSubjectName": "X509Application Indenty", "AWUserID" : "Application id"]
        let keyWarrper = OpenSSLUtils.createPublicAndPrivateDummyKey()
        let certificateWrapper: CertificateWrapper? = CertificateWrapper(attributes: attributes, publicKey: keyWarrper?.publicKey)
        if let data = certificateWrapper?.serialNumber() {
            debugPrint("Serial Number: \(data.bytes)")
        }
    }

    func parseLocalCertificateToReadTheProperties(fileName: String = "AllInOne",
                                                  ext: String = "p12",
                                                  password: String = CertConstants.p12Password) -> String {
        var certData: Data? = Utils.dataFromFile(name: fileName,
                                                 withExtension: ext)
        if certData == nil {
            certData = Utils.readFile(from: Utils.documentDirectory(), fileName: fileName)
        }

        guard let certData = certData,
              let result = Utils.certificateDataFromP12(p12Data: certData, password: password)
        else {
            debugPrint("Failed retrieving p12 data")
            return ""
        }
        guard let cert = PIVDCertificate(certificateData: result.certificateData) else {
            debugPrint(false, "We are not getting certificate")
            return ""
        }
        let certDetails = cert.x509.certDebugInfo
        debugPrint("CertificateName: \(certDetails)")
        return certDetails
    }

    public func createNewCertificateFrom(fileName: String = "AllInOne",
                                         ext: String = "p12",
                                         password: String,
                                         newPassword: String,
                                         newCertName: String = "newCertificate.p12") {

        guard let certData = Utils.dataFromFile(name: fileName, withExtension: ext),
              let certData = Utils.reCreateCertificateWith(newPassword: newPassword,
                                                           p12Data: certData,
                                                           password: password)
        else {
            debugPrint("Failed to create certificate with new password")
            return
        }
        Utils.save(data: certData,
                   toDirectory: Utils.documentDirectory(),
                   withFileName: newCertName)
    }

    public func changeCertificatePassword(fileName: String = "AllInOne",
                                         ext: String = "p12",
                                         password: String,
                                         newPassword: String,
                                         newCertName: String = "newCertificate.p12") {
        guard let certData = Utils.dataFromFile(name: fileName, withExtension: ext),
              let certData = Utils.changeCertificatePassword(newPassword: newPassword,
                                                           p12Data: certData,
                                                           password: password)
        else {
            debugPrint("Failed to change certificate cassword")
            return
        }
        Utils.save(data: certData,
                   toDirectory: Utils.documentDirectory(),
                   withFileName: newCertName)
    }

    func encryptData(data: Data) -> Data? {

        guard let certData = Utils.dataFromFile(name: "AllInOne", withExtension: "p12") else {
            return nil
        }
        let viewModel = OpenSSLCryptoViewModel(certificate: certData,
                                                   password: CertConstants.p12Password)
        return viewModel.encrypt(data: data)
    }

    func deCryptData(data: Data) -> Data? {

        guard let certData = Utils.dataFromFile(name: "AllInOne",
                                                withExtension: "p12") else {
            return nil
        }
        let viewModel = OpenSSLCryptoViewModel(certificate: certData,
                                                   password: CertConstants.p12Password)
        return viewModel.decrypt(data: data)
    }
}


extension Data {
    public var bytes: [UInt8] {
        return [UInt8](self)
    }
}
public extension Collection {
    var isNotEmpty: Bool {
        return self.isEmpty == false
    }
}


@objc
public enum CertificateType:Int {
    case authentication
    case signing
    case encryption
    case historical
    case all
    case certsWithoutPurpose
}

public extension CertificateType {
    var stringValue: String {
        switch self {
        case .authentication: return "Authentication"
        case .signing: return "Signing"
        case .encryption: return "Encryption"
        case .historical:   return "Historical"
        case .all: return "Default"
        case .certsWithoutPurpose: return "CertsWithoutPurpose"
        }
    }

    static func certificateType(forStringValue stringValue:String) -> CertificateType? {
        switch stringValue {
        case "Authentication": return CertificateType.authentication
        case "Signing": return CertificateType.signing
        case "Encryption": return CertificateType.encryption
        case "Historical": return CertificateType.historical
        case "Default": return CertificateType.all
        case "CertsWithoutPurpose": return CertificateType.certsWithoutPurpose
        default:
            return nil
        }
    }
}

class CMWrapperInitilizer {

    class func initializeModule() {
        let sema = DispatchSemaphore(value: 0)
        WrapperModule.makeReady {
            sema.signal()
        }
        let _ = sema.wait(timeout: .distantFuture)
    }

}
