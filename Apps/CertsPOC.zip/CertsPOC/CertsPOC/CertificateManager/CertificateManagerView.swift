//
//  ContentView.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

import SwiftUI

let createNewCertificate = "CreateCert.p12"
let changePasswordCertificate = "ChangePasswordCert.p12"
let certificatePassword = "Password2"

struct CertificateManagerView: View {
    @StateObject var viewModel = CertificateManagerViewModel()

    @State var certDetails: String = ""

    var body: some View {

        VStack(spacing: 10) {

            self.addOptionLayout(title: "Application Identity Certificate") { isCall in
               self.viewModel.createClientIdCertificate(attributes: [:], publicKey: "")
            }

            self.addOptionLayout(title: "Read local certificate properties") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: "AllInOne")
                }
            }

            self.addOptionLayout(title: "Create Certificate With NewPassword") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = ""
                  self.viewModel.createNewCertificateFrom(fileName: "AllInOne",
                                                          password: CertConstants.p12Password,
                                                          newPassword: "Password2",
                                                          newCertName: createNewCertificate)
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: createNewCertificate,
                                                                                               password: certificatePassword)
                }
            }

            self.addOptionLayout(title: "Change Certificate Password") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = ""
                  self.viewModel.changeCertificatePassword(fileName: "AllInOne",
                                                          password: CertConstants.p12Password,
                                                          newPassword: certificatePassword,
                                                           newCertName: changePasswordCertificate)
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: changePasswordCertificate,
                                                                                               password: certificatePassword)
                }
            }

            self.addOptionLayout(title: "Encrypt Data with SSL API") {  isCall in
                DispatchQueue.global().async {
                    if let data = "Ashish".data(using: .utf8),
                       let encryptedData = self.viewModel.encryptData(data: data) {
                        let plainData = self.viewModel.deCryptData(data: encryptedData)
                        let str = String(decoding: plainData ?? Data(), as: UTF8.self)
                        self.certDetails = str
                    }
                }
            }
            self.addOptionLayout(title: "Encrypt data with Native IOS API") {  isCall in
                DispatchQueue.global().async {
                    let viewModel = CryptoGraphicOperationViewModel()
                    if let data = "Ashish Awasthi".data(using: .utf8),
                       let encryptedData = viewModel.encrypt(data: data) {
                        let plainData = viewModel.decrypt(data: encryptedData)
                        let str = String(decoding: plainData ?? Data(), as: UTF8.self)
                        self.certDetails = str
                    }
                }
            }

            self.addOptionLayout(title: "Sign And Verify Data") {  isCall in
                DispatchQueue.global().async {
                    let viewModel = CryptoGraphicOperationViewModel()
                    if let data = "Ashish Awasthi".data(using: .utf8),
                       let signedData = viewModel.sign(dataToSign: data) {
                        let isSuccess = viewModel.verify(signedData: data, signature: signedData)
                        //let str = String(decoding: plainData ?? Data(), as: UTF8.self)
                        self.certDetails = "Is signing data is Success: \(isSuccess)"
                    }
                }
            }

            Text(self.certDetails)
        }
        .padding()
        .onAppear {
            
        }
    }

    func addOptionLayout(title: String, callBack: @escaping(Bool) -> Void) -> some View {
        Button {
            callBack(true)
        } label: {
            HStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text(title)
            }
        }
    }
}

#Preview {
    CertificateManagerView()
}
