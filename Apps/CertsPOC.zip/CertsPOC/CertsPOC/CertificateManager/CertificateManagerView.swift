//
//  ContentView.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

import SwiftUI

let createNewCertificate = "CreateCert.p12"
let changePasswordCertificate = "ChangePasswordCert.p12"
let certificatePassword = "Password2"

struct CertificateManagerView: View {
    @StateObject var viewModel = CertificateManagerViewModel()
    @State var certDetails: String = ""

    var body: some View {

        VStack(spacing: 10) {

            self.addOptionLayout(title: "Application Identity Certificate") { isCall in
               self.viewModel.createClientIdCertificate(attributes: [:], publicKey: "")
            }

            self.addOptionLayout(title: "Read local certificate properties") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: "AllInOne")
                }
            }

            self.addOptionLayout(title: "Create Certificate With NewPassword") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = ""
                  self.viewModel.createNewCertificateFrom(fileName: "AllInOne",
                                                          password: CertConstants.p12Password,
                                                          newPassword: "Password2",
                                                          newCertName: createNewCertificate)
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: createNewCertificate,
                                                                                               password: certificatePassword)
                }
            }

            self.addOptionLayout(title: "Change Certificate Password") {  isCall in
                DispatchQueue.global().async {
                    self.certDetails = ""
                  self.viewModel.changeCertificatePassword(fileName: "AllInOne",
                                                          password: CertConstants.p12Password,
                                                          newPassword: certificatePassword,
                                                           newCertName: changePasswordCertificate)
                    self.certDetails = self.viewModel.parseLocalCertificateToReadTheProperties(fileName: changePasswordCertificate,
                                                                                               password: certificatePassword)
                }
            }
            Text(self.certDetails)
        }
        .padding()
        .onAppear {
            
        }
    }

    func addOptionLayout(title: String, callBack: @escaping(Bool) -> Void) -> some View {
        Button {
            callBack(true)
        } label: {
            HStack {
                Image(systemName: "globe")
                    .imageScale(.large)
                    .foregroundStyle(.tint)
                Text(title)
            }
        }
    }
}

#Preview {
    CertificateManagerView()
}
