//
//  CryptoGraphicOperationViewModel.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 25/12/23.
//

import Foundation
import Security
 /*
 1. For encryption and decrytion public and private key required, Which we generate by own with help secure enclave or random string
   or passcode or get from certificate.
 2. What is Signing and Verification? By singing the data we can create siginature and By passing original data and siginature, We can verify data integrity.
  Whether data is same or not

 */
class CryptoGraphicOperationViewModel {

    var p12Data: Data
    var password: String

    init(fileName: String = "AllInOne",
         ext: String = "p12",
         password: String = CertConstants.p12Password) {
        self.p12Data = Self.insertCertificate() ?? Data()
        self.password = password
    }

    static func insertCertificate(fileName: String = "AllInOne",
                                  ext: String = "p12",
                                  password: String = CertConstants.p12Password) -> Data? {
        return Utils.dataFromFile(name: fileName,
                                  withExtension: ext)
    }

    public func encrypt(data: Data,
                        algorithm: SecKeyAlgorithm = .rsaEncryptionOAEPSHA512AESGCM) -> Data? {

        guard let result = Utils.certificateDataFromP12(p12Data: self.p12Data,
                                                        password: self.password)
        else { return nil }

        guard let publicAndPrivateKey = Utils.publicAndPrivateKey(pkcs12Entry: result.pkcs12Entry) else {
            return nil
        }
        return self.encrypt(value: data,
                            publicKey: publicAndPrivateKey.publicKey,
                            algorithm: algorithm)
    }

    public func decrypt(data: Data,
                        algorithm: SecKeyAlgorithm = .rsaEncryptionOAEPSHA512AESGCM) -> Data?  {
        guard let result = Utils.certificateDataFromP12(p12Data: self.p12Data,
                                                        password: self.password)
        else { return nil }

        guard let publicAndPrivateKey = Utils.publicAndPrivateKey(pkcs12Entry: result.pkcs12Entry) else {
            return nil
        }
        return self.decrypt(encrypted: data,
                            privateKey: publicAndPrivateKey.privateKey,
                            algorithm: algorithm)
    }

    public func sign(dataToSign: Data,
                     algorithm: SecKeyAlgorithm = .rsaSignatureMessagePKCS1v15SHA512) -> Data? {
        guard let result = Utils.certificateDataFromP12(p12Data: self.p12Data,
                                                        password: self.password)
        else { return nil }

        guard let publicAndPrivateKey = Utils.publicAndPrivateKey(pkcs12Entry: result.pkcs12Entry) else {
            return nil
        }
        return self.signThe(data: dataToSign, privateKey: publicAndPrivateKey.privateKey, algorithm: algorithm)
    }

    /// Verifies the signature using the signing algorithm
    /// This method will throw error if incompatible algorithm type is used for eg: RSA key pair with ECC signing algorithm
    ///
    /// - Parameters:
    ///   - signedData: the data that needs to be verified
    ///   - signature: signature of the data
    ///   - publicKey: public key to verify the signature
    ///   - algorithm: signing algorithm
    /// - Returns: `true` if verification succeeds
    /// - Throws: error defined by `AWError.SDK.CryptoKit.AsymmetricCryptoPair`
    public  func verify(signedData: Data,
                        signature: Data,
                        algorithm: SecKeyAlgorithm = .rsaSignatureMessagePKCS1v15SHA512) -> Bool {

        guard let result = Utils.certificateDataFromP12(p12Data: self.p12Data,
                                                        password: self.password)
        else { return false }

        guard let publicAndPrivateKey = Utils.publicAndPrivateKey(pkcs12Entry: result.pkcs12Entry) else {
            return false
        }
        return self.verifySigned(data: signedData, signature: signature, publicKey: publicAndPrivateKey.publicKey, algorithm: algorithm)
    }


    internal func encrypt(value: Data, publicKey: SecKey, algorithm: SecKeyAlgorithm) -> Data? {

        guard SecKeyIsAlgorithmSupported(publicKey, .encrypt, algorithm) else {
            debugPrint("Not supported encryption algorithm")
            return nil
        }
        var errorRef: Unmanaged<CFError>?
        guard let encryptedData = SecKeyCreateEncryptedData(publicKey, algorithm, value as CFData, &errorRef) else {
            let error = errorRef?.takeRetainedValue()
            debugPrint("error encrypting: \(String(describing: error))")
            return nil
        }
        return encryptedData as Data
    }

    internal  func decrypt(encrypted: Data,
                           privateKey: SecKey,
                           algorithm: SecKeyAlgorithm) -> Data? {
        guard SecKeyIsAlgorithmSupported(privateKey, .decrypt, algorithm) else {
            debugPrint("Not supported decription algorithm")
            return nil
        }

        var errorRef: Unmanaged<CFError>?
        guard let decryptedData = SecKeyCreateDecryptedData(privateKey, algorithm, encrypted as CFData, &errorRef) as Data? else {
            let error = errorRef?.takeRetainedValue()
            debugPrint( "error decrypting: \(String(describing: error))")
            return nil
        }
        return decryptedData
    }

    /// Signs the message using the signing algorithm
    /// Please refer to apple documentation regarding any input data size constraints for the signing algorithm.
    /// This method will throw error if incompatible algorithm type is used for eg: RSA key pair with ECC signing algorithm
    /// - Parameters:
    ///   - dataToSign: data that needs to be signed
    ///   - privateKey: private key to sign the data
    ///   - algorithm: signing algorithm
    /// - Returns: signature of the data
    /// - Throws: error defined by `AWError.SDK.CryptoKit.AsymmetricCryptoPair`
    internal func signThe(data: Data,
                          privateKey: SecKey,
                          algorithm: SecKeyAlgorithm) -> Data? {
        guard SecKeyIsAlgorithmSupported(privateKey, .sign, algorithm) else {
            debugPrint("Not supported decription algorithm")
            return nil
        }

        var errorRef: Unmanaged<CFError>?
        guard let signature = SecKeyCreateSignature(privateKey,
                                                    algorithm,
                                                    data as CFData,
                                                    &errorRef) as Data?
        else {
            let error = errorRef?.takeRetainedValue()
            debugPrint("error signing: \(String(describing: error))")
            debugPrint("Not supported decription algorithm")
            return nil
        }

        return signature as Data
    }

    internal func verifySigned(data: Data, signature: Data,
                               publicKey: SecKey,
                               algorithm: SecKeyAlgorithm) -> Bool {
        guard SecKeyIsAlgorithmSupported(publicKey, .verify, algorithm) else {
            debugPrint("Not supported encryption algorithm")
            return false
        }

        guard data.isNotEmpty else {
            debugPrint("Can not verify signature with empty signed data")
            return false
        }

        var errorRef: Unmanaged<CFError>?
        guard SecKeyVerifySignature(publicKey,
                                    algorithm,
                                    data as CFData,
                                    signature as CFData,
                                    &errorRef)
        else {
            debugPrint("error verifying: \(String(describing: errorRef?.takeRetainedValue() as Error?))")
            return false
        }

        return true
    }
}
