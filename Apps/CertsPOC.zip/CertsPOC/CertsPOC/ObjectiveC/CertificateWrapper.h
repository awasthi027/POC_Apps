//
//  CertificateWrapper.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, KeyUsage) {
    DigitalSignature    = 1 << 7,
    NonRepudiation      = 1 << 6,
    KeyEncipherment     = 1 << 5,
    DataEncipherment    = 1 << 4,
    KeyAgreement        = 1 << 3,
    KeyCertSign         = 1 << 2,
    CrlSign             = 1 << 1,
    EncipherOnly        = 1 << 0,
    DecipherOnly        = 1 << 15
};

typedef NS_ENUM(NSUInteger, ExtendedKeyUsage) {
    SSL_Server  = 1 << 0,
    SSL_Client  = 1 << 1,
    SMIME       = 1 << 2,
    CodeSign    = 1 << 3,
    SGC         = 1 << 4,
    OCSPSign    = 1 << 5,
    TimeStamp   = 1 << 6,
    DVCS        = 1 << 7,
    AnyEKU      = 1 << 8
};

typedef NS_ENUM(NSUInteger, SubjectFormat) {
    RFC2253 = 0,
    OneLine,
    MultiLine
};

@interface CertificateWrapper: NSObject

/*!
 @brief Intializes wrapper with data for the certificate represented in DER or
 PEM format.

 @discussion This initializer accepts data in both <b>PEM</b> and <b>DER</b> formats

 To use it, simply call @c[[AWX509Wrapper alloc] initWithCertificateData:data];

 @param  data PEM or DER representation of certificate data.

 @return AWX509Wrapper instance if data can not be successfully parsed as a X509 Certificate.
 */
-(instancetype _Nullable) initWithCertificateData:(NSData* _Nullable)data;

- (instancetype _Nullable ) initWithAttributes:(NSDictionary*_Nullable)attributes
                          publicKey:(NSData*_Nullable)publicKey;
- (NSData *_Nullable)serialNumber;
- (NSString *_Nullable)commonName;
- (BOOL )isValid;
- (BOOL )canUseFor:(KeyUsage)usage;
- (BOOL) hasExtendedUsage:(ExtendedKeyUsage)eUsage;
- (NSString*_Nullable)subjectDetailWithFormat:(SubjectFormat )format;
- (NSString *_Nullable)issuerDetailWithFormat: (SubjectFormat )format;

@end
