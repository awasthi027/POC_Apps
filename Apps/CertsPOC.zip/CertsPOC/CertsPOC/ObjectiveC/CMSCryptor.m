//
//  CMSCryptor.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 24/12/23.
//

#import <Foundation/Foundation.h>
#import "CMSCryptor.h"
#import "CertificateWrapper.h"
#import "OpenSSLHelper.h"


#import <openssl/safestack.h>
#import <openssl/cms.h>
#import <openssl/bio.h>


BIO* AWGetBIOForCMS(CMS_ContentInfo *cmsContent)
{
    BIO *cmsContentBIO = NULL;
    if (cmsContent != NULL)
    {
        cmsContentBIO =  BIO_new(BIO_s_mem());
        i2d_CMS_bio(cmsContentBIO, cmsContent);
    }
    return cmsContentBIO;
}

CMS_ContentInfo *AWGetCMSContentFromData(NSData *data)
{
    BIO *cmsBio = AWGetBIOForData(data);
    CMS_ContentInfo *cms = d2i_CMS_bio(cmsBio, NULL);
    BIO_free(cmsBio);
    cmsBio = NULL;
    return cms;
}

NSData* AWGetDataForCMS(CMS_ContentInfo *cms)
{
    BIO *cmsBIO = AWGetBIOForCMS(cms);
    NSData *returnData = AWGetDataFromBIO(cmsBIO);
    BIO_free(cmsBIO);
    cmsBIO = NULL;
    return returnData;
}

@interface CertificateWrapper()
@property (nonatomic, assign) X509 *certificate;
@end


@implementation CMSCryptor

+(NSData*) encrypt:(NSData*)payload certificateData:(NSData*)certificate {
    enter_open_ssl();
    CertificateWrapper *x509 = [[CertificateWrapper alloc] initWithCertificateData: certificate];
    if (x509 == nil) {
        exit_open_ssl();
        return nil;
    }

    STACK_OF(X509) *stack = sk_X509_new_null();
    BIO *payLoadBIO = AWGetBIOForData(payload);
    sk_X509_push(stack, x509.certificate);

    CMS_ContentInfo *cms = CMS_encrypt(stack, payLoadBIO, EVP_aes_128_cbc(), CMS_BINARY);
    NSData *returnData = AWGetDataForCMS(cms);
    CMS_ContentInfo_free(cms);
    BIO_free(payLoadBIO);
    sk_X509_free(stack);
    exit_open_ssl();
    return returnData;
}

+ (NSData*) decrypt:(NSData*)cmsData privateKeyData:(NSData*)privateKeyData password:(NSString*)password
{
    enter_open_ssl();
    EVP_PKEY *pkey = AWGetRSAPrivateKey(privateKeyData, password);
    if (pkey == NULL) {
        exit_open_ssl();
        return nil;
    }

    CMS_ContentInfo *cms = AWGetCMSContentFromData(cmsData);
    if (cms == NULL) {
        EVP_PKEY_free(pkey);
        exit_open_ssl();
        return nil;
    }

    BIO *payloadBIO = BIO_new(BIO_s_mem());
    NSData *returnData = nil;
    if (CMS_decrypt(cms, pkey, NULL, NULL, payloadBIO, 0) == 1) {
        returnData = AWGetDataFromBIO(payloadBIO);
    }

    BIO_free(payloadBIO);
    CMS_ContentInfo_free(cms);
    EVP_PKEY_free(pkey);
    exit_open_ssl();
    return returnData;
}

+(NSData *) signData:(NSData*)payload
      privateKeyData:(NSData *)privateKeyData
            password:(NSString*)password
   signerCertificate:(NSData *)signerCertificate
            detached:(BOOL) detached
{
    enter_open_ssl();
    EVP_PKEY *pkey = AWGetRSAPrivateKey(privateKeyData, password);
    CertificateWrapper *signerX509 = [[CertificateWrapper alloc] initWithCertificateData:signerCertificate];
    BIO *dataBIO = AWGetBIOForData(payload);
    if (dataBIO == nil) {
        EVP_PKEY_free(pkey);
        exit_open_ssl();
        return nil;
    }

    int flags = CMS_BINARY;
    if (detached) {
        flags |=  CMS_DETACHED;
    }

    CMS_ContentInfo *cms = CMS_sign(signerX509.certificate, pkey, NULL, dataBIO, flags);
    NSData *signature = AWGetDataForCMS(cms);
    if (signature == nil) {
        NSLog(@"CMS Signing error %@ ", AWGetOpenSSLError());
    }
    CMS_ContentInfo_free(cms);
    BIO_free(dataBIO);
    EVP_PKEY_free(pkey);
    exit_open_ssl();
    return signature;
}
+(NSData *) pkcs7SignedPayload:(NSData*)payload
                privateKeyData:(NSData *)privateKeyData
                      password:(NSString*)password
             signerCertificate:(NSData *)signerCertificate
{
    return [CMSCryptor signData:payload
                     privateKeyData:privateKeyData
                           password:password
                  signerCertificate:signerCertificate
                           detached:NO];
}

+(NSData *) pkcs7SignatureForPayload:(NSData*)payload
                      privateKeyData:(NSData *)privateKeyData
                            password:(NSString*)password
                   signerCertificate:(NSData *)signerCertificate
{
    return [CMSCryptor signData:payload
                     privateKeyData:privateKeyData
                           password:password
                  signerCertificate:signerCertificate
                           detached:YES];
}

//
//+(NSData*) verifyPKCS7PayloadData:(NSData*)payload
//              withCertificateData:(NSData*)verificationCertificateData
//                  rootCertificate:(NSData*)verificationCertificateRootCertificateData;
//{
//    enter_open_ssl();
//    PKCS7 *pkcs7 = AWGetPKCS7FromData(payload);
//    if (pkcs7 == NULL ) {
//        exit_open_ssl();
//        return nil;
//    }
//
//    CertificateWrapper *verificationX509 = [[CertificateWrapper alloc] initWithCertificateData:verificationCertificateData];
//    if(verificationX509 ==nil) {
//        PKCS7_free(pkcs7);
//        exit_open_ssl();
//        return nil;
//    }
//
//    STACK_OF(X509) *stack = sk_X509_new_null();
//    sk_X509_push(stack, verificationX509.certificate);
//    X509_STORE *m_store = X509_STORE_new();
//
//    if(verificationCertificateRootCertificateData != nil) {
//        CertificateWrapper *verificationRootX509 = [[CertificateWrapper alloc] initWithCertificateData:verificationCertificateRootCertificateData];
//        if(verificationRootX509 == nil) {
//            X509_STORE_free(m_store);
//            PKCS7_free(pkcs7);
//            sk_X509_free(stack);
//            exit_open_ssl();
//            return nil;
//        }
//
//        X509_STORE_add_cert(m_store, verificationRootX509.certificate);
//    }
//
//    NSData *returnData = nil;
//    BIO *outBIO = BIO_new(BIO_s_mem());
//    int code = PKCS7_verify(pkcs7, stack, m_store, NULL, outBIO, PKCS7_NOINTERN | PKCS7_NOVERIFY);
//    if (code == 1) {
//        returnData = AWGetDataFromBIO(outBIO);
//    } else {
//        NSLog(@"PKCS7 Verify Data: error %@", AWGetOpenSSLError());
//    }
//    sk_X509_free(stack);
//    X509_STORE_free(m_store);
//    BIO_free(outBIO);
//    PKCS7_free(pkcs7);
//    exit_open_ssl();
//    return returnData;
//}


@end
