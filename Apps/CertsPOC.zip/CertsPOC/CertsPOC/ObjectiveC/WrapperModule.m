//
//  WrapperModule.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

#import "WrapperModule.h"

#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/rand.h>
#include <openssl/pem.h>
#include <openssl/err.h>
#include <openssl/crypto.h>
#include <xsw/crypto.h>

@interface WrapperModule()
@property(atomic, class, readwrite, getter=isReady) BOOL ready;
+(void) initializeModule;
@end

@implementation WrapperModule

static BOOL isModuleReady = NO;
static dispatch_queue_t initializationQueue = nil;

+ (BOOL)isReady {
    @synchronized (self) {
        return isModuleReady;
    }
}

+ (void)setReady:(BOOL)ready {
    @synchronized (self) {
        isModuleReady = ready;
    }
}

+(void) initializeModule {
    @synchronized (self) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            XSW_Crypto_Init();
            WrapperModule.ready = YES;
        });
    }
}

+(void) makeModuleReadyWithCompletion:(nullable dispatch_block_t) completion {

    // Initialize the queue
    static dispatch_once_t initializationQueueCreationOnceToken;
    dispatch_once(&initializationQueueCreationOnceToken, ^{
        // Make sure the blocks submitted this queue is run at high QOS but not as high as main queue's QOS.
        dispatch_queue_attr_t attributes = dispatch_queue_attr_make_with_qos_class(DISPATCH_QUEUE_SERIAL, QOS_CLASS_USER_INITIATED, 0);
        initializationQueue = dispatch_queue_create("com.vmware.ws1sdk.cmwrapper.initialization", attributes);
    });

    // Check if the Module is not initialized yet. if not start initialization
    if (WrapperModule.ready == NO) {
        dispatch_async(initializationQueue, ^{
            [self initializeModule];
        });
    }

    // Finally inform the caller that we are initialized.
    if (completion != nil) {
        dispatch_async(initializationQueue, completion);
    }
}


@end

@implementation CMWrapperModuleAPIObject

+(void)initialize {
    [super initialize];
}

@end
