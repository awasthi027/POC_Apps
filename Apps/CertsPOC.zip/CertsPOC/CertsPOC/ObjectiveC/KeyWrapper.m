//
//  KeyWrapper.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#import <Foundation/Foundation.h>
#import "KeyWrapper.h"

@implementation KeyWrapper

- (instancetype)initWithPrivateKey:(NSData* )privateKey
                          publicKey:(NSData* )publicKey {
    self.privateKey = privateKey;
    self.publicKey = publicKey;
  
    return  self;
}

@end

