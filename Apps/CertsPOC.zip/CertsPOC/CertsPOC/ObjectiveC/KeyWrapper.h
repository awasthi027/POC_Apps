//
//  KeyWrapper.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#import <Foundation/Foundation.h>

@interface KeyWrapper: NSObject
/** Serial number of the certificate */
@property (nonatomic, nullable) NSData *publicKey;
/** Serial number of the certificate */
@property (nonatomic, nullable) NSData *privateKey;

- (instancetype _Nullable ) initWithPrivateKey:(NSData* _Nullable )privateKey
                                     publicKey:(NSData* _Nullable )publicKey;
@end
