//
//  OpenSSLUtils.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//


#import <Foundation/Foundation.h>
#import "KeyWrapper.h"

@interface OpenSSLUtils: NSObject

+ (KeyWrapper *)createPublicAndPrivateDummyKey;

@end
