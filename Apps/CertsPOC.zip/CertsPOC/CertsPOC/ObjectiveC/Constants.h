//
//  Constants.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#ifndef Constants_h
#define Constants_h

NSString *kAWCertificateSubjectName = @"AWCertificateSubjectName";
NSString *kAWCertificateUserID      = @"AWUserID";
NSString *kAWCertificateValidity    = @"AWCertificateValidity";




#endif /* Constants_h */
