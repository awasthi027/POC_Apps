//
//  OpenSSLHelper.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#ifndef OpenSSLHelper_h
#define OpenSSLHelper_h


#endif /* OpenSSLHelper_h */
#include <openssl/bio.h>
#include <openssl/pkcs12.h>

#import <Foundation/Foundation.h>



void enter_open_ssl(void);
void exit_open_ssl(void);
/**
 OpenSSL Helpers for most common operations that are needed across other public
 Helpers.
 */

/**
 Conversion From and To to BIO
 */

/*!
 @brief Converts given data into openssl BIO Structure

 @discussion This method takes any data for certificate, key, pkcs7 packet etc
 and given back BIO that can be used with openssl methods.

 To use it, simply call AWGetBIOForData(data)

 @param  data The data you want to convert into openssl input BIO structure.

 @return BIO The BIO structure that can be passed to openssl functions.
 */
BIO * _Nullable AWGetBIOForData(NSData * _Nonnull data);

/*!
 @brief Returns the Error from last openssl operation.

 @discussion You can query this method to get the stack of errors happened during an openssl operation.

 To Use: NSError *error = AWGetOpenSSLError()

 @return NSError error object with error code and description.
 */
NSError * _Nullable AWGetOpenSSLError(void);

EVP_PKEY * _Nullable AWGetRSAPublicKey(NSData * _Nullable publicKey);


/*!
 @brief Generates Public-Private Key Pair for the required bit size.

 @discussion This method uses opensssl RSA_generate_key to generate public private
 key pair.

 To use it,
 NSData *publicKey = nil;
 NSData *privateKey = nil;
 AWGenerateRSAKeyPair(1024, &publicKey, &privateKey)

 @param  keySizeInBits RSA Key Size, 512, 1024, 2048, 4096, 8192 or 16k only.

 @param  publicKey reference to NSData to store generate public key.

 @param  privateKey reference to NSData to store generate private key.

 @return BOOL Returns whether RSA Key Generation Success or failed.
 */
BOOL AWGenerateRSAKeyPair(int keySizeInBits, NSData *_Nonnull* _Nullable publicKey, NSData *_Nonnull* _Nullable privateKey);

/*!
 @brief Provides the detailed X509 name

 @discussion You should provide a valid X509_NAME and a flag which specifies the format of the detail

 To use it, simply call AWGetDetailedX509Name(subject, XN_FLAG_RFC2253)

 @param flag The format of the detail

 @return NSString Detailed X509 name in the specified format.
 */
NSString * _Nullable AWGetDetailedX509Name(X509_NAME * _Nullable name, unsigned long flag);

/*!
 @brief Converts given openssl BIO Structure into NSData

 @discussion This method takes BIO structure output from openssl methods like
 encrypt, sign, generate keys etc and return NSData representation.

 To use it, simply call AWGetDataFromBIO(data)

 @param  bio The BIO you want to serialize as NSData.

 @return NSData serialized BIO to NSData. Returns nil if input BIO is nil.
 */
NSData * _Nullable AWGetDataFromBIO(BIO * _Nonnull bio);

/*!
 @brief Parses the given PKCS12 structure and return representing binary data.

 @discussion When you have PKCS12 structure and need to binary representation of it, you should use this function.

 To Use: NSData *p12Data = AWGetDataFromPKCS12(p12)

 @return NSData or nil if operation can't be completed.
 */
NSData * _Nullable AWGetDataFromPKCS12(PKCS12 * _Nonnull pkcs12);

NSData *AWPKCS12UpdatePassword(NSData *p12Data, NSString *oldPassword, NSString *newPassword);
EVP_PKEY *AWGetRSAPrivateKey(NSData *privateKey, NSString *password);
