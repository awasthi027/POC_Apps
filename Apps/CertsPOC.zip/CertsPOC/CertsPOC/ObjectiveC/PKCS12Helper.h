//
//  PKCS12Helper.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

#ifndef PKCS12Helper_h
#define PKCS12Helper_h


#endif /* PKCS12Helper_h */


@interface PKCS12Helper: NSObject

+ (NSData*) createPKCS12DataFromDer:(NSData*)certDerData privateKeyPEM:(NSData*)pKeyPemData password:(NSString* )password;
+ (NSData *)updatePKCS12Password:(NSData *)p12Data oldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword;
@end
