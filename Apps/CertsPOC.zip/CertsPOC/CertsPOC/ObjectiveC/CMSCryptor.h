//
//  CMSCryptor.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 24/12/23.
//

#ifndef CMSCryptor_h
#define CMSCryptor_h

#import "WrapperModule.h"

#endif /* CMSCryptor_h */

@interface CMSCryptor : CMWrapperModuleAPIObject
/*!
 @brief Encrypts payload using certificate public key

 @discussion This method will use openssl CMS_encrypt to encrypt the payload and return CMS enveloped cipher data.

 To use it, simply call @c[AWCMSCryptor encrypt:payloadData certificateData:certificateData];

 @param  payload Plain Text Data to encrypt

 @param  certificate X509 certificate with public key to encrypt.

 @return NSData CMS Enveloped cipher Data. nil if the payload is nil or certificate data is empty or bad.
 */
+(NSData* _Nullable) encrypt:(NSData* _Nullable)payload
             certificateData:(NSData* _Nullable)certificate;

+ (NSData* _Nullable) decrypt:(NSData* _Nullable)cmsData
     privateKeyData:(NSData* _Nullable)privateKeyData
           password:(NSString* _Nullable)password;

@end
