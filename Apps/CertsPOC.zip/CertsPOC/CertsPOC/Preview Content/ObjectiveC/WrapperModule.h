//
//  WrapperModule.h
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

#import <Foundation/Foundation.h>
@interface WrapperModule: NSObject

/**
 Class method to return whether this module is ready overall,

 @return true if the module is ready and can make various API calls.
 */
@property(atomic, class, readonly, getter=isReady) BOOL ready;

/**
 Class method to make the module ready before other API Usage.
 */
+(void) makeModuleReadyWithCompletion:(nullable dispatch_block_t) completion;


@end
