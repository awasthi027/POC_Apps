//
//  PKCS12Helper.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 23/12/23.
//

#import <Foundation/Foundation.h>
#import "PKCS12Helper.h"
#import "OpenSSLHelper.h"

#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/pem.h>
@implementation PKCS12Helper

+ (NSData*) createPKCS12DataFromDer:(NSData*)certDerData privateKeyPEM:(NSData*)pKeyPemData password:(NSString*)password {
    NSData *returnData = nil;

    if (certDerData == nil || pKeyPemData == nil || password == nil || [password isEqualToString:@""]) {
        return nil;
    }

    enter_open_ssl();
    // reads cert data into BIO and then into X509 format.
    BIO *certificateBIO = AWGetBIOForData(certDerData);
    X509 *certX509 = d2i_X509_bio(certificateBIO, NULL);
    BIO_free(certificateBIO);

    // reads key data into BIO and then into EVP_PKEY format.
    BIO *privateKeyBIO = AWGetBIOForData(pKeyPemData);
    EVP_PKEY *pKey = nil;
    PEM_read_bio_PrivateKey(privateKeyBIO, &pKey, nil, nil);
    BIO_free(privateKeyBIO);

    // verifies that the private key is not nil, and actually belongs with the certificate given.
    if (pKey == nil || X509_check_private_key(certX509, pKey) == false) {
        NSLog(@"PK error while creating P12 from X509");
        // Clean up and return nil;
        if (certX509) {
            X509_free(certX509);
        }
        if (pKey) {
            EVP_PKEY_free(pKey);
        }
        exit_open_ssl();
        return nil;
    }

    const char *pass = [password cStringUsingEncoding:NSUTF8StringEncoding];

    PKCS12 *pkcs12Cert;


    int nid_cert = NID_pbe_WithSHA1And3_Key_TripleDES_CBC;

    pkcs12Cert = PKCS12_create((char*)pass, certX509->name, pKey, certX509, NULL, 0, nid_cert, 0, 0, 0);

    // Clean up before returning p12 data.
    if (pkcs12Cert) {
        returnData =  AWGetDataFromPKCS12(pkcs12Cert);
        PKCS12_free(pkcs12Cert);
    }

    if (certX509) {
        X509_free(certX509);
    }

    if (pKey) {
        EVP_PKEY_free(pKey);
    }

    exit_open_ssl();
    return returnData;
}

+ (NSData *)updatePKCS12Password:(NSData *)p12Data oldPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword {
    enter_open_ssl();
    NSData* updatedData = AWPKCS12UpdatePassword(p12Data, oldPassword, newPassword);
    exit_open_ssl();
    return updatedData;
}

@end
