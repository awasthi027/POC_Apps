//
//  OpenSSLUtils.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//


#ifndef OpenSSLUtils_h
#define OpenSSLUtils_h

#import "OpenSSLUtils.h"
#import "KeyWrapper.h"
#import "OpenSSLHelper.h"

#endif /* OpenSSLUtils_h */



@implementation OpenSSLUtils

+ (KeyWrapper *)createPublicAndPrivateDummyKey {
    NSData *publicKey = nil;
    NSData *privateKey = nil;
    AWGenerateRSAKeyPair(2048, &publicKey, &privateKey);
    return [[KeyWrapper alloc] initWithPrivateKey: privateKey publicKey: publicKey];
}

@end
