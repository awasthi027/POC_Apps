//
//  CertificateWrapper.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//




#import <Foundation/Foundation.h>
#import "CertificateWrapper.h"
#import "Constants.h"
#import "OpenSSLHelper.h"

#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/rand.h>
#include <openssl/pem.h>
#include <openssl/err.h>

unsigned long kAWXNFormatRFC2253    = XN_FLAG_RFC2253;
unsigned long kAWXNFormatOneLine    = XN_FLAG_ONELINE;
unsigned long kAWXNFormatMultiLine  = XN_FLAG_MULTILINE;

@interface CertificateWrapper ()
@property (nonatomic, assign) X509 *certificate;
@end


@implementation CertificateWrapper

- (instancetype) initWithAttributes:(NSDictionary*)attributes
                          publicKey:(NSData*)publicKey {
    if (publicKey == nil) {
        return nil;
    }

    NSString *commonName = attributes[kAWCertificateSubjectName];
    if (commonName.length <= 0 ) {
        return nil;
    } else if (commonName.length > 64) { // Maximum length of 64 according to RFC 528
        commonName = [commonName substringToIndex: 64];
    }

    NSString *userID = attributes[kAWCertificateUserID];
    if (userID.length <= 0) {
        return nil;
    }

    NSString *interVal = attributes[kAWCertificateValidity];
    long long interval = [interVal longLongValue];
    if (interval < 1) {
        interval = 10 * 365 * 24 * 60 * 60;  //10 years
    }

    enter_open_ssl();
    X509 *x509cert = X509_new();
    X509_set_version(x509cert, 2);

    // Random Serial Number
    uint8_t *serial = [self generateRandomBytes: 16];

    ASN1_INTEGER *i = X509_get_serialNumber(x509cert);
    i->length = 16;
    i->data = serial;

    X509_gmtime_adj(X509_get_notBefore(x509cert), 0);
    X509_gmtime_adj(X509_get_notAfter(x509cert), (long)interval);


    X509_NAME *xname = X509_get_subject_name(x509cert);
    NSData *identifier = [userID dataUsingEncoding:NSUTF8StringEncoding];
    NSData *cnData = [commonName dataUsingEncoding:NSUTF8StringEncoding];

    X509_NAME_add_entry_by_txt(xname, "UID", MBSTRING_UTF8, identifier.bytes, (int)identifier.length, -1, 0);
    X509_NAME_add_entry_by_txt(xname, "CN", MBSTRING_UTF8, cnData.bytes, (int)cnData.length, -1, 0);

    X509_set_issuer_name(x509cert, xname);

    EVP_PKEY *pkey = AWGetRSAPublicKey(publicKey);
    if (pkey != NULL && X509_set_pubkey(x509cert, pkey) == 1) {
        self.certificate = x509cert;
    } else {
        if (x509cert != nil) {
            X509_free(x509cert);
        }
        NSError *returnError = AWGetOpenSSLError();
        NSLog(@"Cert Create Error %@", returnError);
    }

    EVP_PKEY_free(pkey);
    if (self.certificate == nil) {
        exit_open_ssl();
        return nil;
    }

    exit_open_ssl();
    return self;
}
- (void)setCertificate:(X509 *)certificate {
    enter_open_ssl();
    if ((certificate != _certificate)
        && (_certificate != nil)) {
        X509_free(_certificate);
    }
    _certificate = certificate;
    exit_open_ssl();
}

- (NSData*) exportCertificateData {
    if (self.certificate == nil) {
        return  nil;
    }

    enter_open_ssl();
    BIO *certBIO = BIO_new(BIO_s_mem());
    NSData *data = nil;
    if (i2d_X509_bio(certBIO, self.certificate) == 1) {
        data = AWGetDataFromBIO(certBIO);
    } else {
        NSLog(@"Export Cert Error: %@", AWGetOpenSSLError());
    }

    BIO_free(certBIO);
    exit_open_ssl();
    return data;
}

- (instancetype) initWithCertificateData:(NSData*) data {
    enter_open_ssl();
    NSError *pemError = nil;
    NSError *derError = nil;

    if (self = [super init]) {
        BIO *certificateBIO = AWGetBIOForData(data);
        self.certificate = PEM_read_bio_X509(certificateBIO, NULL, 0, NULL);
        BIO_free(certificateBIO);

        if (self.certificate == nil) {
            pemError = AWGetOpenSSLError();
            certificateBIO = AWGetBIOForData(data);
            self.certificate = d2i_X509_bio(certificateBIO, NULL);
            BIO_free(certificateBIO);
        }

        if (self.certificate == nil) {
            derError = AWGetOpenSSLError();
        }
    }
    if (self.certificate == nil) {
        NSLog(@"Error trying to parse as PEM: %@", pemError);
        NSLog(@"Error trying to parse as DER: %@", derError);
        exit_open_ssl();
        return nil;
    }
    exit_open_ssl();
    return self;
}

- (uint8_t *)generateRandomBytes: (int)length {

    // Random Serial Number
    uint8_t *serial;
    serial = malloc(length + 1);
    memset(serial, 0x0, length + 1);

    RAND_bytes(serial, length);
    /* Making sure generated random bytes doesn't contain first bytes as Zero.
     if first byte is zero, We will keep generating new random bytes until get nonzero first byte
     Fixed issue: https://jira-euc.eng.vmware.com/jira/browse/ISDK-177156
     */
    NSInteger firstByte = serial[0];
    while (length > 0 && firstByte == 0) {
        NSLog(@"First Byte: %ld",(long)firstByte);
        RAND_bytes(serial, length);
        firstByte = serial[0];
    }
   // [self printDataBytes: serial length: length];
    return  serial;

}

//MARK: ========================================================== Certificate Properties

- (NSData *)serialNumber {
    if (self.certificate == nil) {
        return nil;
    }
    enter_open_ssl();
    ASN1_INTEGER *serial = X509_get_serialNumber(self.certificate);
    NSData* result = [NSData dataWithBytes:serial->data length:serial->length];
    exit_open_ssl();
    return result;
}

- (BOOL)isValid {
    if (self.certificate == nil) {
        return  NO;
    }
    enter_open_ssl();
    ASN1_TIME *afterTime = self.certificate->cert_info->validity->notAfter;
    BOOL result = (X509_cmp_current_time(afterTime) > 0);
    exit_open_ssl();
    return result;
}

- (BOOL)isCACert {
    enter_open_ssl();
    // User openssl's CA Check method to verify if current Cert is CA Cert
    int result = X509_check_ca(self.certificate);
    exit_open_ssl();
    // Even though 2,3 and 4 seems to be representing CA certs, as per NIAP without Basic Constraints, it should not be used as CA.
    return (result == 1);
}


- (NSString *)subjectName {
    return [self getAttributeAtIndex:1];
}

- (NSString *)subjectUserID {
    return [self getAttributeAtIndex:0];
}

- (NSString *)commonName {
    if (self.certificate == nil) {
        return nil;
    }
    enter_open_ssl();
    X509_NAME *subject = X509_get_subject_name(self.certificate);
    NSString* result = [[self entryFromX509Name:subject forKey:@"commonName"] firstObject];
    exit_open_ssl();
    return result;
}

- (NSString*) getAttributeAtIndex:(NSUInteger)index {
    if (self.certificate == nil) {
        return nil;
    }

    enter_open_ssl();
    X509_NAME *name = X509_get_subject_name(self.certificate);
    X509_NAME_ENTRY *subjectEntry = X509_NAME_get_entry(name, (int)index);
    if (subjectEntry && subjectEntry->value) {
        NSData *subjectData = [NSData dataWithBytes:subjectEntry->value->data length:subjectEntry->value->length];
        NSString* result = [[NSString alloc] initWithData:subjectData encoding:NSUTF8StringEncoding];
        exit_open_ssl();
        return result;
    }

    exit_open_ssl();
    return nil;
}

- (NSString *)issuer {
    if (self.certificate == nil) {
        return nil;
    }
    enter_open_ssl();
    X509_NAME *issuerName = X509_get_issuer_name(self.certificate);
    NSString *issuer = [[self entryFromX509Name:issuerName forKey:@"organizationName"] firstObject];

    if(issuer == nil) {
        issuer = [[self entryFromX509Name:issuerName forKey:@"commonName"] firstObject];
    }

    exit_open_ssl();
    return issuer;
}

- (NSArray<NSString *> *)entryFromX509Name:(X509_NAME *)name forKey:(NSString *)key {
    enter_open_ssl();
    NSMutableArray<NSString *> *entries = [NSMutableArray<NSString *> array];
    int entryCount = X509_NAME_entry_count(name);
    for (int i=0; i<entryCount; i++) {
        X509_NAME_ENTRY *entry = X509_NAME_get_entry(name, i);
        char buff[1024];
        OBJ_obj2txt(buff, 1024, entry->object, 0);
        NSString *entryKey = [NSString stringWithUTF8String:buff];
        if ([entryKey isEqualToString:key]) {
            NSString *value = [[NSString alloc] initWithData:[NSData dataWithBytes:entry->value->data length:entry->value->length]
                                                    encoding:NSUTF8StringEncoding];

            [entries addObject:value];
        }
    }

    exit_open_ssl();
    return entries;
}

- (NSString *)emailAddress {
    if (self.certificate == nil) {
        return nil;
    }

    enter_open_ssl();
    X509_NAME *subject = X509_get_subject_name(self.certificate);
    NSString *email = [[self entryFromX509Name:subject forKey:@"emailAddress"] firstObject];
    // If the email address is not available in the subject, check the altname
    if (email == nil) {
        STACK_OF(GENERAL_NAME) *altName = X509_get_ext_d2i(self.certificate, NID_subject_alt_name, NULL, NULL);
        if(altName != NULL) {
            email = [self nameFromX509AltName:altName type:GEN_EMAIL];
        }
        GENERAL_NAMES_free(altName);
    }
    exit_open_ssl();
    return email;
}

- (NSString *)nameFromX509AltName:(STACK_OF(GENERAL_NAME) *)altname type:(int)type {
    return [self nameFromX509AltName:altname type:type nid:NID_undef];
}

- (NSString *)nameFromX509AltName:(STACK_OF(GENERAL_NAME) *)altname type:(int)type nid:(int)nid {
    enter_open_ssl();
    NSString *name = nil;
    int entryCount = sk_GENERAL_NAME_num(altname);
    for (int i=0; i<entryCount; i++) {
        GENERAL_NAME *entry = sk_GENERAL_NAME_value(altname, i);
        if (entry->type == type) {
            // Currently boxer and PIV-D uses email, upn is used by PIV-D
            // There are other values available in GENERAL_NAME.
            // Handle other types, if any other data needed.
            unsigned char *buff = NULL;
            switch (type) {
                case GEN_OTHERNAME:
                    if (OBJ_obj2nid(entry->d.otherName->type_id) == nid) {
                        buff = ASN1_STRING_data(entry->d.otherName->
                                                value->value.asn1_string);
                        name = [NSString stringWithUTF8String:(char *)buff];
                    }
                    break;
                case GEN_EMAIL:
                    buff = ASN1_STRING_data(entry->d.rfc822Name);
                    name = [NSString stringWithUTF8String:(char *)buff];
                    break;
                case GEN_DNS:
                    buff = ASN1_STRING_data(entry->d.dNSName);
                    name = [NSString stringWithUTF8String:(char *)buff];
                    break;
                case GEN_URI:
                    buff = ASN1_STRING_data(entry->d.uniformResourceIdentifier);
                    name = [NSString stringWithUTF8String:(char *)buff];
                    break;

                default:
                    break;
            }
            break;
        }
    }
    exit_open_ssl();
    return name;
}

- (BOOL) canUseFor:(KeyUsage)usage {
    if (self.certificate == nil) {
        return  NO;
    }
    enter_open_ssl();
    X509_check_ca(self.certificate);
    BOOL result = usage & self.certificate->ex_kusage;
    exit_open_ssl();
    return result;
}

- (BOOL) hasExtendedUsage:(ExtendedKeyUsage)eUsage {
    if (self.certificate == nil) {
        return  NO;
    }

    enter_open_ssl();
    X509_check_ca(self.certificate);
    BOOL result = eUsage & self.certificate->ex_xkusage;
    exit_open_ssl();
    return result;
}

- (NSString *)subjectDetailWithFormat:(SubjectFormat )format {
    if (self.certificate == nil) {
        return  nil;
    }
    enter_open_ssl();
    X509_NAME *subject = X509_get_subject_name(self.certificate);
    NSString* result = AWGetDetailedX509Name(subject, [self subjectFormateLongValue: format]);
    exit_open_ssl();
    return result;
}

- (NSString *)issuerDetailWithFormat: (SubjectFormat )format {
    if (self.certificate == nil) {
        return  nil;
    }

    enter_open_ssl();
    X509_NAME *issuer = X509_get_issuer_name(self.certificate);
    NSString* result = AWGetDetailedX509Name(issuer, [self subjectFormateLongValue: format]);
    exit_open_ssl();
    return result;
}

- (unsigned long)subjectFormateLongValue: (SubjectFormat) format {
    switch (format) {
        case RFC2253:
            return  kAWXNFormatRFC2253;
            break;
        case OneLine:
            return kAWXNFormatOneLine;
            break;
        case MultiLine:
            return kAWXNFormatMultiLine;
            break;
        default:
            return 0;
            break;
    }
    return 0;
}

//MARK: ========================================================== Utility Methods
- (void)printDataBytes: (uint8_t *)bytes
                length: (int) length {

    for(int i = 0; i < length; i++ ){
        NSLog(@"Index: %d, hexValue: %x, DecimalValue: %d",i,bytes[i],bytes[i]);
    }
}


@end


