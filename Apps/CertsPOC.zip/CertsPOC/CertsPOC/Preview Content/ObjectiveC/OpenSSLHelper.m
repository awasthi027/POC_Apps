//
//  OpenSSLHelper.m
//  CertsPOC
//
//  Created by Ashish Awasthi on 21/12/23.
//

#import <openssl/pem.h>
#import <openssl/rsa.h>
#import <openssl/err.h>
#import <openssl/x509.h>
#include <openssl/x509v3.h>

#import <Foundation/Foundation.h>
#import "OpenSSLHelper.h"

#define kAWPKCS8Cipher EVP_aes_128_cbc()

BIO * _Nullable AWGetBIOForData(NSData * _Nonnull data)
{
    if(data == nil) {
        return nil;
    }
    BIO *writeBio = BIO_new(BIO_s_mem());
    BIO_write(writeBio, data.bytes, (int)data.length);
    return writeBio;
}

NSError *AWGetOpenSSLError(void)
{
    NSError *retErr = nil;
    unsigned long e = ERR_get_error();
    char *errstring = ERR_error_string(e, NULL);
    NSString *errorString = [NSString stringWithFormat:@"%s", errstring];
    NSMutableDictionary *userInfo = [NSMutableDictionary dictionaryWithObject:errorString forKey:NSLocalizedDescriptionKey];
    retErr = [NSError errorWithDomain:@"aw.sdk.openssl" code:e userInfo:userInfo];
    return retErr;
}


EVP_PKEY *AWGetRSAPublicKey(NSData *publicKey)
{
    if (publicKey == nil) {
        return NULL;
    }

    const unsigned char *bytes = publicKey.bytes;
    /* Check if the key is in PEM format */
    BIO *publicKeyBIO = AWGetBIOForData(publicKey);
    RSA *rsa = PEM_read_bio_RSAPublicKey(publicKeyBIO, NULL, NULL, NULL);
    BIO_free(publicKeyBIO);

    if (rsa == NULL) {
        /* Check if the key can be read using DER parser */
        rsa =  d2i_RSAPublicKey(&rsa, &bytes, publicKey.length);
    }

    if (rsa != NULL) {
        /* If Key reading successful... */
        EVP_PKEY *pkey = EVP_PKEY_new();
        EVP_PKEY_assign_RSA(pkey, rsa);
        return  pkey;
    }

    return NULL;
}

BOOL AWGenerateRSAKeyPair(int keySizeInBits, NSData **publicKey, NSData **privateKey)
{
   // PRINT_MODULE_USAGE_GUIDELINES(@"Using AWCMWrapperModule API without initializing is not guaranteed to work always");

    if(publicKey == nil || privateKey == nil) {
        return NO;
    }

    enter_open_ssl();
    RSA *rsa = RSA_generate_key(keySizeInBits, RSA_F4, NULL, NULL);

    /* Read Private Key */
    BIO *bio = BIO_new(BIO_s_mem());
    PEM_write_bio_RSAPrivateKey(bio, rsa, NULL, NULL, 0, NULL, NULL);
    int keylen = BIO_pending(bio);
    void *pem_key = malloc(keylen);
    memset(pem_key, 0, keylen);
    BIO_read(bio, pem_key, keylen);
    BIO_free_all(bio);
    NSData *privateKeyData = [[NSData alloc] initWithBytesNoCopy:pem_key length:keylen freeWhenDone:YES];

    /* Read public Key */
    bio = BIO_new(BIO_s_mem());
    PEM_write_bio_RSAPublicKey(bio, rsa);
    keylen = BIO_pending(bio);
    pem_key = malloc(keylen);
    memset(pem_key, 0, keylen);
    BIO_read(bio, pem_key, keylen);
    BIO_free_all(bio);
    NSData *publicKeyData = [[NSData alloc] initWithBytesNoCopy:pem_key length:keylen freeWhenDone:YES];

    RSA_free(rsa);
    if (privateKey) {
        *privateKey = privateKeyData;
    }
    if(publicKey) {
        *publicKey = publicKeyData;
    }

    BOOL result = ((*publicKey).length > 0 && (*privateKey).length > 0);
    exit_open_ssl();
    return result;
}

NSString *AWGetStringFromBIO(BIO *bio) {
    NSString *returnString = nil;

    if (bio != nil) {
        int bytesWritten = (int)BIO_number_written(bio);
        int size = bytesWritten + 1;
        char *buff = malloc(size);
        memset(buff, 0, size);
        BIO_read(bio, buff, size);
        returnString = [[NSString alloc] initWithFormat: @"%s", buff];
        free(buff);
    }

    return returnString;
}

NSString * _Nullable AWGetDetailedX509Name(X509_NAME * _Nullable name, unsigned long flag)
{
    NSString *detailedName = nil;

    BIO *outBio = BIO_new(BIO_s_mem());
    if(X509_NAME_print_ex(outBio, name, 0, flag) > 0) {
        detailedName = AWGetStringFromBIO(outBio);
    }
    BIO_free(outBio);

    return detailedName;
}

NSData *AWGetDataFromBIO(BIO *bio) {
    NSData *returnData  = nil;

    if (bio != nil) {
        char *buff = malloc(bio->num_write);
        BIO_read(bio, buff, (int)(bio->num_write));
        returnData  = [NSData dataWithBytes:buff length:bio->num_write];
        free(buff);
    }

    return returnData;
}

NSData *AWGetDataFromPKCS12(PKCS12 *pkcs12) {
    BIO *p12Bio = BIO_new(BIO_s_mem());

    i2d_PKCS12_bio(p12Bio, pkcs12);

    NSData *returnData = AWGetDataFromBIO(p12Bio);
    BIO_free(p12Bio);
    return returnData;
}

PKCS12 *AWGetPKCS12FromData(NSData *data) {
    BIO *p12BIO = AWGetBIOForData(data);
    PKCS12 *p12 = d2i_PKCS12_bio(p12BIO, NULL);
    BIO_free(p12BIO);
    return p12;
}

NSData *AWPKCS12UpdatePassword(NSData *p12Data, NSString *oldPassword, NSString *newPassword)
{
    NSData *returnData = nil;

    if (oldPassword == NULL || newPassword == NULL || newPassword.length == 0) {
        return returnData;
    }

    PKCS12 *p12 = AWGetPKCS12FromData(p12Data);
    if (p12 == NULL) {
        return returnData;
    }

    const char *oldPasswordString = oldPassword.UTF8String;
    const char *newPasswordString = newPassword.UTF8String;

    if (PKCS12_newpass(p12, oldPasswordString, newPasswordString) == 0) {
        NSLog(@"Update password failed: error %@", AWGetOpenSSLError());
        PKCS12_free(p12);
        return returnData;
    }

    returnData = AWGetDataFromPKCS12(p12);
    PKCS12_free(p12);
    return returnData;
}





NSRecursiveLock* _openssl_lock(void) {
    static NSRecursiveLock *lock = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        lock = [[NSRecursiveLock alloc] init];
    });

    return lock;
}

//All Public methods must be using this method to make them Thread Safe. Remember that, the method will become non-reentrant.
void enter_open_ssl(void) {
    NSRecursiveLock *lock = _openssl_lock();
    [lock lock];
}

void exit_open_ssl(void) {
    NSRecursiveLock *lock = _openssl_lock();
    [lock unlock];
}
