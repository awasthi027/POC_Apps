//
//  OpenSSLCryptoOperation.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 24/12/23.
//

import Foundation

class OpenSSLCryptoViewModel: ObservableObject {

    var certificate: Data
    var password: String
    
    init(certificate: Data,
         password: String) {
        self.certificate = certificate
        self.password = password
    }

    func encrypt(data: Data) -> Data? {
        guard let result = Utils.certificateDataFromP12(p12Data: self.certificate,
                                                        password: self.password)
        else { return nil }

        guard let encrypted = CMSCryptor.encrypt(data, certificateData: result.certificateData) else {
            debugPrint("Failed to encrypt the data.")
           return nil
        }
        return encrypted
    }

    func decrypt(data: Data) -> Data? {
        guard let result = Utils.certificateDataFromP12(p12Data: self.certificate, 
                                                        password: self.password)
        else { return nil }

        let pemPrivateKey = Utils.privateKeyFrom(pkcs12Entry: result.pkcs12Entry)

        guard let decrypted = CMSCryptor.decrypt(data, privateKeyData: pemPrivateKey, password: self.password) else {
            debugPrint( "Failed to decrypt the data.")
            return nil
        }
        return decrypted
    }
}
