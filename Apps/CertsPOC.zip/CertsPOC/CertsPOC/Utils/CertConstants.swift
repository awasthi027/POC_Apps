//
//  CertConstants.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 22/12/23.
//

import Foundation

struct CertConstants {
    static let obfuscatedString                 = "tkioYseaPLrNsheIodoTgn4wuoAhTs!rsoi"
    static let obfuscatedCode: [UInt8]          = [32, 3, 0, 28, 16, 0, 43, 14, 36,
                                                   24, 26, 43, 35, 9, 22, 58, 24,
                                                   11, 29, 48, 62, 1, 65, 54, 7, 10,
                                                   13, 7, 59, 24, 72, 28, 20, 91, 72]
    static let p12Password                      = String(decoding: zip(obfuscatedString.utf8, obfuscatedCode).map(^), as: UTF8.self)
}
