//
//  Utils.swift
//  CertsPOC
//
//  Created by Ashish Awasthi on 22/12/23.
//

import Foundation

let privateKeyPKCS1Header = "-----BEGIN RSA PRIVATE KEY-----\n"
let privateKeyPKCS1Footer = "\n-----END RSA PRIVATE KEY-----"

class Utils: NSObject {
}
// MARK: Certificate Utils
extension Utils {

    static func dataFromFile(name: String,
                             withExtension ext: String) -> Data? {
        guard let fileURL = Bundle(for: Utils.self).url(forResource: name, withExtension: ext) else {
            debugPrint("invalid url")
            return nil
        }
        // Get data of a file.
        do {
            return try Data(contentsOf: fileURL)
        } catch {
            debugPrint("Not able to get data for file \(name).\(ext)")
        }
        return nil
    }

    static func certificateDataFromP12(p12Data: Data, password: String) -> (certificateData: Data, pkcs12Entry: PKCS12Entry)? {
        guard let parsedP12Data = PKCS12(p12Data: p12Data, password: password),
            let p12Object = parsedP12Data.entries.first,
            let cert = p12Object.certificate
            else {
              debugPrint("Couldn't get certificate data")
              return nil
            }
        return (SecCertificateCopyData(cert) as Data, p12Object)
    }

    static func reCreateCertificateWith(newPassword: String,
                                          p12Data: Data,
                                          password: String) -> Data? {

        guard let result = self.certificateDataFromP12(p12Data: p12Data, password: password)
            else { return nil }

        let pemPrivateKey = self.privateKeyFrom(pkcs12Entry: result.pkcs12Entry)
        return PKCS12Helper.createPKCS12Data(fromDer: result.certificateData, privateKeyPEM: pemPrivateKey, password: newPassword)
    }

    static func privateKeyFrom(pkcs12Entry: PKCS12Entry) -> Data? {
        let identity = pkcs12Entry.identity
        var privateKey: SecKey?
        _ = SecIdentityCopyPrivateKey(identity, &privateKey)
        guard let retrievedPrivateKey = privateKey else {
            return nil
        }

        guard let privateKeyData = self.convertSecKeyToData(retrievedPrivateKey) else {
            return nil
        }

        let pemPrivateKey = self.pkcs1ToPem(privateKeyData)
        
        return pemPrivateKey
    }
    
    static func publicAndPrivateKey(pkcs12Entry: PKCS12Entry) -> (publicKey: SecKey, privateKey: SecKey)? {
        let trust = pkcs12Entry.trust
        // Public Key
        guard let publicKey = SecTrustCopyKey(trust) else {
            debugPrint("publicKey Key is nil")
            return nil
        }
       // debugPrint("publicKey\(publicKey)")

        let identity = pkcs12Entry.identity
        var privateKey: SecKey?
        _ = SecIdentityCopyPrivateKey(identity, &privateKey)
        guard let pemPrivateKey = privateKey else {
            debugPrint("private Key data is nil")
            return nil
        }

        return (publicKey, pemPrivateKey)
    }

    static func convertSecKeyToData(_ key: SecKey) -> Data? {

        var query: [String: AnyObject] = [:]
        query[kSecClass as String] = kSecClassKey
        query[kSecAttrKeyType as String] = kSecAttrKeyTypeRSA
        query[kSecAttrApplicationTag as String] = "com.ashi.certsPOC.tempPrivateKey".data(using: .utf8) as AnyObject

        // Attributes
        var attributes: [String: AnyObject] = query
        attributes[kSecValueRef as String] = key
        attributes[kSecReturnData as String] = true as AnyObject

        var resultKeyDataRef: CFTypeRef?
        let resultStatus = SecItemAdd(attributes as CFDictionary, &resultKeyDataRef)

        guard resultStatus == errSecSuccess else {
            return nil
        }

        SecItemDelete(query as CFDictionary)

        let resultKeyObject = resultKeyDataRef as AnyObject
        guard let resultKeyData: Data = resultKeyObject as? Data else {
            return nil
        }

        return resultKeyData
    }

    static func pkcs1ToPem(_ keyData: Data) -> Data? {
        // Transform PKCS1 key data into Pem format.

        let privateKeyBase64 = keyData.base64EncodedString()

        let privateKeyPem = privateKeyPKCS1Header + privateKeyBase64 + privateKeyPKCS1Footer
        debugPrint("enhanced auth key string: \(privateKeyPem)")

        return privateKeyPem.data(using: .utf8)
    }

    static func changeCertificatePassword(newPassword: String,
                                          p12Data: Data,
                                         password: String) -> Data? {
        return PKCS12Helper.updatePKCS12Password(p12Data, oldPassword: password, newPassword: newPassword)
    }
}

// MARK: file Utils
extension Utils {
    static func save(data: Data,
                     toDirectory directory: String,
                     withFileName fileName: String) {

        guard let filePath = self.append(toPath: directory,
                                         withPathComponent: fileName) else {
            return
        }

        do {
            if #available(iOS 16.0, *) {
                try data.write(to: URL(filePath: filePath))
            } else {
                // Fallback on earlier versions
            }
        } catch {
            debugPrint("Error", error)
            return
        }

        debugPrint("Save successful Path: \(filePath)")
    }

    static func documentDirectory() -> String {
        let documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory,
                                                                    .userDomainMask,
                                                                    true)
        return documentDirectory[0]
    }

    private static func append(toPath path: String,
                               withPathComponent pathComponent: String) -> String? {
        if var pathURL = URL(string: path) {
            pathURL.appendPathComponent(pathComponent)

            return pathURL.absoluteString
        }

        return nil
    }

    static func readFile(from directory: String,
                  fileName: String) -> Data? {

        guard let filePath = self.append(toPath: directory,
                                         withPathComponent: fileName) else {
            return nil
        }
        do {
         // Get the saved data
            if #available(iOS 16.0, *) {
                let savedData = try Data(contentsOf: URL(filePath: filePath))
                return savedData
            } else {
                // Fallback on earlier versions
            }

        } catch {
         // Catch any errors
            debugPrint("Unable to read the file")
        }
        return nil
    }
}
