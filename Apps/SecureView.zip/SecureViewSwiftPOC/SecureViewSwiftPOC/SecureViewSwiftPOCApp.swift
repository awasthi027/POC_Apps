//
//  SecureViewSwiftPOCApp.swift
//  SecureViewSwiftPOC
//
//  Created by Ashish Awasthi on 06/01/24.
//

import SwiftUI

@main
struct SecureViewSwiftPOCApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    var body: some Scene {
        WindowGroup {
           // SnapShotPreventingView {
                MyView()
           // }
        }
    }
}
class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        debugPrint("ApplicationLifeCycle: didFinishLaunchingWithOptions")
        return true
    }

    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        debugPrint("ApplicationLifeCycle: open, sourceApplication")
        return true
    }

}
