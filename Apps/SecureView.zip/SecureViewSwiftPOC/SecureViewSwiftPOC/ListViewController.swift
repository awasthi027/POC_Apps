//
//  ListViewController.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 03/01/24.
//

import Foundation
import UIKit

class ListViewController: UIViewController {

    class func listViewController() -> ListViewController  {

        let storyboard = UIStoryboard.mainStoryBoard
        if let controller = storyboard.instantiateViewController(withIdentifier:
                                                                String(describing: ListViewController.self)) as? ListViewController {
           return controller
        }
        return  ListViewController()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "List View Controller"

    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }

    @IBAction func didClickOnDetailsButton(_ sender: AnyObject) {
        let detailsViewController = DetailsViewController.detailsViewController()
        self.navigationController?.pushViewController(detailsViewController, animated: true)
    }
}


extension UIStoryboard {
    /// Main storyboard
    static var mainStoryBoard: UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }

    func instantiateViewController<T>(withIdentifier identifier: T.Type) -> T? where T: UIViewController {
        let className = String(describing: identifier)
        return self.instantiateViewController(withIdentifier: className) as? T
    }
}

extension UIViewController {

    func navigate(controller: UIViewController) {
        self.show(controller, sender: nil)
    }
}


import SwiftUI
struct MyView: UIViewControllerRepresentable {
    typealias UIViewControllerType = UINavigationController
    func makeUIViewController(context: Context) -> UINavigationController {
        let vc = ListViewController.listViewController()
        // Do some configurations here if needed.
        return UINavigationController.init(rootViewController: vc)
    }

    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {
        // Updates the state of the specified view controller with new information from SwiftUI.
    }
}
