//
//  SecureViewController.swift
//  SecureViewSwiftPOC
//
//  Created by Ashish Awasthi on 09/01/24.
//
import UIKit
import SwiftUI

class SecureViewController: UIViewController {

    class func secureViewController(viewController: UIViewController) -> SecureViewController {
//        let storyboard = UIStoryboard.mainStoryBoard
//        if let controller = storyboard.instantiateViewController(withIdentifier:
//                                                                    String(describing: SecureViewController.self)) as? SecureViewController {
//            return controller
//        }
        let secureViewController = SecureViewController()
        let secureTxtField = UITextField()
        secureTxtField.isSecureTextEntry = true
        secureViewController.view.addSubview(secureTxtField)
        if let textLayoutView = secureTxtField.subviews.first {
            textLayoutView.addSubview(viewController.view)
        }
        return secureViewController
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Secure View"
    }
}

@nonobjc extension UIViewController {

    func add(_ child: UIViewController, frame: CGRect? = nil) {
        addChild(child)
        if let frame = frame {
            child.view.frame = frame
        }
        view.addSubview(child.view)
        child.didMove(toParent: self)
    }

    func remove() {
        willMove(toParent: nil)
        view.removeFromSuperview()
        removeFromParent()
    }
}
