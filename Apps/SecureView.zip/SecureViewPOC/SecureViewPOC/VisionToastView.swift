//
//  VisionToastView.swift
//  VUMEVision
//
//  Created by Tanuja Awasthi on 14/07/23.
//  Copyright © 2023 Copyright VUME Interctive Pvt. Ltd. All rights reserved.


import SwiftUI

struct VisionToastView: View {
    
    var type: VisionToastStyle
    var title: String
    var message: String
    var onCancelTapped: (() -> Void)

    var body: some View {

        VStack(alignment: .leading) {

            HStack(alignment: .top) {

                Image(systemName: type.iconFileName)
                    .foregroundColor(type.themeColor)

                VStack(alignment: .leading) {
                    Text(title)
                        .foregroundColor(.red)
                    Text(message)
                        .foregroundColor(.red.opacity(0.7))
                }

                Spacer(minLength: 10)

                Button {
                    onCancelTapped()
                } label: {
                    Image(systemName: "xmark")
                        .foregroundColor(Color.red)
                }
            }
            .padding()
        }
        .background(Color.init(hex: 0x1E465F))
        .overlay(
            Rectangle()
                .fill(type.themeColor)
                .frame(width: 6)
                .clipped()
            , alignment: .leading
        )
        .frame(minWidth: 0, maxWidth: .infinity)
        .cornerRadius(8)
        .shadow(color: Color.black.opacity(0.25), radius: 4, x: 0, y: 1)
        .padding(.horizontal, 16)
    }
}

struct VisionToastView_Previews: PreviewProvider {

  static var previews: some View {

    VStack {
        VisionToastView(
            type: .error,
            title: "Error",
            message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ") {}

        VisionToastView(
            type: .info,
            title: "Info",
            message: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. ") {}
    }
  }
}

public enum VisionToastStyle {
    case error
    case warning
    case success
    case info
}

extension VisionToastStyle {
    var themeColor: Color {
        switch self {
        case .error: return Color.red
        case .warning: return Color.orange
        case .info: return Color.blue
        case .success: return Color.green
        }
    }

    var iconFileName: String {
        switch self {
        case .info: return "info.circle.fill"
        case .warning: return "exclamationmark.triangle.fill"
        case .success: return "checkmark.circle.fill"
        case .error: return "xmark.circle.fill"
        }
    }
}

public struct VisionToast: Equatable {

    public var type: VisionToastStyle
    public var title: String
    public var message: String
    public var duration: Double
    public init(type: VisionToastStyle,
                title: String,
                message: String,
                duration: Double = 5) {
        self.type = type
        self.title = title
        self.message = message
        self.duration = duration
    }
}

extension View {
    public func toastView(toast: Binding<VisionToast?>) -> some View {
        self.modifier(FancyToastModifier(toast: toast))
    }
}

struct FancyToastModifier: ViewModifier {
    @Binding var toast: VisionToast?
    @State private var workItem: DispatchWorkItem?

    func body(content: Content) -> some View {
        content
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .overlay(
                ZStack {
                    mainToastView()
                        .offset(y: -175)
                }.animation(.spring(), value: toast)
            )
            .onChange(of: toast) { value in
                showToast()
            }
    }

    @ViewBuilder func mainToastView() -> some View {
        if let toast = toast {
            VStack {
                Spacer()
                VisionToastView(
                    type: toast.type,
                    title: toast.title,
                    message: toast.message) {
                        dismissToast()
                    }
            }
            .transition(.move(edge: .bottom))
        }
    }

    private func showToast() {
        guard let toast = toast else { return }

        UIImpactFeedbackGenerator(style: .light).impactOccurred()

        if toast.duration > 0 {
            workItem?.cancel()

            let task = DispatchWorkItem {
               dismissToast()
            }

            workItem = task
            DispatchQueue.main.asyncAfter(deadline: .now() + toast.duration, execute: task)
        }
    }

    private func dismissToast() {
        withAnimation {
            toast = nil
        }
        workItem?.cancel()
        workItem = nil
    }
}

extension Color {


    init(hex: Int) {
       self.init(
        red: Double((hex >> 16) & 0xFF),
        green: Double((hex >> 8) & 0xFF),
        blue: Double(hex & 0xFF)
       )
   }
}
