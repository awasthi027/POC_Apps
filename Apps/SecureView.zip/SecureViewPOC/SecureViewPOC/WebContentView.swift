//
//  WebContentView.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 03/01/24.
//

import SwiftUI

struct WebContentView: View {
    
    var body: some View {
        VStack {
            SwiftUIWebView(url: URL(string: "https://www.appcoda.com")!)
        }
    }
}

#Preview {
    WebContentView()
}
