//
//  SwiftUIWebView.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 03/01/24.
//


import SwiftUI
import WebKit

struct SwiftUIWebView: UIViewRepresentable {

    var url: URL

    func makeUIView(context: Context) -> WKWebView {
        return WKWebView()
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        let request = URLRequest(url: url)
        webView.load(request)
    }
}
