//
//  SecureNavigationView.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 02/01/24.
//

import SwiftUI

struct SecureNavigationView: View {

    var body: some View {
        VStack {
            Text("Show Security Key")
                GeometryReader {
                    let size = $0.size
                    Image(uiImage: UIImage(named: "ashish.jpeg") ?? UIImage())
                        .resizable()
                        .aspectRatio(contentMode: .fill)
                        .frame(width: size.width, height: size.height)
                        .clipShape(.rect(topLeadingRadius: 35, bottomTrailingRadius: 35))

                }
                .padding(15)
                .navigationTitle("Ashish Image")
        }
        .padding()


    }
}

#Preview {
    SecureNavigationView()
}
