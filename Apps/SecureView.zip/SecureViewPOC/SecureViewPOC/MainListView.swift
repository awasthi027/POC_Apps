//
//  MainListView.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 02/01/24.
//

import SwiftUI

struct MainListView: View {

    var body: some View {

        SnapShotPreventingView {
        NavigationStack {
                List {
                    NavigationLink {
                        SecureNavigationView()
                    } label: {
                        Text("Show Image")
                    }

                    NavigationLink {
                        ShowSecurityKeyView()
                    } label: {
                        Text("Show Security Key")
                    }
                    NavigationLink {
                        WebContentView()
                    } label: {
                        Text("Show Web Content")
                    }
                    NavigationLink {
                        MyView()
                    } label: {
                        Text("Swift Controller")
                    }
                }
                .navigationTitle("My List")
            }
        }
    }
}

#Preview {
    MainListView()
}



