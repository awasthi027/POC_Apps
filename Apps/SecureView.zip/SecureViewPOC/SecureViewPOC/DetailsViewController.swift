//
//  DetailsViewController.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 03/01/24.
//

import Foundation

import Foundation
import UIKit

class DetailsViewController: UIViewController {

    class func detailsViewController() -> DetailsViewController  {

        let storyboard = UIStoryboard.mainStoryBoard
        if let controller = storyboard.instantiateViewController(withIdentifier:
                                                                String(describing: DetailsViewController.self)) as? DetailsViewController {
           return controller
        }
        return DetailsViewController()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}
