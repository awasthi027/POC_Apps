//
//  ContentView.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 02/01/24.
//

import SwiftUI

struct ShowSecurityKeyView: View {

    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
            Image(uiImage: UIImage(named: "nature.jpg") ?? UIImage())
                .resizable()
                .aspectRatio(contentMode: .fill)
                .clipShape(.rect(topLeadingRadius: 35, bottomTrailingRadius: 35))
        }
        //.modifier(SecureViewModifier(color: .red))
        .padding()
    }
}

#Preview {
    ShowSecurityKeyView()
}


