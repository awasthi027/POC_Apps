//
//  SecureViewPOCApp.swift
//  SecureViewPOC
//
//  Created by Ashish Awasthi on 02/01/24.
//

import SwiftUI

@main
struct SecureViewPOCApp: App {
    var body: some Scene {
        WindowGroup {
            MainListView()
        }
    }
}
